import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { FormoneComponent } from './provisioning/formone/formone.component';
import { CampaignComponent } from './certification/campaign/campaign.component';
import { ManagerfidetailsComponent } from './certification/managerfidetails/managerfidetails.component';
import { SubmittoardbComponent } from './certification/submittoardb/submittoardb.component';

import { DocumentUploadComponent } from './certification/documentupload/documentupload.component';
import { ParsefilesComponent } from './certification/parsefiles/parsefiles.component';
import { DashboardComponent } from './certification/dashboard/dashboard.component';
import { UserComponent } from './settings/user/user.component';
import { DefaultreportsComponent } from './certification/defaultreports/defaultreports.component';
import { AuthGuard } from './services/auth.guard';
import { RfilistComponent } from './certification/rfilist/rfilist.component';
import { CreatetemplatecsvComponent } from './certification/createtemplatecsv/createtemplatecsv.component';
import { RfifileuploadComponent } from './certification/rfifileupload/rfifileupload.component';
import { ManualentryComponent } from './certification/manualentry/manualentry.component';
import { RfipopupComponent } from './certification/rfipopup/rfipopup.component';
import { RfidetailsComponent } from './certification/rfidetails/rfidetails.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { ManagerfddetailsComponent } from './certification/managerfddetails/managerfddetails.component';
import { ManagerfduserlistComponent } from './certification/managerfduserlist/managerfduserlist.component';
//import { ApprovalComponent } from './certification/approval/approval.component';
import { ReportsComponent } from './certification/reports/reports.component';

const routes: Routes = [
  { path: 'login', component: LoginComponent },
  { path: 'home', component: HomeComponent, canActivate: [AuthGuard] },
  {
    path: '',
    component: HomeComponent,
    pathMatch: 'full',
    canActivate: [AuthGuard],
  },
  {
    path: 'certification',
    component: RfilistComponent,
    pathMatch: 'full',
    canActivate: [AuthGuard],
  },
  {
    path: 'certification/dashboard',
    component: DashboardComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'certification/rfdlist',
    component: RfilistComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'certification/createtemplatestruct',
    component: CreatetemplatecsvComponent,
    canActivate: [AuthGuard],
  },
  {
    path: 'certification/rfifileupload',
    component: RfifileuploadComponent,
    canActivate: [AuthGuard],
   },
  { path: 'certification/rfifileupload/id', component: RfifileuploadComponent, canActivate: [AuthGuard],  },
  {
    path: 'certification/rfipopup',
    component: RfipopupComponent,
    canActivate: [AuthGuard],
   },
   {
    path: 'certification/rfidetails',
    component: RfidetailsComponent,
    canActivate: [AuthGuard],
   },
   {
    path: 'certification/manualentry',
    component: ManualentryComponent,
    canActivate: [AuthGuard],
  },

  {
    path: 'certification/managerfddetails',
    component: ManagerfddetailsComponent,
    canActivate: [AuthGuard],
  },

  {
    path: 'certification/managerfduserlist',
    component: ManagerfduserlistComponent,
    canActivate: [AuthGuard],
  },

  // {
  //   path: 'certification/approval',
  //   component: ApprovalComponent,
  //   canActivate: [AuthGuard],
  // },

  {
    path: 'certification/reports',
    component: ReportsComponent,
    canActivate: [AuthGuard],
  },

  {
    path: 'provisioning',
    children: [
      {
        path: 'formone',
        component: FormoneComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
  {
    path: 'certification',
    children: [
      {
        path: 'campaign',
        component: CampaignComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
  {
    path: 'certification',
     children: [
      {
        path: 'managerfidetails',
        component: ManagerfidetailsComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
  {
    path: 'certification',
    children: [
      {
        path: 'parsefiles',
        component: ParsefilesComponent,
        canActivate: [AuthGuard],
      },
      {
        path: 'documentupload',
        component: DocumentUploadComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
  {
    path: 'certification',
    children: [
      {
        path: 'submittoardb',
        component: SubmittoardbComponent,
        canActivate: [AuthGuard],
      },
    ],
  },
  {
    path: 'settings',
    children: [
      { path: 'user', component: UserComponent, canActivate: [AuthGuard] },
    ],
  },
  {
    path: 'certification',
    children: [{ path: 'defaultreports', component: DefaultreportsComponent }],
    canActivate: [AuthGuard],
  },
  {
    path: 'not-found', component: PageNotFoundComponent,  canActivate: [AuthGuard]
  },
  {
    path: '**', redirectTo: '/not-found', canActivate: [AuthGuard]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy' })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
