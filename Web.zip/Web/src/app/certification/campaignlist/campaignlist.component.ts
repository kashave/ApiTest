import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

export interface Application {
  daterange: string;
  owner : string;
  status: string;
  edit: string;
}

@Component({
  selector: 'app-campaignlist',
  templateUrl: './campaignlist.component.html',
  styleUrls: ['./campaignlist.component.css']
})
export class CampaignlistComponent implements OnInit {
  dataSource: Application[] = [
    {daterange: 'From 7/1/2021 To 9/30/2021', owner: "Haddock, John", status: "RFI created", edit:""},
    {daterange: 'From 4/1/2021 To 6/30/2021', owner: "Jackson, Mike", status: "File Upload in Progress", edit:""},
 ];
 displayedColumns: string[] = ['daterange', 'owner', 'status','edit'];

  constructor(private formBuilder: FormBuilder) { }
  tableForm = this.formBuilder.group({
  });

  ngOnInit(): void {
  }

  onFormSubmit() {
    console.log("Submit Clicked");
  }

}
