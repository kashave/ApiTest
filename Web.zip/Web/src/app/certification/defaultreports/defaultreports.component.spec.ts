import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DefaultreportsComponent } from './defaultreports.component';

describe('DefaultreportsComponent', () => {
  let component: DefaultreportsComponent;
  let fixture: ComponentFixture<DefaultreportsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DefaultreportsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DefaultreportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
