import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RfipopupComponent } from '../../certification/rfipopup/rfipopup.component';

export interface Application {
  name: string;
  id : string;
  owner : string;
  emailid: string;
  status: string;
  rfino: string;
  bunit : string;
  dcenter : string;
}
@Component({
  selector: 'app-defaultreports',
  templateUrl: './defaultreports.component.html',
  styleUrls: ['./defaultreports.component.css']
})
export class DefaultreportsComponent implements OnInit {
  options: string[] = ['One', 'Two', 'Three'];
  dataSource: Application[] = [
    {name: 'James Russel', id: "ROBO", bunit:"Re-certify", dcenter:"Active", owner: "James01", emailid : "Closed", rfino:"RFI-1234567", status: "Banking"},
    {name: 'Jack Hunting', id: "DNA", bunit:"Revoke", dcenter:"Terminated", owner: "Jack02", emailid : "Rejected", rfino:"RFI-2345678", status: "Card Status"},
    {name: 'David Hudson', id: "RNA", bunit:"", dcenter:"", owner: "David05", emailid : "Open", rfino:"RFI-3456789",status: ""},
    {name: 'Mike Holland', id: "DIGITAL", bunit:"", dcenter:"", owner: "Mike06", emailid : "InProgress", rfino:"RFI-4567890",status: ""},
 ];
 displayedColumns: string[] = ['rfino','status', 'id', 'name', 'owner', 'bunit','dcenter', 'emailid'];

 email: string;
  constructor(private router: Router, private formBuilder: FormBuilder, public dialog: MatDialog) { }
  tableForm = this.formBuilder.group({
  });

  ngOnInit(): void {
  }

  onFormSubmit() {
    console.log("Submit Clicked");
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(RfipopupComponent, {
      width: '1100px',
      height: '425px',
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.email = result;
    });
  }
}
