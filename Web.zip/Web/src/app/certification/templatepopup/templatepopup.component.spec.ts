import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TemplatepopupComponent } from './templatepopup.component';

describe('TemplatepopupComponent', () => {
  let component: TemplatepopupComponent;
  let fixture: ComponentFixture<TemplatepopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TemplatepopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TemplatepopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
