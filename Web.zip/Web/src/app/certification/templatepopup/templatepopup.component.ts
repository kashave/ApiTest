import { Component, Inject, OnInit } from '@angular/core';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { element } from 'protractor';

interface DialogData {
  ColumnData: [];
}

interface Application {
  SourceColumn: string;
  DestinationColumn : string;
  ColumnPositionIndex : number;
  RowPosition:number;
  ColumnValueStartPosition:number;
  ColumnValueEndPosition:number;
  ColumnValueLength:number;
  ColumnValueEndPositionTag : string;
  SplitColumnValueIndex:number;
  Delimiter : string;
  TabularGroupStartTag : string;
  TabularGroupEndTag : string;
  TabularColumnValuePosition:number;
  IsTabularData:boolean;
  IsGroupHeader:boolean;
}

@Component({
  selector: 'app-templatepopup',
  templateUrl: './templatepopup.component.html',
  styleUrls: ['./templatepopup.component.css']
})
export class TemplatepopupComponent implements OnInit {

  public colData: Application;
  public IsStructTemplate:boolean;
  public IsGroupHeaderChecked :boolean = false;
  public IsTabularDataChecked :boolean = false;
  public arrColumns:any;
  /*heroes: string[];
  UserId: any = [];
  RFIId: any;
  delegatesplit: string[];
  stringArr: string[] = [];
  listDelegate:string[];
  splitLstDelegate: string[];
  splitListComma: string[];
  splitdata:string[];
  RFD: any;*/

  constructor(public dialog: MatDialog,public dialogRef: MatDialogRef<TemplatepopupComponent>
    ) {
      //,@Inject(MAT_DIALOG_DATA) data
      /*this.colData=data.pcolData;
      this.IsStructTemplate = data.pIsStructTemplate;
      this.arrColumns = data.parrColumns;

      if (this.colData.IsGroupHeader){
        this.IsGroupHeaderChecked = true;
      }
      else {
        this.IsGroupHeaderChecked = false;
      }

      if (this.colData.IsTabularData){
        this.IsTabularDataChecked = true;
      }
      else {
        this.IsTabularDataChecked = false;
      }*/
    }
    
    /*public rfiDetails = [];
    public rfiDetailsComma = [];*/

   onCloseClick(): void {
    this.dialogRef.close();
   }

   ngOnInit(): void {
   }


   onKeyPress(event: any) {
    const regexpNumber = /([0-9]|1[0-2])/;
    let inputCharacter = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !regexpNumber.test(inputCharacter)) {
      event.preventDefault();
    }
  }

  UpdateDes( strVal:string){
    this.colData.DestinationColumn = strVal;
   }

   selectRawColumns(strVal:string){
    this.colData.DestinationColumn = strVal;
    if (this.arrColumns.length > 0){
      let indx:number = this.arrColumns.findIndex(x => x === strVal);
      this.colData.ColumnPositionIndex = indx+1;
    }
   }

   Updatecvendpostag( strVal:string){
    this.colData.ColumnValueEndPositionTag = strVal;
   }

   Updatedelimiter( strVal:string){
    this.colData.Delimiter = strVal;
   }

   Updatetabulargst( strVal:string){
    this.colData.TabularGroupStartTag = strVal;
   }

   Updatetabularget( strVal:string){
    this.colData.TabularGroupEndTag = strVal;
   }

   UpdateColumnPos(intVal:number){
    this.colData.ColumnPositionIndex = intVal;
   }

   Updaterowpos(intVal:number){
    this.colData.RowPosition = intVal;
   }

   Updatecvstartpos(intVal:number){
    this.colData.ColumnValueStartPosition = intVal;
   }
   Updatecvendpos(intVal:number){
    this.colData.ColumnValueEndPosition = intVal;
   }
   Updatecvlength(intVal:number){
    this.colData.ColumnValueLength = intVal;
   }
   Updatesplitcvindex(intVal:number){
    this.colData.SplitColumnValueIndex = intVal;
   }
   Updatetabularcv(intVal:number){
    this.colData.TabularColumnValuePosition = intVal;
   }

   OkClick(){
    this.dialogRef.close();
   }

   onChangeIsGroupHeaderChecked(ob: MatCheckboxChange) {
    if (ob.checked){
      this.IsGroupHeaderChecked = true;
      this.colData.IsGroupHeader = true;
    }
    else {
      this.IsGroupHeaderChecked = false;
      this.colData.IsGroupHeader = false;
    }
  }

  onChangeIsTabularDataChecked(ob: MatCheckboxChange) {
    if (ob.checked){
      this.IsTabularDataChecked = true;
      this.colData.IsTabularData = true;
    }
    else {
      this.IsTabularDataChecked = false;
      this.colData.IsTabularData = false;
    }
  }
}
