import { Component, OnInit, Inject, ɵflushModuleScopingQueueAsMuchAsPossible } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { CommonService } from 'src/app/services/common.service';
import { element } from 'protractor';
import { RfiService } from 'src/app/services/rfi.service';
import { ActivatedRoute } from '@angular/router';
import { Router } from '@angular/router';


interface DialogData {
  email: string;
}

@Component({
  selector: 'app-rfidetails',
  templateUrl: './rfidetails.component.html',
  styleUrls: ['./rfidetails.component.css'],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} }
  ]
})
export class RfidetailsComponent implements OnInit {
  pageSize = window.innerWidth < 1440 ? 1.2: 6;
  heroes: string[];
  UserId: any = [];
  RFIId: any;
  delegatesplit: string[];
  stringArr: string[] = [];
  listDelegate:string[];
  splitLstDelegate: string[];
  splitListComma: string[];
  splitdata:string[];
  RFD: any;
  isshowupload:any=false;
  isshowview:any=false;
  displayedColumns = ['quarter'];
  dataSource = new MatTableDataSource<any>();
  constructor(public dialog: MatDialog,
    private route: ActivatedRoute,
    private commonService: CommonService,
    private router: Router,
    @Inject(MAT_DIALOG_DATA) data , private _rfiService: RfiService,

    ) {
      }
    
    fileArray : any[] = [];
    public rfiDetails = [];
    public rfiDetailsComma = [];
    showrole: any;

  //  onCloseClick(): void {

  //   this.dialogRef.close();
  // }

  ngOnInit() {
  
    this.showrole = this.commonService.getRoleName();
    this.isshowview=true;
    this.RFIId = this.route.snapshot.queryParamMap.get('rfiId');
    // this.router.navigate(["/header"]).then(() => window.location.reload())
  

    this._rfiService
      .getRfiListDetails(this.RFIId)
      .subscribe(
        (data) => {
          // this.fileArray = [];
          // data.forEach(element => {
          // const evid : any = {
          //   quarter: element.year
          //         // fileSize: element.fileSize,
          //         // fileType: element.fileType,
          //         // fileStatus: element.fileStatus
          //     }
          //     this.fileArray.push(evid);
          (this.rfiDetails = data)
         console.log(JSON.stringify(data))
          this.rfiDetails.forEach((element) => {
            this.RFD= element.certID;
          this.listDelegate= element.delegate;
          var strSplitdel = new String(this.listDelegate);
          var strSplitValue=strSplitdel.split("$");
          this.splitListComma=strSplitValue;

          this.splitListComma.forEach((splitdata) =>{

            this.rfiDetailsComma.push(splitdata)

           });
          // this.dataSource = new MatTableDataSource(this.fileArray);
        });
     });
     if(this.showrole=="ACGMember")
     {
      this.isshowupload=false;
     }
     else{
      this.isshowupload=true;
     }
  }
  upload(){
    this.router.navigate(['/certification/rfifileupload/'], { queryParams: { rfiId : this.RFIId  }, queryParamsHandling: 'merge' });

  }
  redirect(){
    this.router.navigate(['/certification/rfdlist/']);
  }
}
