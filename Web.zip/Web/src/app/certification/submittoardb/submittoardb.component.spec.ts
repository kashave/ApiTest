import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SubmittoardbComponent } from './submittoardb.component';

describe('SubmittoardbComponent', () => {
  let component: SubmittoardbComponent;
  let fixture: ComponentFixture<SubmittoardbComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SubmittoardbComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmittoardbComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
