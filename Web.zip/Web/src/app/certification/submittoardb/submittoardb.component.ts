
import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { RfiService } from 'src/app/services/rfi.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { MenuItems, Permission } from 'src/app/header/header.component';

@Component({
  selector: 'app-submittoardb',
  templateUrl: './submittoardb.component.html',
  styleUrls: ['./submittoardb.component.css']
})
export class SubmittoardbComponent implements OnInit {

  erroMsg: any;
  displayedColumns: string[] = [
    'rfiId',
    'rfiName',
    'rfiStatus',
    'rfiOwner',
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  dataSource = new MatTableDataSource<any>();
  constructor( private router: Router,
    private _rfiService: RfiService,private commonService: CommonService) { }

  ngOnInit(): void {

    this._rfiService
      .getCurrentRfiList()
      .subscribe((data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }


  UpdateAndDownloadFile() 
  {
    
    this._rfiService.downloadZipFile(this.commonService.getUserId()).subscribe(respdata => {
      this.downLoadFile(respdata, 'application/zip');

      this._rfiService
      .getCurrentRfiList()
      .subscribe((data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  
      }, error => {
     console.log(error);
  });
   
  
  }

  downLoadFile(data: any, type: string) {
    
    var blob = new Blob([data], { type: type });
    var url = window.URL.createObjectURL(blob);

    // create <a> tag dinamically
var fileLink = document.createElement('a');
fileLink.href = url;

// it forces the name of the downloaded file
fileLink.download = 'UserList';

// triggers the click event
fileLink.click();
window.URL.revokeObjectURL(url);

    //var pwa = window.open(url);
    //if (!pwa || pwa.closed || typeof pwa.closed == 'undefined') {
    //    alert('Please disable your Pop-up blocker and try again.');
   // }
}

}
