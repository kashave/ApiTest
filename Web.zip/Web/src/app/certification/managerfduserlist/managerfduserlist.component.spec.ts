import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerfduserlistComponent } from './managerfduserlist.component';

describe('ManagerfduserlistComponent', () => {
  let component: ManagerfduserlistComponent;
  let fixture: ComponentFixture<ManagerfduserlistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagerfduserlistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerfduserlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
