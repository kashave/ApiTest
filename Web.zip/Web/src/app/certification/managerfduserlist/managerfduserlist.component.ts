import { Component, Input, OnInit,ElementRef, ViewChildren,ViewChild, QueryList } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator, PageEvent }  from '@angular/material/paginator';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators, NgForm } from '@angular/forms';
import { MatSort } from '@angular/material/sort';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { MatDialog} from '@angular/material/dialog';
import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';
import { Observable } from 'rxjs';
import { RfiService } from 'src/app/services/rfi.service';
import { ActivatedRoute, Router, Event } from '@angular/router';
import { DatePipe } from '@angular/common';
import { MenuItems, Permission } from 'src/app/header/header.component'
import { map, startWith } from 'rxjs/operators';
import { EmployeelookupComponent } from 'src/app/certification/employeelookup/employeelookup.component';
import { debounce } from 'rxjs/internal/operators/debounce';
import { TableUtil } from "src/app/tableUtil";
import * as XLSX from "xlsx";
import { merge } from 'rxjs/internal/observable/merge';
import { tap } from 'rxjs/internal/operators/tap';
import { start } from 'repl';

enum RFIStatus{
  open ="open",
  submitted = "submitted/pending acceptance",
  returned = "returned",
  complete = "complete/certification started"
}

@Component({
  selector: 'app-managerfduserlist',
  templateUrl: './managerfduserlist.component.html',
  styleUrls: ['./managerfduserlist.component.scss'],
  providers: [DatePipe]
})
export class ManagerfduserlistComponent implements OnInit {
  fName:string;
  lName:string;
  options: string[];
  selectedOption: string;
  fileNameloop: string;
  fileArray : any[] = [];
  applicationName:any;
  applicationOwner:any;
  applicationId:any;
  rfiStatus:any;
  loadTabs: boolean = false;
  loaddata: boolean = false;
  messages: any[] = [];
  isDisabled: boolean = true;
  isDownload: boolean = true;
  RFIStatusId: number;
  StatusMessage:string;
  statusIsActive: boolean=false;
  comprfiId: any;
  isLoading = false;
  rfi:any;
  rfiId:any;
  tdate = new Date();  
  maxDate: Date;
  today = new Date();
  @Input()
  max: Date | null;
  alphas: string[][];
  copyVal: any;
  selectedrow: any;
  ismultiplerow: boolean = false;
  multipleselectedrow: any[] = [];
  public isshowview: boolean = false;
  public isshowsave: boolean = false;
  public isshowsubmit: boolean = false;
  public isreadonly: boolean = false;
  manualentryForm: FormGroup;
  myControl = new FormControl();
  end = new FormControl('');
  start = new FormControl('');
  replaceText = new FormControl('');
  fieldName = new FormControl('');  
  userOptions: any[] = [];
  filteredOptions: Observable<any[]>;
  @ViewChildren("rowitem") MyDOMElement: QueryList<ElementRef>;
  copyMatTable: any;
  selectionArray: any[] = [];
  totalCount: number;
  fields: any[] = [
    {id:0, text:'ReviewID', value:'reviewID'},
    {id:1, text:'BU', value:'bu'},
    {id:2, text:'UAID', value:'uaid'},
    {id:3, text:'Asset', value:'asset'},
    {id:4, text:'Asset Details', value:'assetDetails'},
    {id:5, text:'Asset Notes', value:'assetNote'},
    {id:6, text:'First Name', value:'firstName'},
    {id:7, text:'Last Name', value:'lastName'},
    {id:8, text:'User ID', value: 'userId'},
    {id:9, text:'Emp Id', value:'employeeID'},
    {id:10, text: 'Term Date', value:'termdate'},
    {id:11, text:'Role', value:'role'},
    {id:12, text:'LastLogin', value:'lastLogin'}
  ];

  totalRows = 0;
  currentPage = 0;
  pageSize = 100;
  pageSizeOptions: number[] = [5,20,50,100];
  totalRecords: any[]=[];

  constructor(private rfiService: RfiService,
    private commonService: CommonService,
    private datePipe: DatePipe,
    private _fb: FormBuilder,
    private route: ActivatedRoute,
    public dialog: MatDialog,
    private userService : UserService,
    private _snackBar: MatSnackBar    
    ) {
 }
 
 
  public  columnList = ["action","reviewID","bu","uaid",
  "asset",
  "assetDetails",
  "assetNote",
  "firstName",
  "lastName",
  "userId",
  "employeeID",
  "termdate",
  "role",  
  "lastLogin",
  "errorMessage",
  "delete"];

  // public  columnList = ["action","BU",
  // "Asset",
  // "AssetDetails",
  // "AssetNote",
  // "FirstName",
  // "LastName",
  // "UserId",
  // "Role",
  // "Status",
  // "EmployeeId",
  // "TermDate",
  // "Email",
  // "ErrorMessage"];

  userListMatTabDataSource = new MatTableDataSource<any>();

  @ViewChild(MatPaginator) paginator : MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild('testForm') testForm: NgForm;

  async ngOnInit() {
    
    this.displayRoleMenuPermission()
    let rfiList = await this.getRFIDetailList();
    if(rfiList){
      let rfiQueryId = this.route.snapshot.queryParamMap.get('rfiId');
       if(rfiQueryId){
        this.rfi = rfiQueryId;
        let dataval = this.transform(this.rfi);
        let defSelect = {
            applicationName : dataval[0].applicationName,
            applicationOwner : dataval[0].applicationOwner,
            rfi: dataval[0].rfi,
            rfiId: dataval[0].rfiId,
            applicationId : dataval[0].applicationId,
            rfiStatus: dataval[0].rfiStatus
        }
        this.myControl.setValue(defSelect);
        this.loadTabs = true;
        this.applicationName = defSelect.applicationName;
        this.applicationOwner = defSelect.applicationOwner;
        this.applicationId = defSelect.applicationId;
        this.rfiStatus = defSelect.rfiStatus;
        this.rfi = defSelect.rfi;
        this.rfiId = defSelect.rfiId;
        this.commonService.setOption('applicationName', this.applicationName);
        this.commonService.setOption('applicationId', this.applicationId);
      }
      this.filteredOptions = this.myControl.valueChanges
        .pipe(
          startWith({} as any),
          map(user => user && typeof user === 'object' ? user.applicationName : user),
          map((name: string) => name ? this.transform(name) : this.userOptions.slice())
        );
    }
    }


    displayFn(user: any){
      let pop =  user ? user.rfi + ' | ' + user.applicationName  + ' | ' + user.applicationOwner + '|' + user.rfiStatus : '';
      return pop;
    }
    transform(searchText: string): any[] {
      let items = this.userOptions;
      if (!items) return [];
      if (!searchText) return items;

      return items.filter(item => {
        return Object.keys(item).some(key => {
          return String(item[key]).toLowerCase().includes(searchText.toLowerCase());
        });
      });
     }

    
  ngAfterViewInit(){
    this.userListMatTabDataSource.sort = this.sort;
    this.userListMatTabDataSource.paginator = this.paginator;
  }

  applyFilter(filterValue: string) {
    this.userListMatTabDataSource.filter = filterValue.trim().toLowerCase();
  }

  save() {
    // if ((this.testForm.touched || this.editedData.length > 0) && !this.testForm.valid) {
    //   console.log("push this array to server this.editedData" + this.editedData);
    //   // this.editedData <- push on server
    //   alert('not valid');
    // } else {
    //   alert("data submitted");
    //   //this.getAlldata();
    // }
  }

  dataitem:any;
  async getUserListDetails(rfdid : number){
    this.isLoading = true;
    this.dataitem = await this.rfiService.GetRFDUserList(rfdid);
    if(this.dataitem){
     this.totalRecords = this.dataitem;
     var str = this.totalRecords.slice(this.currentPage,this.pageSize);
     this.userListMatTabDataSource = new MatTableDataSource<any>(str);
     if(this.userListMatTabDataSource.data.length > 0){
          this.loaddata = true; 
          this.totalCount = this.dataitem.length;
          setTimeout(() => {
            this.userListMatTabDataSource.sort = this.sort; 
            this.paginator.pageIndex = this.currentPage;
            this.paginator.length = this.totalCount;
          });
      }
      else
      {
        this.loaddata = false;
      }
      this.isLoading = false;
    }
 }

 sortData(sortdata: MatSort){
   this.isLoading = true;
  var sortarr: any[] = [];  
  if(sortdata.active.toLowerCase() == 'firstname'){
     if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.firstName < b.firstName)? 1 : -1);
     }
     else{
      sortarr = this.dataitem.sort((a,b)=> (a.firstName < b.firstName)? -1 : 1);
     }
  }

  if(sortdata.active.toLowerCase() == 'lastname'){
    if(sortdata.direction == 'asc'){
    sortarr = this.dataitem.sort((a,b)=> (a.lastName < b.lastName)? 1: -1);
    }
    else{
    sortarr = this.dataitem.sort((a,b)=> (a.lastName < b.lastName)? -1: 1);
    }
  }

  if(sortdata.active.toLowerCase() == 'userid'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.userId < b.userId)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.userId < b.userId)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'employeeid'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.employeeID < b.employeeID)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.employeeID < b.employeeID)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'role'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.role < b.role)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.role < b.role)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'lastlogin'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.lastLogin < b.lastLogin)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.lastLogin < b.lastLogin)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'errormessage'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.errorMessage < b.errorMessage)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.errorMessage < b.errorMessage)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'termdate'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.termdate < b.termdate)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.termdate < b.termdate)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'bu'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.bu < b.bu)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.bu < b.bu)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'uaid'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.uaid < b.uaid)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.uaid < b.uaid)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'reviewid'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.reviewID < b.reviewID)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.reviewID < b.reviewID)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'asset'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.asset < b.asset)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.asset < b.asset)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'assetdetails'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.assetDetails < b.assetDetails)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.assetDetails < b.assetDetails)? -1: 1);
      }
  }

  if(sortdata.active.toLowerCase() == 'assetnote'){
    if(sortdata.direction == 'asc'){
      sortarr = this.dataitem.sort((a,b)=> (a.assetNote < b.assetNote)? 1: -1);
      }
      else{
        sortarr = this.dataitem.sort((a,b)=> (a.assetNote < b.assetNote)? -1: 1);
      }
  }  

  let strt = this.pageSize * this.currentPage;
  var item:any[] = [];

  if(this.currentPage == 0){
    item = sortarr.slice(0, this.pageSize);
  }
  else{
    item = sortarr.slice(strt, (strt + this.pageSize));
  }

  this.userListMatTabDataSource = new MatTableDataSource<any>(item);
  this.isLoading = false;
 }


 private formatDate(date) {
  if(date){
  const d = new Date(date);
  let month = '' + (d.getMonth() + 1);
  let day = '' + d.getDate();
  const year = d.getFullYear();
  if (month.length < 2) month = '0' + month;
  if (day.length < 2) day = '0' + day;
  let tdte = [year, month, day].join('-');
  return tdte;
}
else{
    return;
}
}

displayRoleMenuPermission()
{
      this.userService
      .getMenuPermission(this.commonService.getRoleId(),MenuItems.ManageRFDUserList)
      .subscribe((data) => {
        data.forEach(element =>
          {
            if(Permission.View == element.permissionId)
            {
              this.isshowview  = true;
            }
            if(Permission.Save == element.permissionId)
            {
              this.isshowsave  = true;
            }
            if(Permission.Submit == element.permissionId)
            {
              this.isshowsubmit  = true;
            }
          });
      });
  } 


  async getRFIDetailList() {
    let cDate =this.datePipe.transform(this.tdate, 'MM-dd-yyyy');
    let data = await this.rfiService.getRFIDetailList(this.commonService.getUserName(),
    this.commonService.getRoleName(),cDate);
    if(data){
    let rfifilter: any[] = [];
      data.forEach(element => {
        const df : any = {
          applicationName : element.applicationName,
          applicationOwner : element.rfiOwner,
          rfi: element.rfiId,
          rfiId:element.id,
          applicationId : element.applicationId,
          rfiStatus: element.rfiStatus
        }
        rfifilter.push(df);
      });
      this.userOptions = rfifilter;
    }
    return this.userOptions;
  }
  
  pageChanged(event:PageEvent){
    this.isLoading = true;
    this.pageSize = event.pageSize;
    this.currentPage = event.pageIndex;
    let strt = (this.pageSize * this.currentPage);
    var item:any[] = [];
    if(this.currentPage == 0){
    item = this.dataitem.slice(0,this.pageSize);
    }
    else{
    item = this.dataitem.slice(strt, (strt + this.pageSize));
    }
    this.userListMatTabDataSource = new MatTableDataSource<any>(item);
    this.isLoading = false;
  }

  ValidandUpdate(){
    this.rfiService.ValidateUpdateStatus(this.rfiId,this.commonService.getUserId())
    .subscribe((result) => {
      if(result){
        const snackBarConfig = new MatSnackBarConfig();
        snackBarConfig.verticalPosition = 'bottom';
        snackBarConfig.duration = 3000;
        snackBarConfig.panelClass = 'center';
        this._snackBar.open("Completed successfully!", "",snackBarConfig);
        this.isreadonly = true;
        this.isDisabled = true;
      }
  });

  }

  async OnSelected(userlistselected : any) {
    this.loadTabs = true;
    this.applicationName = userlistselected.value.applicationName;
    this.applicationOwner = userlistselected.value.applicationOwner;
    this.applicationId = userlistselected.value.applicationId;
    this.rfi = userlistselected.value.rfi;
    this.rfiId = userlistselected.value.rfiId;
    this.rfiStatus = userlistselected.value.rfiStatus;
    if(userlistselected.value.rfiStatus.toLowerCase() == RFIStatus.submitted  ||
       userlistselected.value.rfiStatus.toLowerCase() == RFIStatus.complete ){
      this.isreadonly = true;
      this.isDisabled = true;
      this.isDownload = false;
    }
    await this.getUserListDetails(this.rfiId);
    this.userListMatTabDataSource.sort = this.sort;
    this.userListMatTabDataSource.paginator = this.paginator;
    
  }

  removeItem(rowVal:any,inx:any) {
      this.userService.DeleteUserAccess(rowVal.uId,rowVal.assetId,rowVal.roleId,this.rfiId).subscribe(data=>
      {
            if(data){
              var inx = this.userListMatTabDataSource.data.findIndex(q=>q.guid == rowVal.guid);
              this.userListMatTabDataSource.data.splice(inx,1);
              this.userListMatTabDataSource._updateChangeSubscription();
              this.totalCount = (this.totalCount - 1);
              this.totalRows = this.totalCount;
              const snackBarConfig = new MatSnackBarConfig();
              snackBarConfig.verticalPosition = 'bottom';
              snackBarConfig.duration = 3000;
              snackBarConfig.panelClass = 'center';
              this._snackBar.open("User deleted successfully!", "",snackBarConfig);
            }
      });
  }

  fillemp(usr:any,i:any,val:any){
    var matIndex = this.userListMatTabDataSource.data.findIndex(c=>c.guid == usr.guid);
    var item = document.getElementById("employeeID-"+i);
    this.userListMatTabDataSource.data[matIndex]["employeeID"] = val;
    this.userListMatTabDataSource._updateChangeSubscription();
  }

  SaveData(){
    this.isLoading = true;    
    const distinctArray = this.editArray.filter((n,i) =>this.editArray.indexOf(n)==i);
    const filterdataitem = this.dataitem.filter((ditem) => distinctArray?.includes(ditem.guid));
    
    const myFormData: any = {
      //"UserAccessList" : this.dataitem,
      "UserAccessList" : filterdataitem,
      "UserId": this.commonService.getUserId(),
      "RfiId" : this.rfiId,
      "RfiStatus": this.rfiStatus
    };

    debugger;
    this.userService.UpdateUserAccessList(myFormData)
    .subscribe((data) => {  
      this.editArray = [];   
      var gridData = this.getUserListDetails(this.rfiId);
      if(gridData){
        this.isLoading = false;
        if(data){
          this.isDownload = false;
          this.isDisabled = false;

          setTimeout(() => {
            this._snackBar.open('User details saved successfully.', '', {
              duration: 8000,
              verticalPosition: 'bottom'
            });
          }, 1000);
        }
        else{
          this.isDownload = true;
          this.isDisabled = true;
          setTimeout(() => {
            this._snackBar.open('User details saved successfully. Data validation failed.', '', {
              duration: 8000,
              verticalPosition: 'bottom'
            });
          }, 1000);
        }

      }
      
    });
   }
  cancelForm() {
    window.location.reload();
  }

  clear() {
    this.myControl.reset('');
    this.loadTabs = false;
    this.loaddata = false;
  }

  openDialog(item: any,inx:any,guid:any): void{
    this.fName = item.firstName;
    this.lName = item.lastName;
    var matIndex = this.userListMatTabDataSource.data.findIndex(c=>c.guid == guid);
    const dialogRef = this.dialog.open(EmployeelookupComponent,{
      width: '80%',disableClose: false,
      data: { fName: this.fName, lName : this.lName }
    });
    
    dialogRef.afterClosed().subscribe(res=>{
    if(res && res.data && res.data.length > 0){
        res.data.forEach(element => {
          this.userListMatTabDataSource.data[matIndex]["employeeID"] = element.hrEmployeeID;
          this.userListMatTabDataSource._updateChangeSubscription();
      }); 
    }      
    });

  }
  
  CopyToClipboard(){ 
    this.ismultiplerow = true;
    this.selectionArray.forEach(element => {
    this.copyVal = element;
   });
   this.selectionArray = [];
 }

 copyToSelectedRow(){
   this.ismultiplerow = false;
   let data = this.userListMatTabDataSource.data[this.copyVal.Index][this.copyVal.ColumnName];
   this.selectionArray.forEach(element => {
     this.userListMatTabDataSource.data[element.Index][element.ColumnName] = data;
     var ele = document.getElementById(element.ColumnName+element.Index);
     ele.style.backgroundColor = '#f9f9f9';
     var ele1 = document.getElementById(element.ColumnName+'-'+element.Index);
     ele1.style.backgroundColor = '#f9f9f9';
   });
   this.selectionArray = [];
   var ele = document.getElementById(this.copyVal.ColumnName+this.copyVal.Index);
     ele.style.backgroundColor = '#f9f9f9';
     var ele1 = document.getElementById(this.copyVal.ColumnName +'-'+ this.copyVal.Index);
     ele1.style.backgroundColor = '#f9f9f9';
 }

 copyColumn(name: any,inx: any,guid:any){
   var ele = document.getElementById(name+inx);
   ele.style.backgroundColor = '#b7bdb9';
   var matIndex = this.userListMatTabDataSource.data.findIndex(c=>c.guid == guid)
   const copyval = {
     Index: matIndex,
     ColumnName : name,
     GUID: guid
   }

   var ele1 = document.getElementById(name+'-'+inx);
   ele1.style.backgroundColor = '#b7bdb9';
   this.selectionArray.push(copyval);
 }
 
    replaceTextColumn(){
      var id = this.fieldName.value;
      var txt = this.replaceText.value;
      var start = this.start.value - 1;
      var end = this.end.value;
      var name = this.fields.find(a=>a.id == id);
      if(id!=undefined && id!=null && txt ){
      for(var i = start; i < end; i++){
        this.dataitem[i][name.value] = txt;
      }
    }
 }

 getToday(): string {
  return new Date().toISOString().split('T')[0];
}


exportArray() {
  const userListArray: Partial<any>[] = this.dataitem.map(x => ({
    ReviewID:x.reviewID,
    BU: x.bu,
    APM:x.uaid,
    Asset: x.asset,
    AssetDetails: x.assetDetails,
    AssetNote: x.assetNote,
    FirstName: x.firstName,
    LastName: x.lastName,
    UserId: x.userId,
    EmployeeId: x.employeeID,
    TermDate: x.termdate,
    Role: x.role,
    LastLogin: x.lastLogin
  }));
  TableUtil.exportArrayToExcel(userListArray, "RFDUserList");
}

editArray: any[] =[];



addEditRow(row: any)
  {
    let item = this.dataitem.find(a=>a.guid == row.guid);
     if(this.editArray.length > 0 && !this.editArray.find(c=>c.guid == row.guid))
     {
      this.editArray.push(row.guid);      
     }
     else if(this.editArray.length == 0){
       this.editArray.push(row.guid)
     }
  }

}

