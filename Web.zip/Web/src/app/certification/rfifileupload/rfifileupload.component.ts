import { HttpClient } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatOption } from '@angular/material/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { RfiService } from 'src/app/services/rfi.service';
import { DatePipe } from '@angular/common';
import { CommonService } from 'src/app/services/common.service';
import { IRFIList } from 'src/app/interfaces/IRFIList';
import { ActivatedRoute } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { AlertdialogComponent } from 'src/app/modal/alertdialog/alertdialog.component';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { TemplateService } from 'src/app/services/template.service';
import { MenuItems, Permission } from 'src/app/header/header.component';
import { UserService } from 'src/app/services/user.service';



export class RFIDetail {
  constructor() { }
  public applicationName: string;
}

@Component({
  selector: 'app-rfifileupload',
  templateUrl: './rfifileupload.component.html',
  styleUrls: ['./rfifileupload.component.scss'],
  providers: [DatePipe]

})
export class RfifileuploadComponent implements OnInit {
  Message: string = "Parent to Child";

  public IsTemplateChecked: boolean = false;
  public templatesList: any[];

  options: string[];
  selectedOption: string;
  applicationName: any;
  applicationOwner: any;
  applicationId: number;
  rfiStatus: any;
  openStatus: boolean = false;
  BUName: string;
  rfi: any;
  rfiId: number;
  loadTabs: boolean = false;
  fileArray: any[] = [];
  uploadfileArray: any[] = [];
  selectedFiles: any[] = [];
  files: any[] = [];
  tdate = new Date();
  displayedColumns = ['documentId','fileName', 'fileSize', 'fileType', 'fileStatus','actions']; 
  dataSource: MatTableDataSource<any>;
  isfileGrid: boolean = false;
  isSaveDisabled: boolean = true;
  uploadForm: FormGroup;
  isdeleteDisabled: boolean = false;
  isdownloadeDisabled: boolean = false;
  childuploadrawusers: string;
  childmanualuserentry: string;
  childmanagetemplate: string;

  ischilduploadrawusers: boolean = false;
  ischildmanualuserentry: boolean = false;
  ischildmanagetemplate: boolean = false;

  public isshowview: boolean = false;
  public isshowsave: boolean = false;
  public isshowsubmit: boolean = false;
  public isshowdelete: boolean = false;


  public israwuploaduserlistshowview: boolean = false;
  public israwuploaduserlistshowsave: boolean = false;
  public israwuploaduserlistshowsubmit: boolean = false;
  public israwuploaduserlistshowupload: boolean = false;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('attachments') attachment: any;
  validFileTypes: any = ['txt', 'pdf', 'xls', 'xlsx', 'csv', 'TXT', 'PDF', 'XLS', 'XLSX', 'CSV'];
 
  constructor(private templateService: TemplateService, private rfiService: RfiService, private commonService: CommonService,
    private http: HttpClient, private datePipe: DatePipe,
    private route: ActivatedRoute, public dialog: MatDialog, private userService: UserService) {

    this.uploadForm = new FormGroup({
      rfdSearchControl: new FormControl(''),
      templateInput: new FormControl('')
    });
    setInterval(() =>{
      this.rfiService.getRFIDocumentList(this.rfiId)
         
        .subscribe((data) => {
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
          console.log('refresh......')
        });
    },30000);
  }


  myControl = new FormControl();
  userOptions: any[] = [];
  filteredOptions: Observable<any[]>;

  async ngOnInit() {
    this.displayRoleMenuPermission();
    let rfiList = await this.getRFIDetailList();
    if (rfiList) {

      let rfiQueryId = this.route.snapshot.queryParamMap.get('rfiId');
      if (rfiQueryId) {
        this.rfi = rfiQueryId;
        let dataval = this.transform(this.rfi);
        let defSelect = {
          applicationName: dataval[0].applicationName,
          applicationOwner: dataval[0].applicationOwner,
          rfi: dataval[0].rfi,
          rfiId: dataval[0].rfiId,
          applicationId: dataval[0].applicationId,
          rfiStatus: dataval[0].rfiStatus,
          BUName: dataval[0].buname
        }
        this.myControl.setValue(defSelect);
        this.loadTabs = true;
        this.applicationName = defSelect.applicationName;
        this.applicationOwner = defSelect.applicationOwner;
        this.applicationId = defSelect.applicationId;
        this.rfiStatus = defSelect.rfiStatus,
          this.BUName = defSelect.BUName;
        this.rfi = defSelect.rfi;
        this.rfiId = defSelect.rfiId;
        this.commonService.setOption('applicationName', this.applicationName);
        this.commonService.setOption('applicationId', this.applicationId);
        this.commonService.setOption('rfiStatus', this.rfiStatus);
        this.commonService.setOption('buname', this.BUName);
        this.getRFIDocumntList(this.rfiId);
        this.getActiveTemplate();
        if(this.rfiStatus=="Open" || this.rfiStatus == "Returned"){
          this.openStatus=true;
        }
        else this.openStatus=false;
      }
      this.filteredOptions = this.myControl.valueChanges
        .pipe(
        startWith({} as any),
        map(user => user && typeof user === 'object' ? user.applicationName : user),
        map((name: string) => name ? this.transform(name) : this.userOptions.slice())
        );
    }
  }

  OnSelected(option: MatOption) {
    this.dataSource = null;
    this.loadTabs = true;
    this.applicationName = option.value.applicationName;
    this.applicationOwner = option.value.applicationOwner;
    this.applicationId = option.value.applicationId;
    this.rfiStatus = option.value.rfiStatus;
    this.BUName = option.value.buname;
    this.rfi = option.value.rfi;
    this.rfiId = option.value.rfiId;
    this.getRFIDocumntList(this.rfiId);
    this.commonService.setOption('applicationName', option.value.applicationName);
    this.commonService.setOption('applicationId', option.value.applicationId);
    this.commonService.setOption('rfiid', option.value.rfiId);
    this.commonService.setOption('rfistatus', option.value.rfiStatus);
    this.commonService.setOption('buname', option.value.buname);

    if(option.value.rfiStatus=="Open" || option.value.rfiStatus =="Returned"){
      this.openStatus=true;
    }
    else this.openStatus=false;
 
    this.uploadForm.get('templateInput').setValue("");
    this.IsTemplateChecked = false;

    if (this.applicationId > 0) {
      this.templateService
        .GetAppTemplatesList(this.applicationId)
        .subscribe((data) => {
          this.templatesList = data;
          console.log(data);
          data.forEach(element => {
            if (element.isDefault == true) {
              this.IsTemplateChecked = true;
              this.uploadForm.get('templateInput').setValue(element.description);
            }
          });
        });
    }
  }

  getRFIDocumntList(rfiId: number) {

    this.rfiService.getRFIDocumentList(this.rfiId).subscribe(data => {
      this.fileArray = [];
      data.forEach(element => {
        const evid: any = {
          fileName: element.fileName,
          fileSize: element.fileSize,
          fileType: element.fileType,
          fileStatus: element.fileStatus,
          documentId : element.documentId,
        }
        this.fileArray.push(evid);
      });

      if (this.fileArray.length > 0) {
        this.isfileGrid = true;
        this.dataSource = new MatTableDataSource(this.fileArray);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
      else {
        this.isfileGrid = false;
      }
    })
  }

  async getRFIDetailList() {
    let cDate = this.datePipe.transform(this.tdate, 'MM-dd-yyyy');
    let data = await this.rfiService.getRFIDetailList(this.commonService.getUserName(),
      this.commonService.getRoleName(),
      cDate
    );
    if (data) {
      let rfifilter: any[] = [];
      data.forEach(element => {
        const df: any = {
          applicationName: element.applicationName,
          applicationOwner: element.rfiOwner,
          rfi: element.rfiId,
          rfiId: element.id,
          applicationId: element.applicationId,
          rfiStatus: element.rfiStatus,
          buname: element.bu,

        }
        rfifilter.push(df);
      });
      this.userOptions = rfifilter;
    }
    return this.userOptions;
  }

  transform(searchText: string): any[] {
    let items = this.userOptions;
    if (!items) return [];
    if (!searchText) return items;

    return items.filter(item => {
      return Object.keys(item).some(key => {
        return String(item[key]).toLowerCase().includes(searchText.toLowerCase());
      });
    });
  }


  displayFn(user: any) {
    let pop = user ? user.rfi + ' | ' + user.applicationName + ' | ' + user.applicationOwner + ' | ' + user.rfiStatus : '';
    return pop;
  }

  updateSelectedOption(event: any) {
    this.selectedOption = event.option.selected;
  }

  bytesToMegaBytes(bytes) {

    return (bytes / (1024 * 1024)).toFixed(9);
  }

  onUserListFileChange(pFileList: File[]) {

    // If uploaded files are more than 10 files show alert message.
    if (pFileList.length > 10 || this.uploadfileArray.length + 1 > 10) {

      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'Please check the number of files. Select 10 or less than 10 files.',
        }
      });


    }
    else
      if ((pFileList.length + this.uploadfileArray.length) > 10) {

        this.dialog.open(AlertdialogComponent, {
          width: '450px',

          data: {
            message: 'Please check the number of files. Total selected files should be less than or equal to 10 files.',
          }
        });


      }
      else {

        this.files = Object.keys(pFileList).map(key => pFileList[key]);
        var isFileSizeUp: boolean = false;
        var isEmptyFile: boolean = false;
        var isNotValidFileType: boolean = false;

        this.files.forEach(element => {
          let fileSize: number;
          fileSize = + this.bytesToMegaBytes(element.size)


          if (fileSize > 100) // // checking the size is more than 100 MB show alert message
          {
            isFileSizeUp = true;
          }
          if (element.size == 0) {
            isEmptyFile = true;
          }


          const fileEntension = element.name.split('.').pop();
          if (this.validFileTypes.indexOf(fileEntension) == -1) // checking filetype  is not proper
          {

            isNotValidFileType = true;
          }
        });

        if (isNotValidFileType) // if File is not proper format showing alert messages
        {
          this.dialog.open(AlertdialogComponent, {
            width: '450px',

            data: {
              message: 'Please upload valid files(txt/xlsx/xls/csv/pdf).',
            }
          });
        }
        else {

          if (isFileSizeUp || isEmptyFile) // If file size is more than 100 MB show alert message and if File also empty showalert 
          {
            if (isFileSizeUp) {
              this.dialog.open(AlertdialogComponent, {
                width: '450px',

                data: {
                  message: 'Please upload less than 100 MB files.',
                }
              });
            }
            else {
              if (isEmptyFile) {
                this.dialog.open(AlertdialogComponent, {
                  width: '450px',

                  data: {
                    message: 'Selected file is blank. Please upload valid file.',
                  }
                });
              }
            }

          }
          else {

            this.isSaveDisabled = false;
            this.files = Object.keys(pFileList).map(key => pFileList[key]);

            if (pFileList.length > 0) {
              this.isfileGrid = true;
            }
            this.files.forEach(element => {

              const evid: any = {
                fileName: element.name,
                fileSize: this.bytesToMegaBytes(element.size),
                fileType: element.type,
                fileStatus: 'SUCCESS'
                //element.fileStatus

              }


              //this.fileArray.push(evid);
              this.uploadfileArray.push(evid);
              //console.log(evid.fileName);
              //this.dataSource = new MatTableDataSource(this.fileArray);
              //this.dataSource.paginator = this.paginator;
              //this.dataSource.sort = this.sort;

              this.selectedFiles.push(<File>element);

            });

            //this.attachment.nativeElement.value = '';
          }
        }
        // this.getRFIDocumntList(this.rfiId);
      }
    this.attachment.nativeElement.value = '';  // after deleting the file and to select the deleted file again.
  }
  clear() {
    this.myControl.reset('');
    this.loadTabs = false;
  }
  removeSelectedFile(index) {
    // Delete the item from fileNames list
    this.uploadfileArray.splice(index, 1);

    // delete file from FileList
    this.selectedFiles.splice(index, 1);
    if (this.uploadfileArray.length == 0) {
      this.isSaveDisabled = true;
    }
  }


  UploadRFDFiles() {
    const formData = new FormData();


    if (this.selectedFiles.length) {
      for (let i = 0; i < this.selectedFiles.length; i++)
        formData.append('File', this.selectedFiles[i]);
    }

    formData.append('RFDId', this.rfi);
    formData.append('RFDOwner', this.commonService.getUserName());
    formData.append('DocumentCategoryId', "1");  // if we are uploading Raw files pass always '1' from this page. for evidence files then 2. 



    this.rfiService.SaveRFDDocuments(formData).subscribe(data => {
      // do something, if upload success

      this.rfiService.getRFIDocumentList(this.rfiId)
          
        .subscribe((data) => {
          this.dataSource = new MatTableDataSource(data);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        });
      this.isSaveDisabled = true;

    }, error => {
      console.log(error);
    });

    this.uploadfileArray = [];
    this.selectedFiles = [];
    this.isSaveDisabled = true;
  }
  
  onChangeTemplate(ob: MatCheckboxChange) {
    if (ob.checked) {
      this.IsTemplateChecked = true;
    }
    else {
      this.IsTemplateChecked = false;
    }
  }

  
  displayRoleMenuPermission() {

    this.userService
      .getMenuPermission(this.commonService.getRoleId(), MenuItems.UseTemplateandFormatData)
      .subscribe((data) => {

        data.forEach(element => {

          if (Permission.View == element.permissionId) {
            this.isshowview = true;
          }
          if (Permission.Save == element.permissionId) {
            this.isshowsave = true;
          }
          if (Permission.Submit == element.permissionId) {
            this.isshowsubmit = true;
          }

          if (Permission.Delete == element.permissionId) {
            this.isshowdelete = true;
          }


          if (Permission.View == element.permissionId) {
            this.israwuploaduserlistshowview = true;
          }
          if (Permission.Save == element.permissionId) {
            this.israwuploaduserlistshowsave = true;
          }
          if (Permission.Submit == element.permissionId) {
            this.israwuploaduserlistshowsubmit = true;
          }

          if (Permission.Upload == element.permissionId) {
            this.israwuploaduserlistshowupload = true;
          }


        });


      });
  }

  
  getActiveTemplate(){
    if (this.applicationId > 0) {
      this.templateService
        .GetAppTemplatesList(this.applicationId)
        .subscribe((data) => {
          this.templatesList = data;
          console.log(data);
          data.forEach(element => {
            if (element.isDefault == true) {
              this.IsTemplateChecked = true;
              this.uploadForm.get('templateInput').setValue(element.description);
            }
          });
        });
    }
  }
  deleteItem(documentId: any) {
    // alert("document "+ documentId + " rfiid " + this.rfiId );
    this.rfiService.deleteRFIDocument(this.rfiId,documentId).subscribe(data => {
      this.rfiService.getRFIDocumentList(this.rfiId).subscribe(data => {
        this.fileArray = [];
        data.forEach(element => {
          const evid: any = {
            fileName: element.fileName,
            fileSize: element.fileSize,
            fileType: element.fileType,
            fileStatus: element.fileStatus,
            documentId : element.documentId,
          }
          this.fileArray.push(evid);
        });
  
        if (this.fileArray.length > 0) {
          this.isfileGrid = true;
          this.dataSource = new MatTableDataSource(this.fileArray);
          this.dataSource.paginator = this.paginator;
          this.dataSource.sort = this.sort;
        }
        else {
          this.isfileGrid = false;
        }
      })

    }, error => {
      console.log(error);
    });
    

   
  }
}
