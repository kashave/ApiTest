import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RfifileuploadComponent } from './rfifileupload.component';

describe('RfifileuploadComponent', () => {
  let component: RfifileuploadComponent;
  let fixture: ComponentFixture<RfifileuploadComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RfifileuploadComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RfifileuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
