import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeelookupComponent } from './employeelookup.component';

describe('EmployeelookupComponent', () => {
  let component: EmployeelookupComponent;
  let fixture: ComponentFixture<EmployeelookupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmployeelookupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeelookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
