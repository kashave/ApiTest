import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { UserService } from 'src/app/services/user.service';
import { Optional,Inject } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SelectionModel } from '@angular/cdk/collections';
import { MatDialogRef } from '@angular/material/dialog';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';

@Component({
  selector: 'app-employeelookup',
  styleUrls: ['employeelookup.component.css'],
  templateUrl: 'employeelookup.component.html',
})

export class EmployeelookupComponent implements OnInit  {
  fName: string;
  lName: string;
  loadData: boolean = true;
  isRow: boolean = true;
  selection = new SelectionModel<any>(false, []);
  hrEmployeeIDFilter= new FormControl('');
  legacyIDFilter= new FormControl('');
  hrFirstNameFilter= new FormControl('');
  hrLastNameFilter= new FormControl('');
  hrMiddleNameFilter= new FormControl('');
  hrHireDateFilter= new FormControl('');
  hrJobFamilyFilter= new FormControl('');
  hrOfficeTitleFilter= new FormControl('');
  hrCenterJobTitleFilter= new FormControl('');
  hrSourceFilter= new FormControl('');
  hrStatusFilter= new FormControl('');
  hrSupervisorIDFilter= new FormControl('');
  hrSupervisorNameFilter= new FormControl('');
  hrTermDateInitiatedFilter= new FormControl('');
  hrTermDateEffectiveFilter= new FormControl('');
  hrEeCategoryFilter= new FormControl('');
  emailAddressFilter= new FormControl('');
  phoneFilter= new FormControl('');
  phoneBusinessExtensionFilter= new FormControl('');
  phoneMobile1Filter= new FormControl('');
  adLogonNameFilter= new FormControl('');
  hrGROUPFilter= new FormControl('');
  hrDivisionFilter= new FormControl('');
  hrBusinessUnitNameFilter= new FormControl('');
  locationNameFilter= new FormControl('');
  locationAddress1Filter= new FormControl('');
  locationStateNameFilter= new FormControl('');
  locationStateProvinceFilter= new FormControl('');
  locationPostalCodeFilter= new FormControl('');
  locationCountryFilter= new FormControl('');
  locationISOCodeFilter= new FormControl('')

  dataSource = new MatTableDataSource();
  columnsToDisplay = ['selected', 'hrEmployeeID' ,  'legacyID' ,  'hrFirstName' ,  'hrLastName' ,'hrMiddleName' ,  'hrHireDate' ,  'hrJobFamily' , 
                      'hrOfficeTitle' , 'hrCenterJobTitle' ,  'hrSource' ,  'hrStatus' ,  'hrSupervisorID' ,  
                      'hrSupervisorName' ,  'hrTermDateInitiated' ,  'hrTermDateEffective' ,
                      'hrEeCategory' ,  'emailAddress' ,  'phone' ,  'phoneBusinessExtension' , 
                      'phoneMobile1' ,  'adLogonName' ,  'hrGROUP' ,  'hrDivision' , 
                      'hrBusinessUnitName' ,  'locationName' ,  'locationAddress1' , 
                      'locationStateName' ,  'locationStateProvince' ,  'locationPostalCode' , 
                      'locationCountry' ,  'locationISOCode'];
  filterValues = {
    hrEmployeeID: '',
    legacyID: '',
    hrFirstName: '',
    hrLastName: '',
    hrMiddleName: '',
    hrHireDate: '',
    hrJobFamily:'',
    hrOfficeTitle:'',
    hrCenterJobTitle:'',hrSource:'',hrStatus:'',hrSupervisorID:'',
    hrSupervisorName:'',hrTermDateInitiated:'',hrTermDateEffective:'',
    hrEeCategory:'',emailAddress:'',phone:'',phoneBusinessExtension:'',
    phoneMobile1:'',adLogonName:'',hrGROUP:'',hrDivision:'',
    hrBusinessUnitName:'',locationName:'',locationAddress1:'',locationStateName:'',
    locationStateProvince:'',locationPostalCode:'',locationCountry:'',locationISOCode:''
  };

  constructor( private userService : UserService,@Optional() @Inject(MAT_DIALOG_DATA) public  data: any, private dialogRef: MatDialogRef<EmployeelookupComponent>,
  private _snackBar: MatSnackBar) 
  {
    this.fName = data.fName;
    this.lName = data.lName;
    this.getWorkDayDetails(this.fName,this.lName);
    this.dataSource.filterPredicate = this.createFilter();
  }

  getSelectedEmployee(){
    if(this.selection.selected.length > 0){
    this.dialogRef.close({ data : this.selection.selected });
    }
    else{
      this._snackBar.open('Select the employee', 'Select', {
        duration: 8000,
        verticalPosition: 'bottom',
      });
    }
  }

  isSelectedRow(){
    if(this.selection.selected.length > 0 ){
      this.isRow = false;
    }
  }

  close(){
    this.dialogRef.close();
  }

  ngOnInit() {
    this.hrEmployeeIDFilter.valueChanges
      .subscribe(
        name => {
          this.filterValues.hrEmployeeID = name;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
    this.legacyIDFilter.valueChanges
      .subscribe(
        id => {
          this.filterValues.legacyID = id;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
    this.hrFirstNameFilter.valueChanges
      .subscribe(
        colour => {
          this.filterValues.hrFirstName = colour;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
    this.hrLastNameFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrLastName = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrMiddleNameFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrMiddleName = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrJobFamilyFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrJobFamily = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrOfficeTitleFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrOfficeTitle = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrCenterJobTitleFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrCenterJobTitle = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrSourceFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrSource = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrStatusFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrStatus = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrSupervisorIDFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrSupervisorID = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrSupervisorNameFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrSupervisorName = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrTermDateInitiatedFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrTermDateInitiated = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.hrTermDateEffectiveFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrTermDateEffective = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.hrEeCategoryFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrEeCategory = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.emailAddressFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.emailAddress = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.phoneFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.phone = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.phoneBusinessExtensionFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.phoneBusinessExtension = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.phoneMobile1Filter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.phoneMobile1 = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.adLogonNameFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.adLogonName = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.hrGROUPFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrGROUP = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.hrDivisionFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrDivision = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.hrBusinessUnitNameFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.hrBusinessUnitName = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.locationNameFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.locationName = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

      this.locationAddress1Filter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.locationAddress1 = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.locationStateNameFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.locationStateName = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.locationStateProvinceFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.locationStateProvince = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.locationPostalCodeFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.locationPostalCode = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.locationCountryFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.locationCountry = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )
      this.locationISOCodeFilter.valueChanges
      .subscribe(
        pet => {
          this.filterValues.locationISOCode = pet;
          this.dataSource.filter = JSON.stringify(this.filterValues);
        }
      )

  }

  createFilter(): (data: any, filter: string) => boolean {
    let filterFunction = function(data, filter): boolean {
      let searchTerms = JSON.parse(filter);
      return (data.hrEmployeeID || '').toString().toLowerCase().indexOf(searchTerms.hrEmployeeID) !== -1
        && (data.legacyID || '').toString().toLowerCase().indexOf(searchTerms.legacyID) !== -1
        && (data.hrFirstName|| '').toLowerCase().indexOf(searchTerms.hrFirstName) !== -1
        && (data.hrLastName|| '').toLowerCase().indexOf(searchTerms.hrLastName) !== -1
        && (data.hrMiddleName || '').toLowerCase().indexOf(searchTerms.hrMiddleName) !== -1 
        && (data.hrHireDate|| '').toString().toLowerCase().indexOf(searchTerms.hrHireDate) !== -1
        && (data.hrJobFamily|| '').toString().toLowerCase().indexOf(searchTerms.hrJobFamily) !== -1
        && (data.hrOfficeTitle || '').toString().toLowerCase().indexOf(searchTerms.hrOfficeTitle) !== -1 
        && (data.hrCenterJobTitle || '').toString().toLowerCase().indexOf(searchTerms.hrCenterJobTitle) !== -1 
        && (data.hrSource || '').toString().toLowerCase().indexOf(searchTerms.hrSource) !== -1 
        && (data.hrStatus || '').toString().toLowerCase().indexOf(searchTerms.hrStatus) !== -1 
        && (data.hrSupervisorID || '').toString().toLowerCase().indexOf(searchTerms.hrSupervisorID) !== -1 
        && (data.hrSupervisorName || '').toString().toLowerCase().indexOf(searchTerms.hrSupervisorName) !== -1 
        && (data.hrTermDateInitiated || '').toString().toLowerCase().indexOf(searchTerms.hrTermDateInitiated) !== -1 
        && (data.hrTermDateEffective || '').toString().toLowerCase().indexOf(searchTerms.hrTermDateEffective) !== -1 
        && (data.hrEeCategory || '').toString().toLowerCase().indexOf(searchTerms.hrEeCategory) !== -1 

        && (data.emailAddress || '').toString().toLowerCase().indexOf(searchTerms.emailAddress) !== -1 
        && (data.phone || '').toString().toLowerCase().indexOf(searchTerms.phone) !== -1 
        && (data.phoneBusinessExtension || '').toString().toLowerCase().indexOf(searchTerms.phoneBusinessExtension) !== -1 
        && (data.phoneMobile1 || '').toString().toLowerCase().indexOf(searchTerms.phoneMobile1) !== -1 
        && (data.adLogonName || '').toString().toLowerCase().indexOf(searchTerms.adLogonName) !== -1 
        && (data.hrGROUP || '').toString().toLowerCase().indexOf(searchTerms.hrGROUP) !== -1 
        && (data.hrDivision || '').toString().toLowerCase().indexOf(searchTerms.hrDivision) !== -1 
        && (data.hrBusinessUnitName || '').toString().toLowerCase().indexOf(searchTerms.hrBusinessUnitName) !== -1 

        && (data.locationName || '').toString().toLowerCase().indexOf(searchTerms.locationName) !== -1 
        && (data.locationAddress1 || '').toString().toLowerCase().indexOf(searchTerms.locationAddress1) !== -1 
        && (data.locationStateName || '').toString().toLowerCase().indexOf(searchTerms.locationStateName) !== -1 
        && (data.locationStateProvince || '').toString().toLowerCase().indexOf(searchTerms.locationStateProvince) !== -1 
        && (data.locationPostalCode || '').toString().toLowerCase().indexOf(searchTerms.locationPostalCode) !== -1 
        && (data.locationCountry || '').toString().toLowerCase().indexOf(searchTerms.locationCountry) !== -1 
        && (data.locationISOCode || '').toString().toLowerCase().indexOf(searchTerms.locationISOCode) !== -1;
    }

    return filterFunction;
  }

  getWorkDayDetails(fName: string, lastName: string){
    this.userService.getWorkDayDetails(fName,lastName).subscribe((data) => {
    if(data.length > 0)
    {
        this.loadData = true;
        this.dataSource.data = data;
    }
    else
    {
        this.loadData = false;
    }
  });

  
}

resetFilter(){
  this.dataSource.filter = '';
  this.hrEmployeeIDFilter.setValue('');
  this.legacyIDFilter.setValue('');
  this.hrFirstNameFilter.setValue('');
  this.hrLastNameFilter.setValue('');
  this.hrMiddleNameFilter.setValue('');
  this.hrHireDateFilter.setValue('');
  this.hrJobFamilyFilter.setValue('');
  this.hrOfficeTitleFilter.setValue('');
  this.hrCenterJobTitleFilter.setValue('');
  this.hrSourceFilter.setValue('');
  this.hrStatusFilter.setValue('');
  this.hrSupervisorIDFilter.setValue('');
  this.hrSupervisorNameFilter.setValue('');
  this.hrTermDateInitiatedFilter.setValue('');
  this.hrTermDateEffectiveFilter.setValue('');
  this.hrEeCategoryFilter.setValue('');
  this.emailAddressFilter.setValue('');
  this.phoneFilter.setValue('');
  this.phoneBusinessExtensionFilter.setValue('');
  this.phoneMobile1Filter.setValue('');
  this.adLogonNameFilter.setValue('');
  this.hrGROUPFilter.setValue('');
  this.hrDivisionFilter.setValue('');
  this.hrBusinessUnitNameFilter.setValue('');
  this.locationNameFilter.setValue('');
  this.locationAddress1Filter.setValue('');
  this.locationStateNameFilter.setValue('');
  this.locationStateProvinceFilter.setValue('');
  this.locationPostalCodeFilter.setValue('');
  this.locationCountryFilter.setValue('');
  this.locationISOCodeFilter.setValue('');
}

}
