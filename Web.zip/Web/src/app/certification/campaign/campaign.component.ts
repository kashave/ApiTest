import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RfipopupComponent } from '../rfipopup/rfipopup.component';


export interface Application {
  name: string;
  id : string;
  owner : string;
  emailid: string;
  status: string;
  select: boolean;
  rfino: string;
  bunit : string;
  dcenter : string;
}

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.css']
})
export class CampaignComponent implements OnInit {
  dataSource: Application[] = [
    {select: true, name: 'Operational Planning', id: "1259", bunit:"High", dcenter:"06/30/2021", owner: "Haddock, John", emailid : "Email Sent", rfino:"RFI-1234567", status: "RFI created"},
    {select: true,name: 'Strategic Planning', id: "1237", bunit:"", dcenter:"06/30/2021", owner: "Jackson, Micheal", emailid : "", rfino:"", status: "RFI not created"},
    {select: false,name: 'Tactical Planning', id: "2762", bunit:"", dcenter:"06/30/2021", owner: "Trump, David", emailid : "", rfino:"",status: "RFI not created"},
    {select: false,name: 'Contingency Planning', id: "2305", bunit:"", dcenter:"06/30/2021", owner: "Deen, Joshua", emailid : "", rfino:"",status: "RFI not created"},
 ];
 displayedColumns: string[] = ['select','rfino','status', 'id', 'name', 'owner', 'bunit','dcenter', 'emailid'];

 email: string;
  constructor(private router: Router, private formBuilder: FormBuilder, public dialog: MatDialog) { }
  tableForm = this.formBuilder.group({
  });

  ngOnInit(): void {
  }

  onFormSubmit() {
    console.log("Submit Clicked");
  }

  openDialog(): void {
    const dialogRef = this.dialog.open(RfipopupComponent, {
      width: '1100px',
      height: '425px',
      data: {}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.email = result;
    });
  }
}
