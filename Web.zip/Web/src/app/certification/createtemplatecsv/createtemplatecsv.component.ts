import { Component, OnInit, ViewChild, Input, ApplicationInitStatus, NgModule, ChangeDetectorRef } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog, MatDialogConfig, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { SelectionModel } from '@angular/cdk/collections';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { TemplateService } from 'src/app/services/template.service';
import { CommonService } from 'src/app/services/common.service';
import { HttpClient } from '@angular/common/http';
import { debug } from 'console';
import { AlertdialogComponent } from 'src/app/modal/alertdialog/alertdialog.component';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { TemplatepopupComponent } from '../templatepopup/templatepopup.component';
import { stringify } from 'querystring';
import { RfiService } from 'src/app/services/rfi.service';
import * as XLSX from 'xlsx';
import { DatePipe } from '@angular/common';
import { MatOption } from '@angular/material/core';
import { MatSort } from '@angular/material/sort';
import { BehaviorSubject, Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { ActivatedRoute } from '@angular/router';
import { setTimeout } from 'timers';

type AOA = any[][];


export interface Application {
  SourceColumn: string;
  DestinationColumn: string;
  ColumnPositionIndex: number;
  RowPosition: number;
  ColumnValueStartPosition: number;
  ColumnValueEndPosition: number;
  ColumnValueLength: number;
  ColumnValueEndPositionTag: string;
  ColumnConstantValue: string;
  SplitColumnValueIndex: number;
  Delimiter: string;
  TabularGroupStartTag: string;
  TabularGroupEndTag: string;
  TabularColumnValuePosition: number;
  IsTabularData: boolean;
  IsGroupHeader: boolean;
  IsRecordStart: boolean;
  IsRecordEnd: boolean;
}

export interface PreviewInt {
  BU: string;
  Asset: string;
  AssetDetail: string;
  AssetNotes: string;
  LastName: string;
  FirstName: string;
  UserId: string;
  Role: string;
  LastLogin: string;
  EmployeeId: string;
  Termdate: string;
  Email: string;
}

export class PreviewClass {
  BU: string;
  Asset: string;
  AssetDetails: string;
  AssetNotes: string;
  LastName: string;
  FirstName: string;
  UserId: string;
  Role: string;
  LastLogin: string;
  EmployeeId: string;
  Termdate: string;
  Email: string;
}

export class PreviewData {
  PreviewClass: PreviewClass[] = [];
}

export class SaveTemplateModel {
  ApplicationId: number;
  TemplateId: number;
  Description: string;
  Details: string;
  DocumentTypeId: number;
  DocumentData: string;
  TemplateTypeId: number;
  UserId: number;
  IsDefault: boolean;
}

export class AppTemplateList {
  applicationId: number;
  templateId: number;
  description: string;
  details: string;
  documentTypeId: number;
  documentData: string;
  templateTypeId: number;
  templateType: string;

}

export class ColumnData {
  ColumnName: string;
  Tag: string;
  ColumnPositionIndex: number;
  ColumnConstantValue: string;
  SplitColumnValueIndex: number;
  Delimiter: string;
  IsRecordStart: boolean = false;
  IsRecordEnd: boolean = false;
}

export class ColumnDataUnstruct {
  ColumnName: string;
  Tag: string;
  ColumnPositionIndex: number;
  RowPosition: number;
  ColumnValueStartPosition: number;
  ColumnValueEndPosition: number;
  ColumnValueLength: number;
  ColumnValueEndPositionTag: string;
  ColumnConstantValue: string;
  SplitColumnValueIndex: number;
  Delimiter: string;
  TabularGroupStartTag: string;
  TabularGroupEndTag: string;
  TabularColumnValuePosition: number;
  IsTabularData: boolean;
  //IsFirstColumn:boolean;
  //IsLastColumn:boolean;
  IsGroupHeader: boolean;
  IsRecordStart: boolean = false;
  IsRecordEnd: boolean = false;
}

export class FileData {
  ApplicationName: string;
  ApplicationId: number;
  TemplateId: number;
  TemplateDescription: string;
  TemplateDetails: string;
  TemplateType: string;
  TemplateTypeId: number;
  Delimiter: string;
  ColumnRowPosition: number;
  DataRowStartPosition: number;
  IgnoreRowsWithTags: string;
  FileFormat: string;
  FileFormatId: string;
}
export class TemplateData {
  FileDetails: FileData;
  ColumnDetails: ColumnData[] = [];
}

export class TemplateDataUnstruct {
  FileDetails: FileData;
  ColumnDetails: ColumnDataUnstruct[] = [];
}

@Component({
  selector: 'app-createtemplatecsv',
  templateUrl: './createtemplatecsv.component.html',
  styleUrls: ['./createtemplatecsv.component.css'],
  providers: [DatePipe]
})
export class CreatetemplatecsvComponent implements OnInit {
  @ViewChild(MatPaginator) paginator: MatPaginator;

  public CHRP: number = 0;
  public DRSP: number = 1;

  myControl = new FormControl();
  filteredOptions: Observable<any[]>;
  userOptions: any[] = [];
  isfileGrid: boolean = false;
  fileArray: any[] = [];
  public openStatus: boolean = true;
  rfi: any;
  loadTabs: boolean = false;
  applicationName: any;
  applicationOwner: any;
  applicationId: number;
  rfiStatus: any;
  tdate = new Date();

  public isFixedLength:boolean = false;
  public isSaveClicked = false;

  public rowDataStart: string = "The number of the row where actual data begins that you want to include in your formatted file.";
  public rowColumnHeaders: string = "Which row contains the Column headers/titles? This allows for quick mapping; if original data doesn’t contain them you should add.";
  public headerPosition: string = "Count the number of values from left to right.  In the example below, LastName is in position 3. 'Type,FirstName,LastName,DisplayName,NTAccountName'";
  public IgnoreRowDataValues: string = "This allows you to not map data that doesn’t need to be in the formatted file.  For example, if every 50 rows there is a cell with ***page break***. You can list those values to be ignored.  These values should be entered separated by commas.";
  public headerValue: string = "Select the field from the original file that identifies the specific column listed above.";
  public ttcreateOrSelectdropdown = "Select Create Template to create new template Or select from existing templates from dropdown.";
  public tttemplateName = "Name the template for an application. Application can have multiple templates created but only one will be active at a time to process uploaded files.";
  public tttemplateDesc = "Provide a description or notes to the new template.";
  public tttemplatetype = "Select correct Template type which matches specific original file like Structured Or Unstructered CSV/TXT/XLS/XLXS files. This is required to correctly map columns.";
  public ttDelimiter = "Define a column separater as provided in original file. For CSV file it will be Comma(,), for Tab delimited file, it will be Tab, etc.";
  public ttSetAsActive = "Set a template as Active. When a file is uploaded, it will use this template for processing. Please note that only one template can be set as active for an application.";
  public ttFileFormat = "For unstructured files, select general for non specific files. For specific files, select Irving, Vanguard Report and Unix Solaris.";

  public ttSelectCheckbox = "Please tick the checkbox to map this column.";
  public ttSelectFromOriginalCheckbox = "Select a column from dropdown to map to sailpoint column. List of columns in dropdown are automatically picked up from original file.";
  public ttConstantValue = "Provide a constant value for selected RFD/Application. BU and Asset columns are automatically filled. Provide a constant value to Asset Detail.";
  public ttSplitColumnIndex = "If a column value on original file needs to be split based on delimiter, provide the word position (from left to right).";
  public ttColumnDelimiter = "If a column value on original file needs to be split, provide the word separator like space, comma, etc. By default it is space. For space, no need to provide value.";
  public ttRowPosition = "Row position of actual column value in relation to the Header value, if it does not occur in the same line, need to specify row position. If column value occurs on the same line as header value, leave row position as 0.";
  public ttValueStartPosition = "Value start position Or relative position to Header value if the Header Value is on the same line.";
  public ttValueEndPosition = "Value end position Or relative position to Header value if the Header value is on the same line.";
  public ttValueLength = "Character length of the value.";
  public ttValueEndPositionTag = "If value end position can be determined by the next Header value/Caption position.";
  public ttIsTabularData = "If data is in Tabular format/list.";
  public ttIsGroupHeader = "If column value itself is grouping column value which contains multiple other column values.";
  public ttIsRecordStart = "This is to mark start of the record. This will be used only for Unstructured files.";
  public ttIsRecordEnd = "This is to mark end of the record. This will be used only for Unstructured files.";
  public ttTabularGroupStartTag = "Specify the group start header value for this column which is present in tabular format data.";
  public ttTabularGroupEndTag = "Specify the group end header value for this column which is present in tabular format data.";
  public ttTabularColumnValuePosition = "Specify the column value position in the tabular data.";


  public showColumnAttributes: boolean = false;
  public selectedColumn: string = "";
  public selectedColumnDSIndex = 0;
  public arrFile: string[] = [];
  public selectedDelimiter: string = ",";
  public selectedFileFormatId: string = "0";

  previewSource: MatTableDataSource<PreviewClass>;

  pageSize = 5;
  customHeight = window.innerWidth < 1440 ? 200 : 320;
  public excelData: AOA = [];
  wopts: XLSX.WritingOptions = { bookType: 'xlsx', type: 'array' };
  public fileName: string = 'SheetJS.xlsx';

  public selectedTabIndex = 0;
  public selectedFileTabIndex = 0;

  public arrColumns: string[] = [];
  public arrCount: number = 0;
  
  public files: any[] = [];
  selectedFiles: any[] = [];
  public validFileTypes: any = ['txt', 'pdf', 'xls', 'xlsx', 'csv', 'TXT', 'PDF', 'XLS', 'XLSX', 'CSV'];

  public viewer: string = 'google';
  public selectedType: string = 'docx';
  //public DemoDoc:string="http://www.africau.edu/images/default/sample.pdf"
  //public DemoDoc:string="https://www.w3.org/WAI/WCAG20/Techniques/working-examples/PDF20/table.pdf"
  public DemoDoc: string = "https://www.w3.org/WAI/WCAG20/Techniques/working-examples/PDF20/table.pdf"

  /*public viewer:string = 'google';  
   public selectedType:string = 'txt';   
   public DemoDoc:string ="https://www.le.ac.uk/oerresources/bdra/html/resources/example.txt"*/

  public appId: number = 0;
  public rfiId: string = "";
  public BUName: string = "";
  public templateId: number;
  public templateTypeId: string = "1";
  public templatesList = [];
  public data;
  public IsStructTemplate: boolean = true;

  public IsDefaultChecked: boolean = false;
  public IsSelectedColumnChecked: boolean = true;

  public templateMode = "Create";
  selectedRowIndex = -1;
  ELEMENT_DATA: Application[] = [
    { SourceColumn: "BU", DestinationColumn: "BU", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.BUName, IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "Asset", DestinationColumn: "Asset", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "Asset", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "Asset Detail", DestinationColumn: "Asset Detail", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "Asset Notes", DestinationColumn: "Asset Notes", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "Last Name", DestinationColumn: "LastName", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "First Name", DestinationColumn: "FirstName", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "UserId", DestinationColumn: "UserId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "Role", DestinationColumn: "Role", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "LastLogin", DestinationColumn: "LastLogin", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "EmployeeId", DestinationColumn: "EmployeeId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "Term Date", DestinationColumn: "Term Date", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
    { SourceColumn: "Email", DestinationColumn: "Email", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false }
  ];
  dataSource = new MatTableDataSource<Application>(this.ELEMENT_DATA)

  /* ELEMENT_PREVIEW_DATA : PreviewClass[] = [
     {BU:"", Asset:"",AssetDetail:"", AssetNotes:"", LastName:"Jackson",FirstName:"Robin",UserId:"RobinJ",Role:"Manager",Status:"",EmployeeId:"", Termdate:"",Email:""},
     {BU:"", Asset:"",AssetDetail:"", AssetNotes:"", LastName:"Hood",FirstName:"Robin",UserId:"RobinH",Role:"Executive",Status:"",EmployeeId:"", Termdate:"",Email:""},
     {BU:"", Asset:"",AssetDetail:"", AssetNotes:"", LastName:"Hudson",FirstName:"David",UserId:"DavidH",Role:"Developer",Status:"",EmployeeId:"", Termdate:"",Email:""},
     {BU:"", Asset:"",AssetDetail:"", AssetNotes:"", LastName:"Thomas",FirstName:"Nick",UserId:"NickT",Role:"Test Executive",Status:"",EmployeeId:"", Termdate:"",Email:""},
     {BU:"", Asset:"",AssetDetail:"", AssetNotes:"", LastName:"Harriet",FirstName:"Nissi",UserId:"NissiH",Role:"Front Office Executive",Status:"",EmployeeId:"", Termdate:"",Email:""}
   ]*/
  displayedColumns: string[] = ['select', 'SourceColumn']; //, 'DestinationColumn', 'ColumnPositionIndex'
  //previewSource = new MatTableDataSource<PreviewInt>(this.ELEMENT_PREVIEW_DATA)

  displayPreviewColumns: string[] = ['BU', 'Asset', 'AssetDetail', 'AssetNotes', 'FirstName', 'LastName', 'UserId', 'Role', 'LastLogin', 'EmployeeId', 'TermDate', 'Email'];

  mandatoryColumns: string[] = ['BU', 'Asset', 'Last Name', 'First Name', 'UserId', 'Role'];

  email: string;
  isSaved: boolean = false;
  fileOutput;

  /* onChange(event) {
   debugger;
   var file = event.target.files[0];
   var reader = new FileReader();

   this.IsStructTemplate = false;
   //this.tableForm.get('SelectTemplateType').setValue("5");
   this.fileOutput = "";

   reader.onload = (e: any) => {
     // The file's text will be printed here
     this.fileOutput = e.target.result;
     this.arrFile = e.target.result.toString().replace(/\r\n/g,'\n').split('\n');
     //for(let i of arr) {
       //console.log(i);
     //}
     let arrstring:string = "";
     debugger;
     if (this.IsStructTemplate) {
     this.arrColumns = this.arrFile[0].split(this.selectedDelimiter);
     if (this.arrColumns.length < 3){
       this.arrColumns = this.arrFile[1].split(this.selectedDelimiter);
       if (this.arrColumns.length < 3){
         this.tableForm.get('templateColumnRowPosition').setValue(2);
         this.tableForm.get('templateDataRowPosition').setValue(3);
       }
     }
     else {
       this.tableForm.get('templateColumnRowPosition').setValue(1);
       this.tableForm.get('templateDataRowPosition').setValue(2);
     }
     //this.arrColumns.splice(this.arrColumns.indexOf(/['"]+/g), 1, '');
     let arrIndex:number = 0;
     this.arrColumns.forEach(element => {
       let astring:string =  element.replace('\"', '');
       astring = astring.replace('\"', '');
       this.arrColumns[arrIndex]= astring;
       arrIndex++;
     });

     //console.log(this.arrColumns);
     this.arrCount = this.arrFile.length;

     let indexarr : number= 0;
     this.arrFile.forEach(element => {
       this.arrFile[indexarr] = this.padLeadingZeros(indexarr+1,5) +" "+ element
       arrstring = arrstring + this.arrFile[indexarr]+"\n";
       indexarr++;
     });
     }
     debugger;
     if (!this.IsStructTemplate && this.selectedFileFormatId == "1"){ //Unix Solaris
       let unixSolarixLine:string = "Username:Password:User ID (UID):Group ID (GID):User ID Info (GECOS):Home Directory:Command/Shell";
       this.arrColumns = unixSolarixLine.split(":");
       this.arrCount = 0;
     }

     this.fileOutput = arrstring;

   };
   
   reader.readAsText(file);
   }*/

  padLeadingZeros(num, size) {
    var s = num + "";
    while (s.length < size) s = " " + s;
    return s;
  }

  constructor(private templateService: TemplateService, private commonService: CommonService, private rfiService: RfiService,
    private http: HttpClient, private router: Router, private formBuilder: FormBuilder, public dialog: MatDialog,
    private datePipe: DatePipe, private route: ActivatedRoute) { }
  tableForm = this.formBuilder.group({
    templateSelects: new FormControl(''),
    defaultCheckbox: new FormControl(''),
    templatetype: new FormControl(''),
    delimiterSelect: new FormControl(''),
    templatename: new FormControl('', [Validators.maxLength(100)]),
    templatedesc: new FormControl('', Validators.maxLength(500)),
    templateColumnRowPosition: new FormControl('', Validators.min(1)),
    templateDataRowPosition: new FormControl('', Validators.min(1)),
    templateIgnoreRowsWithTags: new FormControl(),

    //paneColName : new FormControl(''),
    selectColumnCheckbox: new FormControl(''),
    rawColumnSelects: new FormControl(''),

    fileFormatSelect: new FormControl(''),
    fileFormatSelect2: new FormControl('')
  });

  selection = new SelectionModel<Application>(true, []);

  get f() {
    return this.tableForm.controls;
  }

  async ngOnInit() {
    //this.appId = 0;
    let rfiList = await this.getRFIDetailList();
    if (rfiList) {

      let rfiQueryId = this.route.snapshot.queryParamMap.get('rfiId');
      if (rfiQueryId) {
        this.rfi = rfiQueryId;
        let dataval = this.transform(this.rfi);
        let defSelect = {
          applicationName: dataval[0].applicationName,
          applicationOwner: dataval[0].applicationOwner,
          rfi: dataval[0].rfi,
          rfiId: dataval[0].rfiId,
          applicationId: dataval[0].applicationId,
          rfiStatus: dataval[0].rfiStatus,
          BUName: dataval[0].buname
        }
        this.myControl.setValue(defSelect);
        this.loadTabs = true;
        this.applicationName = defSelect.applicationName;
        this.applicationOwner = defSelect.applicationOwner;
        this.applicationId = defSelect.applicationId;
        this.rfiStatus = defSelect.rfiStatus,
          this.BUName = defSelect.BUName;
        this.rfi = defSelect.rfi;
        this.rfiId = defSelect.rfiId;
        this.commonService.setOption('applicationName', this.applicationName);
        this.commonService.setOption('applicationId', this.applicationId);
        this.commonService.setOption('rfiStatus', this.rfiStatus);
        this.commonService.setOption('buname', this.BUName);
        //this.getRFIDocumntList(this.rfiId);
        //this.getActiveTemplate();
      }
      this.filteredOptions = this.myControl.valueChanges
        .pipe(
        startWith({} as any),
        map(user => user && typeof user === 'object' ? user.applicationName : user),
        map((name: string) => name ? this.transform(name) : this.userOptions.slice())
        );
    }

    this.isSaveClicked = false;
    this.CHRP = 0;
    this.DRSP = 1;
    this.templateTypeId = "1";
    this.dataSource.paginator = this.paginator;
    this.tableForm.get('templateColumnRowPosition').setValue(this.CHRP + 1);
    this.tableForm.get('templateDataRowPosition').setValue(this.DRSP + 1);
    this.tableForm.get('templatetype').setValue("1");
    this.tableForm.get('delimiterSelect').setValue(",");
    this.data = this.commonService.getOption();
    this.isFixedLength = false;
    //this.tableForm.get('appid').setValue(this.data.applicationId);
    this.appId = this.data.applicationId;
    this.rfiId = this.data.rfiId;
    this.BUName = this.data.buname;
    this.templateId = 0;
    if (this.appId > 0) {
      this.templateService
        .GetAppTemplatesList(this.appId)
        .subscribe((data) => {
          this.templatesList = data;
        });
      this.fileOutput = "";
      this.excelData = [];
      if (this.previewSource != null && this.previewSource.data != null){
        this.previewSource.data = [];
      }
    }
    else {
      this.templatesList = [];
    }

    this.tableForm.get('templateSelects').setValue("0");
    this.tableForm.get('templatename').setValue("");
    this.tableForm.get('delimiterSelect').setValue(",");
    this.tableForm.get('templatedesc').setValue("");
    this.tableForm.get('templateIgnoreRowsWithTags').setValue("");
    this.selection.clear();
    this.IsDefaultChecked = false;

    this.dataSource = new MatTableDataSource<Application>(this.ELEMENT_DATA);
    this.selection.clear();
    this.IsStructTemplate = true;
    //this.IsSelectedColumnChecked = true;

    this.dataSource.data.forEach(row => {
      row.DestinationColumn = row.SourceColumn;
      row.ColumnPositionIndex = 0;
      row.RowPosition = 0;
      row.ColumnValueStartPosition = 0;
      row.ColumnValueEndPosition = 0;
      row.ColumnValueLength = 0;
      row.ColumnValueEndPositionTag = "";
      //row.ColumnConstantValue = "";
      row.SplitColumnValueIndex = 0;
      row.Delimiter = "";
      row.TabularGroupStartTag = "";
      row.TabularGroupEndTag = "";
      row.TabularColumnValuePosition = 0;
      row.IsTabularData = false;
      row.IsGroupHeader = false;
    });

    this.dataSource.data[0].ColumnConstantValue = this.BUName;
    this.dataSource.data[1].ColumnConstantValue = this.applicationName;

    this.arrCount = 0;

    this.OnColBtnClick("BU");

    this.selectedTabIndex = 0;
    this.selectedFileTabIndex = 0;

    this.selection.select(this.dataSource.data[0]);
    this.selection.select(this.dataSource.data[1]);
    this.selection.select(this.dataSource.data[2]);
    //this.selectedColumnDSIndex = 0;
    //this.selectedColumn = "BU";
    //this.IsSelectedColumnChecked = true;
    this.selectedFileFormatId = "0";
    this.tableForm.get('fileFormatSelect').setValue(this.selectedFileFormatId);
    this.tableForm.get('fileFormatSelect2').setValue(this.selectedFileFormatId);
  }

  // Populate UI with selected template details
  SelectTemplate(strVal: string) {
    this.isSaveClicked = false;
    if (strVal == "0") // Create template
    {
      this.isFixedLength = false;
      this.templateTypeId = "1";
      this.templateMode = "Create";
      //console.log(this.templateMode);
      this.templateId = 0;
      this.tableForm.get('templateSelects').setValue("0");
      this.tableForm.get('templatename').setValue("");
      this.tableForm.get('delimiterSelect').setValue(",");
      this.tableForm.get('templatedesc').setValue("");
      this.tableForm.get('templateIgnoreRowsWithTags').setValue("");
      this.tableForm.get('templateColumnRowPosition').setValue(this.CHRP + 1);
      this.tableForm.get('templateDataRowPosition').setValue(this.DRSP + 1);
      this.tableForm.get('templatetype').setValue("1");
      this.IsDefaultChecked = false;
      this.fileOutput = "";
      this.excelData = [];

      this.arrCount = 0;
      if (this.previewSource != null && this.previewSource.data != null){
        this.previewSource.data = [];
      }
      this.ELEMENT_DATA = [
        { SourceColumn: "BU", DestinationColumn: "BU", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.BUName, IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset", DestinationColumn: "Asset", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "Asset", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Detail", DestinationColumn: "Asset Detail", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Notes", DestinationColumn: "Asset Notes", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Last Name", DestinationColumn: "LastName", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "First Name", DestinationColumn: "FirstName", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "UserId", DestinationColumn: "UserId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Role", DestinationColumn: "Role", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "LastLogin", DestinationColumn: "LastLogin", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "EmployeeId", DestinationColumn: "EmployeeId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Term Date", DestinationColumn: "Term Date", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Email", DestinationColumn: "Email", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false }
      ];
      this.dataSource = new MatTableDataSource<Application>(this.ELEMENT_DATA)
      this.selectedTabIndex = 0;
      this.selectedFileTabIndex = 0;

      this.selection.clear();
      this.dataSource.data.forEach(row => {
        row.DestinationColumn = row.SourceColumn;
        row.ColumnPositionIndex = 0;
        row.SplitColumnValueIndex = 0;
        row.Delimiter = "";
      });

      this.IsStructTemplate = true;

      this.selection.select(this.dataSource.data[0]);
      this.selection.select(this.dataSource.data[1]);
      this.selection.select(this.dataSource.data[2]);
      this.selectedColumnDSIndex = 0;
      this.selectedColumn = "BU";
      //this.IsSelectedColumnChecked = true;
      this.selectedFileFormatId = "0";
      this.tableForm.get('fileFormatSelect').setValue(this.selectedFileFormatId);
      this.tableForm.get('fileFormatSelect2').setValue(this.selectedFileFormatId);
      this.OnColBtnClick("BU");
    }
    else // Selected existing template
    {
      this.selectedFileTabIndex = 0;
      this.fileOutput = "";
      this.excelData = [];
      if (this.previewSource != null && this.previewSource.data != null){
        this.previewSource.data = [];
      }

      this.arrCount = 0;
      //console.log(this.templatesList);
      this.templateMode = "Update";
      this.templateId = parseInt(strVal);

      this.tableForm.get('delimiterSelect').setValue(",");
      this.tableForm.get('templatename').setValue("");
      this.tableForm.get('templatedesc').setValue("");
      this.tableForm.get('templateIgnoreRowsWithTags').setValue("");
      this.tableForm.get('templateColumnRowPosition').setValue(this.CHRP + 1);
      this.tableForm.get('templateDataRowPosition').setValue(this.DRSP + 1);
      //this.tableForm.get('defaultCheckbox').setValue(0);

      this.selection.clear();
      this.dataSource.data.forEach(row => {
        row.DestinationColumn = row.SourceColumn;
        row.ColumnPositionIndex = 0;
        row.SplitColumnValueIndex = 0;
        row.Delimiter = "";
      });
      this.templatesList.forEach(
        value => {
          if (value["templateId"] === this.templateId) {
            this.tableForm.get('templatename').setValue(value["description"]);
            this.tableForm.get('templatedesc').setValue(value["details"]);
            let ttype: number = value["templateTypeId"];
            this.tableForm.get('templatetype').setValue(ttype.toString());
            this.SelectTemplateType(ttype.toString());
            if (ttype > 4) {
              this.IsStructTemplate = false;
            }
            else {
              this.IsStructTemplate = true;
            }
            this.templateTypeId = ttype.toString();

            let TemplateJson: TemplateData = new TemplateData();
            let TemplateJsonUnStruct: TemplateDataUnstruct = new TemplateDataUnstruct();
            let FileDet: FileData = new FileData();
            let dd: string = value["documentData"];
            let bldefault: boolean = value["isDefault"];
            this.IsDefaultChecked = bldefault;
            TemplateJson = JSON.parse(dd);
            if (!this.IsStructTemplate) {
              TemplateJsonUnStruct = JSON.parse(dd);
            }
            this.tableForm.get('delimiterSelect').setValue(TemplateJson.FileDetails.Delimiter);
            this.selectedDelimiter = TemplateJson.FileDetails.Delimiter;
            this.CHRP = TemplateJson.FileDetails.ColumnRowPosition;
            this.DRSP = TemplateJson.FileDetails.DataRowStartPosition;
            this.tableForm.get('templateColumnRowPosition').setValue(TemplateJson.FileDetails.ColumnRowPosition + 1);
            this.tableForm.get('templateDataRowPosition').setValue(TemplateJson.FileDetails.DataRowStartPosition + 1);
            this.tableForm.get('templateIgnoreRowsWithTags').setValue(TemplateJson.FileDetails.IgnoreRowsWithTags);
            this.selectedFileFormatId = TemplateJson.FileDetails.FileFormatId;
            if (this.selectedFileFormatId.length == 0) {
              this.selectedFileFormatId = "0";
            }
            this.tableForm.get('fileFormatSelect').setValue(this.selectedFileFormatId);
            if (this.templateTypeId == '6' && (this.selectedFileFormatId == '0' || this.selectedFileFormatId == '1')) {
              this.tableForm.get('fileFormatSelect2').setValue(this.selectedFileFormatId);
            }
            debugger;
            if (this.IsStructTemplate) {
              TemplateJson.ColumnDetails.forEach(columnSelected => {
                //columnSelected.ColumnName

                let dsIndex = this.dataSource.data.findIndex(x => x.SourceColumn === columnSelected.ColumnName);
                this.dataSource.data[dsIndex].ColumnPositionIndex = columnSelected.ColumnPositionIndex + 1;
                this.dataSource.data[dsIndex].DestinationColumn = columnSelected.Tag;
                this.dataSource.data[dsIndex].SplitColumnValueIndex = columnSelected.SplitColumnValueIndex + 1;
                this.dataSource.data[dsIndex].Delimiter = columnSelected.Delimiter;
                this.dataSource.data[dsIndex].IsRecordStart = columnSelected.IsRecordStart;
                this.dataSource.data[dsIndex].IsRecordEnd = columnSelected.IsRecordEnd;

                this.dataSource.data[dsIndex].ColumnConstantValue = columnSelected.ColumnConstantValue;

                this.selection.select(this.dataSource.data[dsIndex]);
              });
            }
            if (!this.IsStructTemplate) {
              TemplateJsonUnStruct.ColumnDetails.forEach(columnSelected => {
                //columnSelected.ColumnName

                let dsIndex = this.dataSource.data.findIndex(x => x.SourceColumn === columnSelected.ColumnName);
                this.dataSource.data[dsIndex].ColumnPositionIndex = columnSelected.ColumnPositionIndex + 1;
                this.dataSource.data[dsIndex].DestinationColumn = columnSelected.Tag;
                this.dataSource.data[dsIndex].RowPosition = columnSelected.RowPosition;
                this.dataSource.data[dsIndex].ColumnValueStartPosition = columnSelected.ColumnValueStartPosition + 1;
                this.dataSource.data[dsIndex].ColumnValueEndPosition = columnSelected.ColumnValueEndPosition + 1;
                this.dataSource.data[dsIndex].ColumnValueLength = columnSelected.ColumnValueLength;
                this.dataSource.data[dsIndex].ColumnValueEndPositionTag = columnSelected.ColumnValueEndPositionTag;
                this.dataSource.data[dsIndex].ColumnConstantValue = columnSelected.ColumnConstantValue;
                this.dataSource.data[dsIndex].SplitColumnValueIndex = columnSelected.SplitColumnValueIndex + 1;
                this.dataSource.data[dsIndex].Delimiter = columnSelected.Delimiter;
                this.dataSource.data[dsIndex].TabularGroupStartTag = columnSelected.TabularGroupStartTag;
                this.dataSource.data[dsIndex].TabularGroupEndTag = columnSelected.TabularGroupEndTag;
                this.dataSource.data[dsIndex].TabularColumnValuePosition = columnSelected.TabularColumnValuePosition + 1;
                this.dataSource.data[dsIndex].IsTabularData = columnSelected.IsTabularData;
                this.dataSource.data[dsIndex].IsGroupHeader = columnSelected.IsGroupHeader;
                this.dataSource.data[dsIndex].IsRecordStart = columnSelected.IsRecordStart;
                this.dataSource.data[dsIndex].IsRecordEnd = columnSelected.IsRecordEnd;

                this.selection.select(this.dataSource.data[dsIndex]);
                if (columnSelected.ColumnName == "UserId" && columnSelected.Tag.toLowerCase() == "fixedlength"){
                  this.isFixedLength = true;
                }
              });
            }
          }
        });
      this.OnColBtnClick("BU");
    }
  }

  get columns(): FormArray {
    return this.tableForm.get('columns') as FormArray;
  }

  // On user change I clear the title of that album 
  onUserChange(event, column: FormGroup) {
    const DestinationColumn = column.get('DestinationColumn');

    DestinationColumn.setValue(null);
    DestinationColumn.markAsUntouched();
    // Notice the ngIf at the title cell definition. The user with id 3 can't set the title of the albums
  }

  onFormSubmit() {
    //console.log("Submit Clicked");
  }

  /** Whether the number of selected elements matches the total number of rows. */
  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
  }

  isSelectedPage() {
    const numSelected = this.selection.selected.length;
    //const page = this.dataSource.paginator.pageSize;
    let endIndex: number;
    // First check whether data source length is greater than current page index multiply by page size.
    // If yes then endIdex will be current page index multiply by page size.
    // If not then select the remaining elements in current page only.
    if (this.dataSource.data.length > (this.dataSource.paginator.pageIndex + 1) * this.dataSource.paginator.pageSize) {
      endIndex = (this.dataSource.paginator.pageIndex + 1) * this.dataSource.paginator.pageSize;
    } else {
      // tslint:disable-next-line:max-line-length
      endIndex = this.dataSource.data.length - (this.dataSource.paginator.pageIndex * this.dataSource.paginator.pageSize);
    }
    //console.log(endIndex);
    return numSelected === endIndex;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected() ?
      this.selection.clear() :
      this.dataSource.data.forEach(row => this.selection.select(row));
  }
  selectRows() {
    // tslint:disable-next-line:max-line-length
    let endIndex: number;
    // tslint:disable-next-line:max-line-length
    if (this.dataSource.data.length > (this.dataSource.paginator.pageIndex + 1) * this.dataSource.paginator.pageSize) {
      endIndex = (this.dataSource.paginator.pageIndex + 1) * this.dataSource.paginator.pageSize;
    } else {
      // tslint:disable-next-line:max-line-length
      endIndex = this.dataSource.data.length;
    }

    for (let index = (this.dataSource.paginator.pageIndex * this.dataSource.paginator.pageSize); index < endIndex; index++) {
      this.selection.select(this.dataSource[index]);
    }
  }

  // Save Template - Create Or Update Template
  SaveTemplate() {
    this.isSaved = true;

    if (this.tableForm.invalid) {
      return;
    }

    if (!this.selection.hasValue()) {
      return;
    }
    let blmandatoryColumns: boolean = true;
    let strmandatoryColumns: string = ' - ';
    for (let i = 0; i < this.mandatoryColumns.length; i++) {
      if (this.selection.selected.findIndex(val => val.SourceColumn == this.mandatoryColumns[i]) < 0) {
        blmandatoryColumns = false;
        strmandatoryColumns += this.mandatoryColumns[i] + ', ';
      }
    }
    if (strmandatoryColumns.length > 0) {
      strmandatoryColumns = strmandatoryColumns.substring(1, strmandatoryColumns.length - 2);
    }

    let tname: string = this.tableForm.get('templatename').value;
    if (tname.trim().length == 0) {
      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'Please provide template name',
        }
      });
      this.selectedTabIndex = 0;
      return;
    }

    if (!blmandatoryColumns) {
      //alert('Template Name already exists.');
      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'Please select the checkbox and fill the mapping details for the following mandatory columns:\n' + strmandatoryColumns,
        }
      });
      return;
    }

    let blColumnPositionIndex: boolean = false;
    for (let i = 0; i < this.selection.selected.length; i++) {
      if (this.selection.selected[i].ColumnPositionIndex == 0 && this.IsStructTemplate) {
        if (this.selection.selected[i].SourceColumn != "BU" && this.selection.selected[i].SourceColumn != "Asset" && this.selection.selected[i].SourceColumn != "Asset Detail") {
          blColumnPositionIndex = true;
        }
        break;
      }
    }
    //debugger;
    let blConstantValueEmpty: boolean = false;
    for (let i = 0; i < this.selection.selected.length; i++) {
      if (this.selection.selected[i].ColumnConstantValue != null && this.selection.selected[i].ColumnConstantValue.length == 0 && (this.selection.selected[i].SourceColumn == "BU" || this.selection.selected[i].SourceColumn == "Asset")) {
        blConstantValueEmpty = true;
        break;
      }
    }

    let bldesColumnEmpty: boolean = false;
    for (let i = 0; i < this.selection.selected.length; i++) {
      if (this.selection.selected[i].DestinationColumn.length == 0) {
        bldesColumnEmpty = true;
        break;
      }
    }
    let bldesColumnDuplicates: boolean = false;
    let rawColumns: string[] = new Array();
    for (let i = 0; i < this.selection.selected.length; i++) {
      if (rawColumns != null && rawColumns.length > 0 && rawColumns.indexOf(this.selection.selected[i].DestinationColumn) > -1) {
        bldesColumnDuplicates = true;
        break;
      }
      else {
        if (this.selection.selected[i].SourceColumn != "BU" && this.selection.selected[i].SourceColumn != "Asset" && this.selection.selected[i].SourceColumn != "Asset Detail") {
          rawColumns.push(this.selection.selected[i].DestinationColumn);
        }
      }
    }
    let blColumnPosDuplicates: boolean = false;
    let rawColumnPositions: string[] = new Array();
    for (let i = 0; i < this.selection.selected.length; i++) {

      if (rawColumnPositions != null && rawColumnPositions.length > 0 && rawColumnPositions.indexOf(this.selection.selected[i].ColumnPositionIndex.toString()) > -1) {
        blColumnPosDuplicates = true;
        break;
      }
      else {
        if (this.selection.selected[i].SourceColumn != "BU" && this.selection.selected[i].SourceColumn != "Asset" && this.selection.selected[i].SourceColumn != "Asset Detail") {
          rawColumnPositions.push(this.selection.selected[i].ColumnPositionIndex.toString());
        }
      }
    }

    let blTemplateExists: boolean = false;
    // Check duplicate template name for existing template
    if (this.templateId > 0) {
      blTemplateExists = false;
      this.templatesList.forEach(
        value => {
          if (value["description"] === tname && value["templateId"] != this.templateId) {
            blTemplateExists = true;
          }
        }
      )
    }
    // Check duplicate template name for new template
    else {
      blTemplateExists = false;
      this.templatesList.forEach(
        value => {
          if (value["description"] === tname) {
            blTemplateExists = true;
          }
        }
      )
    }
    if (blTemplateExists) {
      //alert('Template Name already exists.');
      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'Template Name already exists.',
        }
      });
      return;
    }

    if (blConstantValueEmpty) {
      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'BU and Asset column constant values cannot be blank.',
        }
      });
      return;
    }

    let colposRow: string = this.tableForm.get('templateColumnRowPosition').value;
    let dataposRow: string = this.tableForm.get('templateDataRowPosition').value;

    if (parseInt(colposRow) >= parseInt(dataposRow)) {
      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'Column Row Position cannot be greater than or equal to Data Row Position.',
        }
      });
      return;
    }

    if (blColumnPositionIndex && this.IsStructTemplate) {
      //alert('Column Position Index cannot be 0 for selected columns.');
      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'Column Position Index cannot be 0 for selected columns.',
        }
      });
      return;
    }

    if (bldesColumnEmpty) {
      this.dialog.open(AlertdialogComponent, {
        width: '450px',

        data: {
          message: 'Selected Raw File Column name cannot be blank.',
        }
      });
      return;
    }

    /*
    if (bldesColumnDuplicates && this.IsStructTemplate){
      this.dialog.open(AlertdialogComponent, {
        width: '450px',
        
        data: {
          message: 'Selected Raw File Column names cannot be duplicate.',
        }
      });
      return;
    }
  
    if (blColumnPosDuplicates && this.IsStructTemplate){
      this.dialog.open(AlertdialogComponent, {
        width: '450px',
        
        data: {
          message: 'Selected Raw File Columns position cannot be duplicate.',
        }
      });
      return;
    }*/
    let TemplateJson: TemplateData = new TemplateData();
    let FileDet: FileData = new FileData();
    FileDet.ApplicationName = this.applicationName;
    FileDet.ApplicationId = this.appId;
    FileDet.TemplateId = this.templateId;
    FileDet.TemplateDescription = this.tableForm.get('templatename').value;
    FileDet.TemplateDetails = this.tableForm.get('templatedesc').value;
    FileDet.TemplateType = this.tableForm.get('templatetype').value; //???
    FileDet.Delimiter = this.selectedDelimiter; //this.tableForm.get('delimiterSelect').value;
    FileDet.TemplateTypeId = parseInt(this.tableForm.get('templatetype').value);
    FileDet.ColumnRowPosition = this.tableForm.get('templateColumnRowPosition').value - 1;
    FileDet.DataRowStartPosition = this.tableForm.get('templateDataRowPosition').value - 1;
    FileDet.IgnoreRowsWithTags = this.tableForm.get('templateIgnoreRowsWithTags').value;
    FileDet.FileFormat = "General";
    FileDet.FileFormatId = "0";
    if (this.selectedFileFormatId == "1" && this.templateTypeId == '5') {
      FileDet.FileFormat = "Unix Solaris";
      FileDet.FileFormatId = "1";
    }
    if (this.selectedFileFormatId == "2" && this.templateTypeId == '5') {
      FileDet.FileFormat = "Vanguard Report";
      FileDet.FileFormatId = "2";
    }
    if (this.selectedFileFormatId == "1" && this.templateTypeId == '6') {
      FileDet.FileFormat = "Irving Report";
      FileDet.FileFormatId = "1";
    }
    let i: number;
    let ColumnD: ColumnData;
    for (i = 0; i < this.selection.selected.length; i++) {
      ColumnD = new ColumnData();
      ColumnD.ColumnName = this.selection.selected[i].SourceColumn;
      ColumnD.Tag = this.selection.selected[i].DestinationColumn;
      ColumnD.ColumnPositionIndex = this.selection.selected[i].ColumnPositionIndex - 1;
      let is: number = 0;
      let dsindex: number = 0;
      this.dataSource.data.forEach(row => {
        if (row.SourceColumn == ColumnD.ColumnName) {
          dsindex = is;
        }
        is++;
      });
      ColumnD.SplitColumnValueIndex = this.dataSource.data[dsindex].SplitColumnValueIndex - 1;
      ColumnD.Delimiter = this.dataSource.data[dsindex].Delimiter;
      ColumnD.IsRecordStart = this.dataSource.data[dsindex].IsRecordStart;
      ColumnD.IsRecordEnd = this.dataSource.data[dsindex].IsRecordEnd;
      if (this.selection.selected[i].SourceColumn == "BU") {
        ColumnD.ColumnConstantValue = this.dataSource.data[0].ColumnConstantValue;
      }
      if (this.selection.selected[i].SourceColumn == "Asset") {
        ColumnD.ColumnConstantValue = this.dataSource.data[1].ColumnConstantValue;
      }
      if (this.selection.selected[i].SourceColumn == "Asset Detail") {
        ColumnD.ColumnConstantValue = this.dataSource.data[2].ColumnConstantValue;
      }
      TemplateJson.FileDetails = FileDet;
      TemplateJson.ColumnDetails.push(ColumnD);
    }
    let TemplateJsonUnstruct: TemplateDataUnstruct = new TemplateDataUnstruct();
    let iu: number;
    let ColumnDU: ColumnDataUnstruct;
    for (i = 0; i < this.selection.selected.length; i++) {
      ColumnDU = new ColumnDataUnstruct();
      ColumnDU.ColumnName = this.selection.selected[i].SourceColumn;
      ColumnDU.Tag = this.selection.selected[i].DestinationColumn;
      ColumnDU.ColumnPositionIndex = this.selection.selected[i].ColumnPositionIndex - 1;

      let iu: number = 0;
      let ddindex: number = 0;
      this.dataSource.data.forEach(row => {
        if (row.SourceColumn == ColumnDU.ColumnName) {
          ddindex = iu;
        }
        iu++;
      });

      ColumnDU.RowPosition = this.dataSource.data[ddindex].RowPosition;
      ColumnDU.ColumnValueStartPosition = this.dataSource.data[ddindex].ColumnValueStartPosition - 1;
      ColumnDU.ColumnValueEndPosition = this.dataSource.data[ddindex].ColumnValueEndPosition - 1;
      ColumnDU.ColumnValueLength = this.dataSource.data[ddindex].ColumnValueLength;
      ColumnDU.ColumnValueEndPositionTag = this.dataSource.data[ddindex].ColumnValueEndPositionTag;
      ColumnDU.ColumnConstantValue = this.dataSource.data[ddindex].ColumnConstantValue;
      ColumnDU.SplitColumnValueIndex = this.dataSource.data[ddindex].SplitColumnValueIndex - 1;
      ColumnDU.Delimiter = this.dataSource.data[ddindex].Delimiter;
      ColumnDU.TabularGroupStartTag = this.dataSource.data[ddindex].TabularGroupStartTag;
      ColumnDU.TabularGroupEndTag = this.dataSource.data[ddindex].TabularGroupEndTag;
      ColumnDU.TabularColumnValuePosition = this.dataSource.data[ddindex].TabularColumnValuePosition - 1;
      ColumnDU.IsTabularData = this.dataSource.data[ddindex].IsTabularData;
      ColumnDU.IsGroupHeader = this.dataSource.data[ddindex].IsGroupHeader;
      ColumnDU.IsRecordStart = this.dataSource.data[ddindex].IsRecordStart;
      ColumnDU.IsRecordEnd = this.dataSource.data[ddindex].IsRecordEnd;

      TemplateJsonUnstruct.FileDetails = FileDet;
      TemplateJsonUnstruct.ColumnDetails.push(ColumnDU);
    }
    //console.log(TemplateJson);
    var saveModel: SaveTemplateModel = new SaveTemplateModel();
    saveModel.ApplicationId = this.appId;
    saveModel.TemplateId = this.templateId;
    saveModel.Description = FileDet.TemplateDescription;
    saveModel.Details = FileDet.TemplateDetails;
    saveModel.DocumentTypeId = 3;
    saveModel.TemplateTypeId = FileDet.TemplateTypeId;
    saveModel.DocumentData = JSON.stringify(TemplateJson);
    if (!this.IsStructTemplate) {
      saveModel.DocumentData = JSON.stringify(TemplateJsonUnstruct);
    }
    saveModel.UserId = this.commonService.getUserId();
    saveModel.IsDefault = this.IsDefaultChecked;

    console.log(saveModel);

    let successMsg: string = "Template Saved Successfully.\n";
    if (this.selectedFiles.length == 0) {
      successMsg = successMsg + "Please upload a file to preview processed data."
    }

    this.templateService
      .CreateUpdateTemplate(saveModel)
      .subscribe(
      res => {
        this.templateId = res;
        //alert('Template Saved Successfully.');
        this.dialog.open(AlertdialogComponent, {
          width: '450px',

          data: {
            message: successMsg,
          }
        });
        /*
        this.dataSource.data.forEach( row => {
          row.DestinationColumn = row.SourceColumn;
          row.ColumnPositionIndex = 0;
          row.RowPosition = 0;
          row.ColumnValueStartPosition = 0;
          row.ColumnValueEndPosition = 0;
          row.ColumnValueLength = 0;
          row.ColumnValueEndPositionTag = "";
          row.SplitColumnValueIndex = 0;
          row.Delimiter = "";
          row.TabularGroupStartTag = "";
          row.TabularGroupEndTag = "";
          row.TabularColumnValuePosition = 0;
          row.IsTabularData = false;
          row.IsGroupHeader = false;
        });*/
        //this.ngOnInit();
        /*
        if (this.selectedFiles.length == 0){
          this.dialog.open(AlertdialogComponent, {
            width: '450px',
            
            data: {
              message: 'Please upload a file to preview processed data.',
            }
          });
        }*/

        //Preview - Only for Unstructured Raw files
        if (this.appId > 0) { // && !this.IsStructTemplate
          this.templateService
            .GetAppTemplatesList(this.appId)
            .subscribe((data) => {
              this.templatesList = data;
            });
          //this.tableForm.get('templateSelects').setValue(this.templateId.toString());
          let tname: string = this.tableForm.get('templatename').value;
          /*this.templatesList.forEach(
            value => {
              debugger;
              if (value["description"] === tname) {
                  ttemplateid =value["templateId"];*/

          let stringFilename: string = this.selectedFiles[0].name;
          if (this.templateId > 0 && stringFilename.length > 0) {
            this.templateService
              .ParseFileToJson(this.appId, this.templateId, stringFilename)
              .subscribe((data) => {
                let PreviewJson: PreviewData = new PreviewData();
                let prevD: PreviewClass;
                data.UserData.slice(0,100).forEach(element => {
                  prevD = new PreviewClass();
                  prevD.BU = element.BU;
                  prevD.Asset = element.Asset;
                  prevD.AssetDetails = element.AssetDetails;
                  prevD.AssetNotes = element.AssetNotes;
                  prevD.FirstName = element.FirstName;
                  prevD.LastName = element.LastName;
                  prevD.UserId = element.UserName;
                  prevD.Role = element.Role;
                  prevD.Termdate = element.TermDate;
                  prevD.LastLogin = element.LastLogin;
                  prevD.Email = element.Email;
                  prevD.EmployeeId = element.EmployeeId;
                  PreviewJson.PreviewClass.push(prevD);
                 });
                this.previewSource = new MatTableDataSource<PreviewClass>(PreviewJson.PreviewClass);
              });
          }
        }

        //Preview - Only for structured files
        /*if (this.IsStructTemplate){
          this.PreviewProcessedData();
          this.templateService
          .GetAppTemplatesList(this.appId)
          .subscribe((data) => {
            this.templatesList = data;
          });
        }*/

        //this.selectedTabIndex = 0;
        this.selectedFileTabIndex = 1;
        this.isSaveClicked = true;
      }
      );

  }

  /*highlight(row){
   //this.selectedRowIndex = row.id;
  }*/

  UpdateDes(strVal: string) {
    this.dataSource.data[this.selectedColumnDSIndex].DestinationColumn = strVal;
  }

  selectRawColumns(strVal: string) {
    let i: number = this.selectedColumnDSIndex;
    this.dataSource.data[i].DestinationColumn = strVal;
    if (this.arrColumns.length > 0) {
      let indx: number = this.arrColumns.findIndex(x => x === strVal);
      this.dataSource.data[i].ColumnPositionIndex = indx + 1;
    }
  }

  /*UpdateColumnPos(i:number, intVal:number){
   this.dataSource.data[i].ColumnPositionIndex = intVal;
  }*/

  onKeyPress(event: any) {
    const regexpNumber = /([0-9]|1[0-2])/;
    let inputCharacter = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !regexpNumber.test(inputCharacter)) {
      event.preventDefault();
    }
  }

  onKeyPressNegative(event: any) {
    const regexpNumber = /(-|[0-9]|1[0-2])/;
    let inputCharacter = String.fromCharCode(event.charCode);
    if (event.keyCode != 8 && !regexpNumber.test(inputCharacter)) {
      event.preventDefault();
    }
  }

  CancelTemplate() {
    this.templateId = 0;
    this.SelectTemplate("0");
    //this.ngOnInit();
    this.IsStructTemplate = true;
    if (this.previewSource != null && this.previewSource.data != null){
      this.previewSource.data = [];
    }
  }

  StepBack() {
    this.selectedTabIndex = 0;
    //this.PreviewProcessedData();
  }

  keyPressAlphaNumeric(event) {

    var inp = String.fromCharCode(event.keyCode);

    if (/[a-zA-Z0-9_ ]/.test(inp)) {
      return true;
    } else {
      event.preventDefault();
      return false;
    }
  }

  onChangeDefault(ob: MatCheckboxChange) {
    this.IsDefaultChecked = ob.checked;
  }

  openHelpDialog(): void {

    /*let isSelected:boolean = false;
    for (let i = 0; i < this.selection.selected.length; i++) {
      if (this.selection.selected[i].SourceColumn == pColumnName){
        isSelected = true;
      }
    }
  
    if (!isSelected){
      this.dialog.open(AlertdialogComponent, {
        width: '450px',
        
        data: {
          message: 'Please select/check the column before entering column attributes.',
        }
      });
      return;
    }*/

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.autoFocus = true;

    dialogConfig.width = "500px";
    

    /*
    let selectedrow:Application;
    this.dataSource.data.forEach( row => {
     if (row.SourceColumn == pColumnName){
      selectedrow = row;
     }
    });
  
    dialogConfig.data = {
        pIsStructTemplate:this.IsStructTemplate,
        pColumnName:pColumnName,
        pcolData: selectedrow,
        parrColumns : this.arrColumns
    };*/
    //this.dialog.open(TemplatepopupComponent, dialogConfig);
    let dialogRef = this.dialog.open(TemplatepopupComponent); //, dialogConfig

    let i: number = 0;
    dialogRef.afterClosed().subscribe(
      /*value => {
      
      this.dataSource.data.forEach( row => {
        if (row.SourceColumn == pColumnName){
          if (value != ""){
            this.dataSource.data[i] = value;
          }
        }
        i++;
       });
      //console.log(this.dataSource.data);
    }*/
    );
  }

  SelectTemplateType(strVal: string) {
    this.templateTypeId = strVal;
    if (parseInt(strVal) > 4) {
      this.IsStructTemplate = false;
      this.tableForm.get('delimiterSelect').setValue("NA");
      this.selectedDelimiter = "NA";
      this.tableForm.get('templateIgnoreRowsWithTags').setValue("");
      this.ResetELEMENT_DATA();
    }
    else {
      this.IsStructTemplate = true;
      this.tableForm.get('delimiterSelect').setValue(",");
      this.selectedDelimiter = ",";
      if (parseInt(strVal) == 3){
        this.tableForm.get('delimiterSelect').setValue("NA");
        this.selectedDelimiter = "NA";
      }
      if (parseInt(strVal) == 4) {
        this.tableForm.get('delimiterSelect').setValue(" ");
        this.selectedDelimiter = " ";
      }
      this.ResetELEMENT_DATA();
    }
  }

  OnColBtnClick(strVal: string) {
    debugger;
    strVal.replace('*', '');
    this.showColumnAttributes = true;
    this.selectedColumn = strVal;
    this.tableForm.get('rawColumnSelects').setValue("0");

    let dsIndex = this.dataSource.data.findIndex(x => x.SourceColumn === this.selectedColumn);
    this.selectedColumnDSIndex = dsIndex;
    let IsSelected: boolean = false;
    for (let i: number = 0; i < this.selection.selected.length; i++) {
      if (this.selection.selected[i].SourceColumn == strVal) {
        IsSelected = true;
      }
    }
    this.IsSelectedColumnChecked = IsSelected;
  }

  onChangeColumnSelected(ob: MatCheckboxChange) {
    let dsIndex = this.dataSource.data.findIndex(x => x.SourceColumn === this.selectedColumn);
    this.selectedColumnDSIndex = dsIndex;

    if (ob.checked) {
      this.selection.select(this.dataSource.data[dsIndex]);
      //Put your code here to populate Column attributes.
      this.IsSelectedColumnChecked = true;
    }
    else {
      if (this.selectedColumn != "BU" && this.selectedColumn != "Asset") {
        this.selection.toggle(this.dataSource.data[dsIndex]);
        this.IsSelectedColumnChecked = false;
      }
      else {
        this.IsSelectedColumnChecked = true;
      }
    }
  }

  Updatecvendpostag(strVal: string) {
    this.dataSource.data[this.selectedColumnDSIndex].ColumnValueEndPositionTag = strVal;
  }

  Updateconstantval(strVal: string) {
    this.dataSource.data[this.selectedColumnDSIndex].ColumnConstantValue = strVal;
    if (this.dataSource.data[this.selectedColumnDSIndex].SourceColumn == "BU") {
      this.BUName = strVal;
    }
  }

  Updatedelimiter(strVal: string) {
    this.dataSource.data[this.selectedColumnDSIndex].Delimiter = strVal;
  }

  Updatefiledelimiter(strVal: string) {
    this.selectedDelimiter = strVal;
  }

  ResetELEMENT_DATA() {
    //this.tableForm.get('delimiterSelect').setValue(",");
    //this.selectedDelimiter = ",";
    this.tableForm.get('templateIgnoreRowsWithTags').setValue("");
    this.ELEMENT_DATA = [
      { SourceColumn: "BU", DestinationColumn: "BU", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.BUName, IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "Asset", DestinationColumn: "Asset", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.applicationName, IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "Asset Detail", DestinationColumn: "Asset Detail", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "Asset Notes", DestinationColumn: "Asset Notes", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "Last Name", DestinationColumn: "LastName", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "First Name", DestinationColumn: "FirstName", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "UserId", DestinationColumn: "UserId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "Role", DestinationColumn: "Role", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "LastLogin", DestinationColumn: "LastLogin", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "EmployeeId", DestinationColumn: "EmployeeId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "Term Date", DestinationColumn: "Term Date", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
      { SourceColumn: "Email", DestinationColumn: "Email", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false }
    ];
    this.dataSource = new MatTableDataSource<Application>(this.ELEMENT_DATA)
    this.arrColumns = null;
    this.arrCount = 0;
    this.selection.clear();
    this.selection.select(this.dataSource.data[0]);
    this.selection.select(this.dataSource.data[1]);
    this.selection.select(this.dataSource.data[2]);
  }

  Updatefileformat2(strVal: string) {
    this.selectedFileFormatId = strVal;
    if (this.selectedFileFormatId == "0") { // General
      this.ResetELEMENT_DATA();
    }

    if (this.selectedFileFormatId == "1") { // Irving
      this.ResetELEMENT_DATA();
      this.tableForm.get('delimiterSelect').setValue("NA");
      this.selectedDelimiter = "NA";
      this.tableForm.get('templateIgnoreRowsWithTags').setValue("Page");

      this.ELEMENT_DATA = [
        { SourceColumn: "BU", DestinationColumn: "BU", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.BUName, IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset", DestinationColumn: "Asset", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.applicationName, IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Detail", DestinationColumn: "Asset Detail", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Notes", DestinationColumn: "Asset Notes", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Last Name", DestinationColumn: "General Information", ColumnPositionIndex: 0, RowPosition: -1, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 1, Delimiter: ",", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "First Name", DestinationColumn: "General Information", ColumnPositionIndex: 0, RowPosition: -1, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 2, Delimiter: ",", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "UserId", DestinationColumn: "ID:", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Role", DestinationColumn: "Access Level", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 20, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "Access Level Information", TabularGroupEndTag: "Custom Field Information", TabularColumnValuePosition: 2, IsTabularData: true, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "LastLogin", DestinationColumn: "LastLogin", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "EmployeeId", DestinationColumn: "EmployeeId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Term Date", DestinationColumn: "Term Date", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Email", DestinationColumn: "Email", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false }
      ];
      this.dataSource = new MatTableDataSource<Application>(this.ELEMENT_DATA)
      this.arrColumns = null;
      this.arrCount = 0;
      this.selection.clear();
      this.selection.select(this.dataSource.data[0]);
      this.selection.select(this.dataSource.data[1]);
      this.selection.select(this.dataSource.data[2]);
      this.selection.select(this.dataSource.data[4]);
      this.selection.select(this.dataSource.data[5]);
      this.selection.select(this.dataSource.data[6]);
      this.selection.select(this.dataSource.data[7]);
    }

  }

  Updatefileformat(strVal: string) {
    this.selectedFileFormatId = strVal;
    //debugger;
    if (this.selectedFileFormatId == "1") { //Unix Solaris
      this.ResetELEMENT_DATA();

      this.tableForm.get('delimiterSelect').setValue(":");
      this.selectedDelimiter = ":";
      this.tableForm.get('templateIgnoreRowsWithTags').setValue("");
      let unixSolarixLine: string = "Username:Password:User ID (UID):Group ID (GID):User ID Info (GECOS):Home Directory:Command/Shell";
      this.arrColumns = unixSolarixLine.split(":");
      this.arrCount = 0;


      this.ELEMENT_DATA = [
        { SourceColumn: "BU", DestinationColumn: "BU", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.BUName, IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset", DestinationColumn: "Asset", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.applicationName, IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Detail", DestinationColumn: "Asset Detail", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Notes", DestinationColumn: "Asset Notes", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Last Name", DestinationColumn: "User ID Info (GECOS)", ColumnPositionIndex: 5, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 2, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "First Name", DestinationColumn: "User ID Info (GECOS)", ColumnPositionIndex: 5, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 1, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "UserId", DestinationColumn: "Username", ColumnPositionIndex: 1, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Role", DestinationColumn: "Home Directory", ColumnPositionIndex: 7, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "LastLogin", DestinationColumn: "LastLogin", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "EmployeeId", DestinationColumn: "EmployeeId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Term Date", DestinationColumn: "Term Date", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Email", DestinationColumn: "Email", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false }
      ];
      this.dataSource = new MatTableDataSource<Application>(this.ELEMENT_DATA)

      this.selection.clear();
      this.selection.select(this.dataSource.data[0]);
      this.selection.select(this.dataSource.data[1]);
      this.selection.select(this.dataSource.data[2]);
      this.selection.select(this.dataSource.data[4]);
      this.selection.select(this.dataSource.data[5]);
      this.selection.select(this.dataSource.data[6]);
      this.selection.select(this.dataSource.data[7]);
    }
    else if (this.selectedFileFormatId == "2") { // Vanguard Report
      this.ResetELEMENT_DATA();

      this.tableForm.get('delimiterSelect').setValue("NA");
      this.selectedDelimiter = "NA";
      this.tableForm.get('templateIgnoreRowsWithTags').setValue("VANGUARD,DATASET ACCESS LISTS,REPORT DATED:,INFORMATION AS OF:,CA7ONL,HSANTHANAM,STCUSER,END OF REPORT,####,**");

      this.ELEMENT_DATA = [
        { SourceColumn: "BU", DestinationColumn: "BU", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.BUName, IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset", DestinationColumn: "Asset", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: this.applicationName, IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Detail", DestinationColumn: "Asset Detail", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Asset Notes", DestinationColumn: "Asset Notes", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Last Name", DestinationColumn: "Name:", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 2, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "First Name", DestinationColumn: "Name:", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 1, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "UserId", DestinationColumn: "Userid:", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "Name:", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Role", DestinationColumn: "Group Explosion", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 1, ColumnValueEndPosition: 0, ColumnValueLength: 20, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: true, IsGroupHeader: true, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "LastLogin", DestinationColumn: "LastLogin", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "EmployeeId", DestinationColumn: "EmployeeId", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Term Date", DestinationColumn: "Term Date", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false },
        { SourceColumn: "Email", DestinationColumn: "Email", ColumnPositionIndex: 0, RowPosition: 0, ColumnValueStartPosition: 0, ColumnValueEndPosition: 0, ColumnValueLength: 0, ColumnValueEndPositionTag: "", SplitColumnValueIndex: 0, Delimiter: "", TabularGroupStartTag: "", TabularGroupEndTag: "", TabularColumnValuePosition: 0, IsTabularData: false, IsGroupHeader: false, ColumnConstantValue: "", IsRecordStart: false, IsRecordEnd: false }
      ];
      this.dataSource = new MatTableDataSource<Application>(this.ELEMENT_DATA)
      this.arrColumns = null;
      this.arrCount = 0;
      this.selection.clear();
      this.selection.select(this.dataSource.data[0]);
      this.selection.select(this.dataSource.data[1]);
      this.selection.select(this.dataSource.data[2]);
      this.selection.select(this.dataSource.data[4]);
      this.selection.select(this.dataSource.data[5]);
      this.selection.select(this.dataSource.data[6]);
      this.selection.select(this.dataSource.data[7]);
    }
    else { //General
      this.ResetELEMENT_DATA();
    }
  }

  Updatetabulargst(strVal: string) {
    this.dataSource.data[this.selectedColumnDSIndex].TabularGroupStartTag = strVal;
  }

  Updatetabularget(strVal: string) {
    this.dataSource.data[this.selectedColumnDSIndex].TabularGroupEndTag = strVal;
  }

  UpdateColumnPos(intVal: number) {
    this.dataSource.data[this.selectedColumnDSIndex].ColumnPositionIndex = intVal;
  }

  UpdateCHRP(intVal: number) {
    this.CHRP = intVal - 1;
    this.UpdateViewRawFile();
  }

  UpdateDRSP(intVal: number) {
    this.DRSP = intVal - 1;
  }

  Updaterowpos(intVal: number) {
    this.dataSource.data[this.selectedColumnDSIndex].RowPosition = intVal;
  }

  Updatecvstartpos(intVal: number) {
    this.dataSource.data[this.selectedColumnDSIndex].ColumnValueStartPosition = intVal;
  }
  Updatecvendpos(intVal: number) {
    this.dataSource.data[this.selectedColumnDSIndex].ColumnValueEndPosition = intVal;
  }
  Updatecvlength(intVal: number) {
    this.dataSource.data[this.selectedColumnDSIndex].ColumnValueLength = intVal;
  }
  Updatesplitcvindex(intVal: number) {
    this.dataSource.data[this.selectedColumnDSIndex].SplitColumnValueIndex = intVal;
  }

  Updatetabularcv(intVal: number) {
    this.dataSource.data[this.selectedColumnDSIndex].TabularColumnValuePosition = intVal;
  }

  onChangeIsTabularDataChecked(ob: MatCheckboxChange) {
    this.dataSource.data[this.selectedColumnDSIndex].IsTabularData = ob.checked;
  }

  onChangeIsGroupHeaderChecked(ob: MatCheckboxChange) {
    this.dataSource.data[this.selectedColumnDSIndex].IsGroupHeader = ob.checked;
  }

  onChangeIsRecordStartChecked(ob: MatCheckboxChange) {
    this.dataSource.data[this.selectedColumnDSIndex].IsRecordStart = ob.checked;
  }

  onChangeIsRecordEndChecked(ob: MatCheckboxChange) {
    this.dataSource.data[this.selectedColumnDSIndex].IsRecordEnd = ob.checked;
  }

  SetClass(strColumn: string) {
    strColumn.replace('*', '');
    let strReturn: string = "";
    if (this.selection.selected.findIndex(x => x.SourceColumn == strColumn) > -1) {
      strReturn = "VTSelected";
    }
    else {
      strReturn = "VTNotSelected";
    }

    return strReturn;

  }

  onUserListFileChange(pFileList: File[]) {
    this.selectedFiles = [];

    if (true) {
      this.files = Object.keys(pFileList).map(key => pFileList[key]);
      var isFileSizeUp: boolean = false;
      var isEmptyFile: boolean = false;
      var isNotValidFileType: boolean = false;

      this.files.forEach(element => {
        let fileSize: number;
        fileSize = + this.bytesToMegaBytes(element.size)


        if (fileSize > 100) // // checking the size is more than 100 MB show alert message
        {
          isFileSizeUp = true;
        }
        if (element.size == 0) {
          isEmptyFile = true;
        }


        const fileEntension = element.name.split('.').pop();
        if (this.validFileTypes.indexOf(fileEntension) == -1) // checking filetype  is not proper
        {

          isNotValidFileType = true;
        }
      });

      if (isNotValidFileType) // if File is not proper format showing alert messages
      {
        this.dialog.open(AlertdialogComponent, {
          width: '450px',

          data: {
            message: 'Please upload valid files(txt/xlsx/xls/csv/pdf).',
          }
        });
      }
      else {

        if (isFileSizeUp || isEmptyFile) // If file size is more than 100 MB show alert message and if File also empty showalert 
        {
          if (isFileSizeUp) {
            this.dialog.open(AlertdialogComponent, {
              width: '450px',

              data: {
                message: 'Please upload less than 100 MB files.',
              }
            });
          }
          else {
            if (isEmptyFile) {
              this.dialog.open(AlertdialogComponent, {
                width: '450px',

                data: {
                  message: 'Selected file is blank. Please upload valid file.',
                }
              });
            }
          }

        }
        else {


          this.files = Object.keys(pFileList).map(key => pFileList[key]);

          this.files.forEach(element => {

            const evid: any = {
              fileName: element.name,
              fileSize: this.bytesToMegaBytes(element.size),
              fileType: element.type,
              fileStatus: 'SUCCESS'
              //element.fileStatus

            }


            //this.fileArray.push(evid);
            //this.uploadfileArray.push(evid);
            //console.log(evid.fileName);
            //this.dataSource = new MatTableDataSource(this.fileArray);
            //this.dataSource.paginator = this.paginator;
            //this.dataSource.sort = this.sort;

            this.selectedFiles.push(<File>element);

          });

          //this.attachment.nativeElement.value = '';
        }
      }
      // this.getRFIDocumntList(this.rfiId);
    }
    //this.attachment.nativeElement.value = '';  // after deleting the file and to select the deleted file again.
    this.UploadRFDFiles();
    var file = this.selectedFiles[0];
    if (file.name.toLowerCase().indexOf('.pdf') > -1) {
      let sUrl:string = this.commonService.apiBaseUrl+"/api/RFI/load-pdf?strFilename="+file.name;
      let elementIframe:HTMLIFrameElement = document.getElementById('pdfFrame') as HTMLIFrameElement;
      elementIframe.src = sUrl;
    }
    this.UpdateViewRawFile();
  }

  bytesToMegaBytes(bytes) {

    return (bytes / (1024 * 1024)).toFixed(9);
  }

  UploadRFDFiles() {
    const formData = new FormData();

    if (this.selectedFiles.length) {
      for (let i = 0; i < this.selectedFiles.length; i++)
        formData.append('File', this.selectedFiles[i]);
    }
    formData.append('RFDId', this.appId.toString());
    formData.append('RFDOwner', this.commonService.getUserName());
    formData.append('DocumentCategoryId', "1");  // Not required 

    this.rfiService.UploadFilesFromTemplate(formData).subscribe(data => {
      // do something, if upload success
    });

    //this.selectedFiles= [];
  }

  UpdateViewRawFile() {
    var file = this.selectedFiles[0];
    var reader: FileReader = new FileReader();
    this.arrCount = 0;
    this.arrColumns = [];
    //this.IsStructTemplate = false;
    //this.tableForm.get('SelectTemplateType').setValue("5");
    this.fileOutput = "";
    this.excelData = [];
    if (this.previewSource != null && this.previewSource.data != null){
      this.previewSource.data = [];
    }

    if (file.name.toLowerCase().indexOf('.xlsx') > -1 || file.name.toLowerCase().indexOf('.xls') > -1) {
      const target: DataTransfer = <DataTransfer>(file.target);
      reader.onload = (e: any) => {
        /* read workbook */
        const bstr: string = e.target.result;
        const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

        /* grab first sheet */
        const wsname: string = wb.SheetNames[0];
        const ws: XLSX.WorkSheet = wb.Sheets[wsname];
        //debugger;
        /* save data */
        this.excelData = <AOA>(XLSX.utils.sheet_to_json(ws, { header: 1 }));
        //console.log(this.excelData);
        let i: number = 0;
        this.excelData[this.CHRP].forEach(cols => {
          this.arrColumns.push(<string>cols);
        });
      };
      reader.readAsBinaryString(file);
    }


    if (file.name.toLowerCase().indexOf('.csv') > -1 || file.name.toLowerCase().indexOf('.txt') > -1) {
      reader.onload = (e: any) => {
        // The file's text will be printed here
        this.fileOutput = e.target.result;
        this.arrFile = e.target.result.toString().replace(/\r\n/g, '\n').split('\n');
        this.arrCount = 0;
        let arrstring: string = "";
        if (this.IsStructTemplate) {
          let strDelimiter: string = this.selectedDelimiter;

          let headerLine: string = this.arrFile[this.CHRP];
          if (strDelimiter == "TAB") {
            this.arrColumns = headerLine.split('\t');
          }
          else {
            this.arrColumns = headerLine.split(strDelimiter);
          }

          /*if (this.arrColumns.length < 3){
            headerLine  = this.arrFile[1];  
            if (strDelimiter == "TAB") {
              this.arrColumns = headerLine.split('\t');
            }
            else {
                this.arrColumns = headerLine.split(strDelimiter);
            }
            if (this.arrColumns.length < 3){
              this.tableForm.get('templateColumnRowPosition').setValue(2);
              this.tableForm.get('templateDataRowPosition').setValue(3);
            }
          }
          else {
            this.tableForm.get('templateColumnRowPosition').setValue(1);
            this.tableForm.get('templateDataRowPosition').setValue(2);
          }*/

          //this.arrColumns.splice(this.arrColumns.indexOf(/['"]+/g), 1, '');
          let arrIndex: number = 0;
          this.arrColumns.forEach(element => {
            let astring: string = element.replace('\"', '');
            astring = astring.replace('\"', '');
            this.arrColumns[arrIndex] = astring;
            arrIndex++;
          });
          //console.log(this.arrColumns);
          this.arrCount = this.arrFile.length;
        }

        let indexarr: number = 0;
        this.arrFile.forEach(element => {
          this.arrFile[indexarr] = this.padLeadingZeros(indexarr + 1, 5) + ":" + element
          arrstring = arrstring + this.arrFile[indexarr] + "\n";
          indexarr++;
        });

        if (!this.IsStructTemplate && this.selectedFileFormatId == "1") { //Unix Solaris
          let unixSolarixLine: string = "Username:Password:User ID (UID):Group ID (GID):User ID Info (GECOS):Home Directory:Command/Shell";
          this.arrColumns = unixSolarixLine.split(":");
          this.arrCount = 0;
        }

        this.fileOutput = arrstring;

        if (this.arrColumns.length < 3) {
          this.arrCount = 0;
          this.arrColumns = null;
        }

        //if (this.arrColumns.length > 3){
        //this.IsStructTemplate = true;
        //this.tableForm.get('SelectTemplateType').setValue("1");
        //}
      };

      reader.readAsText(file);
    }

  }

  OnNext() {
    this.selectedTabIndex = 1;
  }

  PreviewProcessedData() {
    /*let indexarr : number= 0;
    let arrstring:string = "";
    this.arrFile.forEach(element => {
      this.arrFile[indexarr] = this.padLeadingZeros(indexarr+1,5) +" "+ element
      arrstring = arrstring + this.arrFile[indexarr]+"\n";
      indexarr++;
    });
    console.log(this.arrFile);*/
    //this.ELEMENT_PREVIEW_DATA = null;
    if (this.previewSource != null && this.previewSource.data != null){
      this.previewSource.data = [];
    }
    let BUVal: string = this.dataSource.data[0].ColumnConstantValue;
    let AssetVal: string = this.dataSource.data[1].ColumnConstantValue;
    let AssetDetailVal: string = this.dataSource.data[2].ColumnConstantValue;
    let PreviewJson: PreviewData = new PreviewData();
    let prevD: PreviewClass;
    let rowCount: number = 0;
    if (this.arrFile.length > 0) {
      this.arrFile.forEach(element => {
        prevD = new PreviewClass();
        let currentLine: string = element.substring(6);
        currentLine = currentLine.replace('\"', '');
        currentLine = currentLine.replace('\"', '');
        let arrDataValues: any;
        if (this.selectedDelimiter == "TAB") {
          arrDataValues = currentLine.split('\t');
        }
        else {
          arrDataValues = currentLine.split(this.selectedDelimiter);
        }
        if (arrDataValues.length > 3 && rowCount > 0) {
          for (let i: number = 0; i < this.selection.selected.length; i++) {
            prevD.BU = BUVal;
            prevD.Asset = AssetVal;
            prevD.AssetDetails = AssetDetailVal;
            if (this.selection.selected[i].SourceColumn != "BU" && this.selection.selected[i].SourceColumn != "Asset" && this.selection.selected[i].SourceColumn != "Asset Detail") {
              let colpos: number = this.selection.selected[i].ColumnPositionIndex - 1;
              let colnm: string = this.selection.selected[i].DestinationColumn;
              let colnmSource: string = this.selection.selected[i].SourceColumn;
              let colVal: string = arrDataValues[colpos].toString().replace('\"', ''); //.replace(/\s/g,'');
              if (this.selection.selected[i].SplitColumnValueIndex > 0) {
                let arrSplitValues: any;
                if (this.selection.selected[i].Delimiter == null || this.selection.selected[i].Delimiter == "") {
                  arrSplitValues = colVal.split(" ");
                }
                else {
                  arrSplitValues = colVal.split(this.selection.selected[i].Delimiter);
                }
                if (arrSplitValues.length >= this.selection.selected[i].SplitColumnValueIndex) {
                  colVal = arrSplitValues[this.selection.selected[i].SplitColumnValueIndex - 1];
                }
              }

              if (colnmSource == "Asset Notes") {
                prevD.AssetNotes = colVal;
              }
              if (colnmSource == "Last Name") {
                prevD.LastName = colVal;
              }
              if (colnmSource == "First Name") {
                prevD.FirstName = colVal;
              }
              if (colnmSource == "UserId") {
                prevD.UserId = colVal;
              }
              if (colnmSource == "Role") {
                prevD.Role = colVal;
              }
              if (colnmSource == "LastLogin") {
                prevD.LastLogin = colVal;
              }
              if (colnmSource == "EmployeeId") {
                prevD.EmployeeId = colVal;
              }
              if (colnmSource == "Term Date") {
                prevD.Termdate = colVal;
              }
              if (colnmSource == "Email") {
                prevD.Email = colVal;
              }
            }
          }
          PreviewJson.PreviewClass.push(prevD);
        }
        rowCount++;
      });
    }

    // New code for xlsx/xls
    this.excelData.forEach(element => {
      prevD = new PreviewClass();
      //let currentLine:string = element.substring(5);
      //currentLine =  currentLine.replace('\"', '');
      //currentLine = currentLine.replace('\"', '');
      let arrDataValues: string[] = element; //currentLine.split(this.selectedDelimiter);
      if (arrDataValues.length > 3 && rowCount > 0) {
        for (let i: number = 0; i < this.selection.selected.length; i++) {
          prevD.BU = BUVal;
          prevD.Asset = AssetVal;
          prevD.AssetDetails = AssetDetailVal;
          if (this.selection.selected[i].SourceColumn != "BU" && this.selection.selected[i].SourceColumn != "Asset" && this.selection.selected[i].SourceColumn != "Asset Detail") {
            let colpos: number = this.selection.selected[i].ColumnPositionIndex - 1;
            let colnm: string = this.selection.selected[i].DestinationColumn;
            let colnmSource: string = this.selection.selected[i].SourceColumn;
            let colVal: string = arrDataValues[colpos].toString().replace('\"', ''); //.replace(/\s/g,'');
            if (this.selection.selected[i].SplitColumnValueIndex > 0) {
              let arrSplitValues: any;
              if (this.selection.selected[i].Delimiter == null || this.selection.selected[i].Delimiter == "") {
                arrSplitValues = colVal.split(" ");
              }
              else {
                arrSplitValues = colVal.split(this.selection.selected[i].Delimiter);
              }
              if (arrSplitValues.length >= this.selection.selected[i].SplitColumnValueIndex) {
                colVal = arrSplitValues[this.selection.selected[i].SplitColumnValueIndex - 1];
              }
            }

            /*if (colnmSource == "Asset Detail"){
              prevD.AssetDetail =colVal
            }*/
            if (colnmSource == "Asset Notes") {
              prevD.AssetNotes = colVal;
            }
            if (colnmSource == "Last Name") {
              prevD.LastName = colVal;
            }
            if (colnmSource == "First Name") {
              prevD.FirstName = colVal;
            }
            if (colnmSource == "UserId") {
              prevD.UserId = colVal;
            }
            if (colnmSource == "Role") {
              prevD.Role = colVal;
            }
            if (colnmSource == "LastLogin") {
              prevD.LastLogin = colVal;
            }
            if (colnmSource == "EmployeeId") {
              prevD.EmployeeId = colVal;
            }
            if (colnmSource == "Term Date") {
              prevD.Termdate = colVal;
            }
            if (colnmSource == "Email") {
              prevD.Email = colVal;
            }
          }
        }
        PreviewJson.PreviewClass.push(prevD);
      }
      rowCount++;
    });
    this.previewSource = new MatTableDataSource<PreviewClass>(PreviewJson.PreviewClass);
  }

  /*
  getRFIDocumntList(rfiId: number) {

    this.rfiService.getRFIDocumentList(this.rfiId).subscribe(data => {
      this.fileArray = [];
      data.forEach(element => {
        const evid: any = {
          fileName: element.fileName,
          fileSize: element.fileSize,
          fileType: element.fileType,
          fileStatus: element.fileStatus
        }
        this.fileArray.push(evid);
      });

      if (this.fileArray.length > 0) {
        this.isfileGrid = true;
        this.dataSource = new MatTableDataSource(this.fileArray);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      }
      else {
        this.isfileGrid = false;
      }
    })
  }
  */

  async getRFIDetailList() {
    let cDate = this.datePipe.transform(this.tdate, 'MM-dd-yyyy');
    let data = await this.rfiService.getRFIDetailList(this.commonService.getUserName(),
      this.commonService.getRoleName(),
      cDate
    );
    if (data) {
      let rfifilter: any[] = [];
      data.forEach(element => {
        const df: any = {
          applicationName: element.applicationName,
          applicationOwner: element.rfiOwner,
          rfi: element.rfiId,
          rfiId: element.id,
          applicationId: element.applicationId,
          rfiStatus: element.rfiStatus,
          buname: element.bu,

        }
        rfifilter.push(df);
      });
      this.userOptions = rfifilter;
    }
    return this.userOptions;
  }
  OnSelected(option: MatOption) {
    //this.dataSource = null;
    this.ngOnInit();
    //this.SelectTemplate("0");
    this.loadTabs = true;
    this.applicationName = option.value.applicationName;
    this.applicationOwner = option.value.applicationOwner;
    this.applicationId = option.value.applicationId;
    this.appId = this.applicationId;
    this.rfiStatus = option.value.rfiStatus;
    this.BUName = option.value.buname;
    this.dataSource.data[0].ColumnConstantValue = this.BUName;
    this.dataSource.data[1].ColumnConstantValue = this.applicationName;
    this.rfi = option.value.rfi;
    this.rfiId = option.value.rfiId;
    //this.getRFIDocumntList(this.rfiId);

    this.commonService.setOption('applicationName', option.value.applicationName);
    this.commonService.setOption('applicationId', option.value.applicationId);
    this.commonService.setOption('rfiid', option.value.rfiId);
    this.commonService.setOption('rfistatus', option.value.rfiStatus);
    this.commonService.setOption('buname', option.value.buname);

    if(this.rfiStatus=="Open" || this.rfiStatus == "Returned"){
      this.openStatus = true;
    }
    else {
      this.openStatus = false;
    }

    /*this.tableForm.get('templateInput').setValue("");
    this.IsTemplateChecked = false;*/

    /*
    if (this.applicationId > 0) {
      this.templateService
        .GetAppTemplatesList(this.applicationId)
        .subscribe((data) => {
          this.templatesList = data;
          console.log(data);
          data.forEach(element => {
            if (element.isDefault == true) {
              this.IsTemplateChecked = true;
              this.uploadForm.get('templateInput').setValue(element.description);
            }
          });
        });
    }*/
  }
  clear() {
    this.myControl.reset('');
    this.loadTabs = false;
    this.templateId = 0;
    this.SelectTemplate("0");
    //this.ngOnInit();
    this.IsStructTemplate = true;
    this.appId = 0;
    this.applicationName = "";
    this.applicationOwner = "";
    this.applicationId = 0;
    this.templatesList = [];
    this.openStatus = true;
  }
  transform(searchText: string): any[] {
    let items = this.userOptions;
    if (!items) return [];
    if (!searchText) return items;

    return items.filter(item => {
      return Object.keys(item).some(key => {
        return String(item[key]).toLowerCase().includes(searchText.toLowerCase());
      });
    });
  }
  displayFn(user: any) {
    let pop = user ? user.rfi + ' | ' + user.applicationName + ' | ' + user.applicationOwner + ' | ' + user.rfiStatus : '';
    return pop;
  }

  CompleteTemplate() {
    this.router.navigate(['/certification/rfifileupload/'], { queryParams: { rfiId: this.rfi }, queryParamsHandling: 'merge' });
  }

  onChangeIsFixedLength(ob: MatCheckboxChange) {
    if (ob.checked){
      this.dataSource.data.forEach(row => {
        if (row.SourceColumn != "BU" && row.SourceColumn !="Asset" && row.SourceColumn != "Asset Detail") {
           row.DestinationColumn = "FixedLength";
        }
      });
    }
    else {
      this.dataSource.data.forEach(row => {
        if (row.SourceColumn != "BU" && row.SourceColumn !="Asset" && row.SourceColumn != "Asset Detail") {
           row.DestinationColumn = row.SourceColumn;
        }
      });
    }
  }
}
