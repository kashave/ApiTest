import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CreatetemplatecsvComponent } from './createtemplatecsv.component';

describe('CreatetemplatecsvComponent', () => {
  let component: CreatetemplatecsvComponent;
  let fixture: ComponentFixture<CreatetemplatecsvComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CreatetemplatecsvComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreatetemplatecsvComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
