import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { RfipopupComponent } from '../rfipopup/rfipopup.component';
import { MatTableDataSource } from '@angular/material/table';
import { RfiService } from 'src/app/services/rfi.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { MenuItems, Permission } from 'src/app/header/header.component';

@Component({
  selector: 'app-rfilist',
  templateUrl: './rfilist.component.html',
  styleUrls: ['./rfilist.component.css'],
  providers: [DatePipe],
})
export class RfilistComponent implements OnInit, AfterViewInit {
  public role: string;
  public userId: string;
  tdate = new Date();

  //public cdate : string = '20-20-2021'
  public show: boolean = false;
  public isshowview: boolean = true;
  public isshowupload: boolean = true;
  public isshowsearch: boolean = false;

  erroMsg: any;
  displayedColumns: string[] = [
    'rfiId',
    'applicationName',
    'rfiStatus',
    'rfiOwner',
    'dueDate',
    'Upload',
  ];

  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  //@ViewChild(MatSort, {static: true}) sort: MatSort;

  dataSource = new MatTableDataSource<any>();
  filterForm: FormGroup;
  showrole = this.commonService.getRoleName();
 // pageSize = this.showrole == "ACGMember" ? 6 : 8; //show 9 records or 13 records as default
 pageSize = window.innerWidth < 1440 ? 10 : 15;
  constructor(
    private router: Router,
    private _rfiService: RfiService,
    private datePipe: DatePipe,
    public fb: FormBuilder,
    private commonService: CommonService,
    public dialog: MatDialog,
    private userService : UserService
  ) {}
  public rfiStatus = [];
  ngOnInit() {
    this.searchForm();

    this.userId = this.commonService.getUserName();
    this.role = this.commonService.getRoleName();

    this.displayRoleMenuPermission()

    // if (this.role == 'ApplicationOwner') {
    //   this.show = false;
    // }

    // if (this.role == 'ACGMember') {
    //   this.show = true;
    // }

    let cDate = this.datePipe.transform(this.tdate, 'MM-dd-yyyy');

    this._rfiService
      .getRfiList(this.userId, this.role, cDate)
      .subscribe((data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });

    this._rfiService.getRfiStatus().subscribe(
      (data) => (this.rfiStatus = data),
      (error) => (this.erroMsg = error)
    );
  }

  /* Reactive form */
  searchForm() {
    this.filterForm = this.fb.group({
      rfistatus: [''],
      owner: [''],
      duedate: [''],
    });
  }

  ngAfterViewInit(): void {
    //this.dataSource.sort = this.sort;
  }

  // openRFIDetailsDialog(rfiIdVal : any): void {

  //  const dialogConfig = new MatDialogConfig();
  //  dialogConfig.disableClose = true;
  //  dialogConfig.autoFocus = true;

  //  dialogConfig.width= "800px",

  //  dialogConfig.data = {
  //      userId: rfiIdVal
  //  };
  //  this.dialog.open(RfipopupComponent, dialogConfig);

  // }
  upload(rfiIdVal : any){
    this.router.navigate(['/certification/rfifileupload/'], { queryParams: { rfiId : rfiIdVal  }, queryParamsHandling: 'merge' });

  }

  showRfiDetails(rfiIdVal : any){
    this.router.navigate(['/certification/rfidetails/'], { queryParams: { rfiId : rfiIdVal  }, queryParamsHandling: 'merge' });

  }

  submitSearchForm() {
    let pOwner = this.filterForm.get('owner').value;
    let prfiStatus = this.filterForm.get('rfistatus').value;
    let prDate = this.datePipe.transform(
      this.filterForm.get('duedate').value,
      'MM-dd-yyyy'
    );
    let pcDate = this.datePipe.transform(this.tdate, 'MM-dd-yyyy');

    if (pOwner == 'undefined' || pOwner == '' || pOwner == null) {
      pOwner = 'ALL';
    }


    if (prfiStatus == 'undefined' || prfiStatus == '' || prfiStatus == null || prfiStatus == 'Select' ) {
      prfiStatus = '0';
    }

    if (prDate == 'undefined' || prDate == '' || prDate == null) {
      prDate = 'ALL';
    }

    //console.log(this.filterForm.value)

    this._rfiService
      .getRfiListbySearch(pOwner, prfiStatus, prDate, pcDate)
      .subscribe((data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
  }

  displayRoleMenuPermission()
    {

      this.userService
      .getMenuPermission(this.commonService.getRoleId(),MenuItems.UserCertificationHome)
      .subscribe((data) => {

        data.forEach(element =>
          {

            if(Permission.View == element.permissionId)
            {
              this.isshowview  = true;
            }
            if(Permission.Upload == element.permissionId )
            {
              this.isshowupload = false;  // in this section we have make false.
            }
            if(Permission.Search == element.permissionId )
            {
              this.isshowsearch = true;
            }

          });


      });
    }


}
