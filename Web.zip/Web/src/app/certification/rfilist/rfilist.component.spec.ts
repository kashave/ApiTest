import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RfilistComponent } from './rfilist.component';

describe('RfilistComponent', () => {
  let component: RfilistComponent;
  let fixture: ComponentFixture<RfilistComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RfilistComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RfilistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
