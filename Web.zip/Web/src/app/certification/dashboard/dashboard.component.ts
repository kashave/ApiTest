import { Component, OnInit } from '@angular/core';
import { ChartType, ChartOptions } from 'chart.js';
import { SingleDataSet, Label } from 'ng2-charts';
import { DashboardService } from 'src/app/services/dashboard.service';
import {
  HttpClient,
  HttpErrorResponse,
  HttpHeaders,
} from '@angular/common/http';
import { element } from 'protractor';
import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';
import { MenuItems, Permission } from 'src/app/header/header.component';



@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  public isshowview: boolean = false;
  constructor(
    public dashboardService: DashboardService,
    private http: HttpClient, private userService: UserService, private commonService: CommonService
  ) { }
  quarterBy: string[] = [
    'ALL User',
    'ALL Status',
    'Open',
    'ACG Completed',
    'Missed RFI',
  ];
  pieChartArr: string[] = [];
  something;
  ALLData = [];
  ACGStatus = [];
  Open = [];
  ACGComplete = [];
  Returned = [];
  kp = [];

  totalbyuser = [];
  totalbystatus = [];
  openbyuser = [];
  completedbyuser = [];
  returnbyuser = [];
  getACGDashboard() {
    var CPdata;
    this.quarterBy.forEach((element) => {
      CPdata = this.dashboardService
        .getDetailsbyQuarter(element)
        .subscribe((data) => {
          if (element == 'ALL User') {

            this.ALLData = data.map(function (object) {
              return [object.userOnly, object.adminOnly, object.userandAdmin, object.noUser];
            });
            this.totalbyuser = [this.ALLData[0]];

          }
          // else if (element == 'ALL Status') {
          //   this.ACGStatus = data.map(function (object) {
          //     console.log(object)
          //     return [object.userOnly, object.adminOnly, object.userandAdmin,object.noUser];
          //   });
          //   this.totalbystatus = [this.ACGStatus[0]];

          // } 
          else if (element == 'Open') {
            this.Open = data.map(function (object) {
              return [object.userOnly, object.adminOnly, object.userandAdmin, object.noUser];
            });
            this.openbyuser = [this.Open[0]];

          } else if (element == 'ACG Completed') {
            this.ACGComplete = data.map(function (object) {
              return [object.userOnly, object.adminOnly, object.userandAdmin, object.noUser];
            });
            this.completedbyuser = [this.ACGComplete[0]];
          } else if (element == 'Missed RFI') {
            this.Returned = data.map(function (object) {
              return [object.userOnly, object.adminOnly, object.userandAdmin, object.noUser];
            });
            this.returnbyuser = [this.Returned[0]];
          }
        });
    });
  }
  getACGDashboardStatus() {
    var CPdata;
    debugger;
    this.quarterBy.forEach((element) => {
      CPdata = this.dashboardService
        .getStatusbyQuarter("All Status")
        .subscribe((data) => {
         

            this.ACGStatus = data.map(function (object) {
              return [object.open, object.submittedorPendingAcceptance, object.returned, object.acceptedOrProcessing, object.closedOrIncomplete, object.completeOrCertificationStarted];
            });
            this.totalbystatus = [this.ACGStatus[0]];

          
        })
    });
  }
  public TotalbyUserOptions: ChartOptions = {
    responsive: true, maintainAspectRatio: false,title:{text: 'Total by User',      display:true,   },
    legend:  {      position: 'bottom', labels: {        fontSize: 10,        boxWidth: 10,}, },
  };
  public TotalbyStatusOptions: ChartOptions = {
    responsive: true, maintainAspectRatio: false,title:{text: 'Total by Status',      display:true,   },
    legend:  {      position: 'bottom', labels: {        fontSize: 10,        boxWidth: 10,}, },
  };
  public OpenbyUserOptions: ChartOptions = {
    responsive: true, maintainAspectRatio: false,title:{text: 'Open by User',      display:true,   },
    legend:  {      position: 'bottom', labels: {        fontSize: 10,        boxWidth: 10,}, },
  };
  public CompletedbyUserOptions: ChartOptions = {
    responsive: true, maintainAspectRatio: false,title:{text: 'Completed by User',      display:true,   },
    legend:  {      position: 'bottom', labels: {        fontSize: 10,        boxWidth: 10,}, },
  };
  public ReturnedbyUserOptions: ChartOptions = {
    responsive: true, maintainAspectRatio: false,title:{text: 'Returned by User',      display:true,   },
    legend:  {      position: 'bottom', labels: {        fontSize: 10,        boxWidth: 10,}, },
  };




  public pieChartLabels: Label[] = ['User', 'Admin', 'User and Admin', 'No User'];
  public pieStatusChartLabels: Label[] = ['Open', 'Submitted/Pending Acceptance', 'Returned', 'Accepted/Processing', 'Closed/Incomplete', 'Complete/Certification Started'];
  public pieChartType: ChartType = 'pie';
  public pieChartLegend = true;
  public chartColors: any[] = [{ backgroundColor: ['#FF7360', '#6fcea8', '#8FAADE', '#FAF6A1'] }];
  public pieChartPlugins = [
    {
      afterLayout: function (chart) {
        chart.legend.legendItems.forEach((label) => {
          let value = chart.data.datasets[0].data[label.index];
          label.text += '-' + value;
          return label;
        });
      },
    },
  ];
  ngOnInit() {

    this.getACGDashboard();
    this.getACGDashboardStatus();
    this.displayRoleMenuPermission();
  }

  displayRoleMenuPermission() {
    this.userService
      .getMenuPermission(this.commonService.getRoleId(), MenuItems.ACGDashboard)
      .subscribe((data) => {

        data.forEach(element => {

          if (Permission.View == element.permissionId) {
            this.isshowview = true;
          }

        });


      });
  }
}
