import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managecampaign',
  templateUrl: './managecampaign.component.html',
  styleUrls: ['./managecampaign.component.css']
})
export class ManagecampaignComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
