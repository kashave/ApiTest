import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagecampaignComponent } from './managecampaign.component';

describe('ManagecampaignComponent', () => {
  let component: ManagecampaignComponent;
  let fixture: ComponentFixture<ManagecampaignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagecampaignComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagecampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
