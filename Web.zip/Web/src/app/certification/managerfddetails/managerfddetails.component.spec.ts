import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerfddetailsComponent } from './managerfddetails.component';

describe('ManagerfddetailsComponent', () => {
  let component: ManagerfddetailsComponent;
  let fixture: ComponentFixture<ManagerfddetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagerfddetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerfddetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
