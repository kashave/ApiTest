import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managerfddetails',
  templateUrl: './managerfddetails.component.html',
  styleUrls: ['./managerfddetails.component.css']
})
export class ManagerfddetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
