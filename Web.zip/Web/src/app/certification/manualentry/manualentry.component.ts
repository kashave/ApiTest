import { DataSource } from '@angular/cdk/collections';
import { error } from '@angular/compiler/src/util';
import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { exit } from 'process';
import { MatSort } from '@angular/material/sort';
import {
  NgForm,
  FormGroup,
  FormControl,
  FormArray,
  FormBuilder,
  Validators,
  FormGroupDirective,
} from '@angular/forms';
import {
  CanActivate,
  ActivatedRouteSnapshot,
  RouterStateSnapshot,
  UrlTree,
  Router,
} from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';
import { MenuItems, Permission } from 'src/app/header/header.component';



@Component({
  selector: 'app-manualentry',
  templateUrl: './manualentry.component.html',
  styleUrls: ['./manualentry.component.scss'],
})
export class ManualentryComponent implements OnInit {
  gaugeTitles: FormArray;

  title = 'manual-entry';

  maxDate: Date;
  today = new Date();
  serverData = [];
  public isshowview: boolean = false;
  public isshowsave: boolean = false;

  @Input()
  max: Date | null;
  alphas: string[][];
  constructor(
    private router: Router,
    private _fb: FormBuilder,
    private userService: UserService,
    private commonService: CommonService
  ) {}

  manualentryForm: FormGroup;
  ngOnInit() {
    this.manualentryForm = this._fb.group({
      gaugeTitles: this._fb.array([this.createItem()]),
    });
    this.gaugeTitles = this.manualentryForm.get('gaugeTitles') as FormArray;
    this.data();
    
  }
  private data()
  {
   this.serverData =
   [
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     },
     {
      BU: "",
      Asset: "",
      assetDetails: "",
      assetNotes: "",
      firstName: "",
      lastName: "",
      UserId: "",
      Role: "",
      Status: "",
      EmployeeId: "",
      TermDate: "",
      EmailId: "",
     }
   ];

   this.serverData.map(d =>
     this.gaugeTitles.push(this._fb.group({  BU: "",
     Asset: "",
     assetDetails: "",
     assetNotes: "",
     firstName: "",
     lastName: "",
     UserId: "",
     Role: "",
     Status: "",
     EmployeeId: "",
     TermDate: "",
     EmailId: "", }))
   );
 }

  getToday(): string {
    return new Date().toISOString().split('T')[0];
  }
  addItem() {
    this.gaugeTitles.push(this.createItem());
  }
  public OnReset()
{
  this.manualentryForm.reset();
}
  createItem() {
    return this._fb.group({
      BU: new FormControl('', [Validators.required]),
      Asset: new FormControl('', [Validators.required]),
      assetDetails: new FormControl(''),
      assetNotes: new FormControl(''),
      firstName: new FormControl('', [Validators.required]),
      lastName: new FormControl('', [Validators.required]),
      UserId: new FormControl('', [Validators.required]),
      Role: new FormControl('', [Validators.required]),
      Status: new FormControl(''),
      EmployeeId: new FormControl(''),
      TermDate: new FormControl(''),
      EmailId: new FormControl('', [Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$')]),
    });
  }

  removeItem(itemIndex: number) {
    this.gaugeTitles.removeAt(itemIndex);
  }

  SaveData(){
    console.log("message")
  }
  cancelForm() {
    window.location.reload();
    this.manualentryForm.reset();
  }
  
}
