import { Component, ElementRef, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { element } from 'protractor';
import { MatTabGroup } from '@angular/material/tabs';
import { SelectionModel } from '@angular/cdk/collections';
import { MatLabel } from '@angular/material/form-field';
import {Observable} from 'rxjs';
import {map, startWith} from 'rxjs/operators';
import { MatOption } from '@angular/material/core/option';

export interface ManualEntry {
  id : string;
  fname: string;
  lname: string;
  userid : string;
  userrole : string;
  emailid: string;
  title: string;
  dept : string;
}

interface formattedType{
    id: number,
    typeName: string
}

interface  fileDetail{
    data: any,
    filename: string,
    size: number,
    type: string
}

interface  UserDetail{
  data: any,
  username: string,
  role: string
}

export interface Application {
    name: string;
    id : string;
    owner : string;
    emailid: any[];
    status: string;
    rfino: string;
    bunit : string;
    dcenter : string;
    edit : string;
    userlist : any[];
  }

@Component({
  selector: 'app-documentupload',
  templateUrl: './documentupload.component.html',
  styleUrls: [ './documentupload.component.css' ]
})
export class DocumentUploadComponent  {
  myControl = new FormControl();

  options: string[] = ['RFI-1234567 | Operational Planning | Haddock, John', 
  'RFI-2345678 | Strategic Planning | Jackson, Micheal', 
  'RFI-3456789 | Tactical Planning | Trump, David', 
  'RFI-4567890 | Contingency Planning | Deen, Joshua'];
  filteredOptions: Observable<string[]>;
   userListfile : fileDetail[] = [
       {
           filename: 'userlist1.txt',
           size: 23456,
           data: null,
           type: 'txt'
        },
       {
        filename: 'userlist1.csv',
        size: 23456,
        data: null,
        type: 'csv'
       }
    ]

    evidencefile : fileDetail[] = [
        {
            filename: 'evidence1.jpg',
            size: 23456,
            data: null,
            type: 'jpg'
         },
        {
         filename: 'evidence2.png',
         size: 23456,
         data: null,
         type: 'png'
        }
     ]

     userfile : UserDetail[] = [
       {
         data: null,
         username: 'davidhudson',
         role:'Admin'
       },
       {
         data: null,
         username: 'JackRussel',
         role:'Application User 1'
       }
     ]
 
  applicationName = '';
  applicationOwner = '';

  rfiID = '';
  loadTabs = false;
    fileArray : any[] = [];
    evidencefiles : any[] = [];
    highlightedRows = [];
    manualentrydataSource: ManualEntry[] = [
      {id: "1", fname:"David", lname:"Hudson", userid:"dhudson",userrole: "Admin", emailid:"dhudson@xyz.com", title:"User", dept:"Accounts"},
      {id: "2", fname:"", lname:"", userid:"",userrole: "", emailid:"", title:"", dept:""}
  ];
  ManualEntrydisplayedColumns: string[] = [ "id", "fname", "lname", "userid", "userrole", "emailid", "title", "dept"];
    dataSource: Application[] = [
        {name: 'Operational Planning', id: "1259", bunit:"High", dcenter:"06/30/2021", owner: "Haddock, John",
         emailid : this.evidencefile, rfino:"RFI-1234567", status: "RFI created", edit:"",
         userlist: this.userListfile
         },
        {name: 'Strategic Planning', id: "1237", bunit:"", dcenter:"06/30/2021",
         owner: "Jackson, Micheal", emailid : [], rfino:"RFI-2345678", status: "RFI not created",edit:"",
         userlist:[]},
        {name: 'Tactical Planning', id: "2762", bunit:"", dcenter:"06/30/2021", owner: "Trump, David", 
        emailid : this.evidencefile, rfino:"RFI-3456789",status: "RFI not created", edit:"",
        userlist:[]},
        {name: 'Contingency Planning', id: "2305", bunit:"", dcenter:"06/30/2021", owner: "Deen, Joshua",
         emailid : this.evidencefile,
          rfino:"RFI-4567890",status: "RFI not created",edit:"",userlist: this.userListfile}
     ];
     displayedColumns: string[] = ['rfino','status', 'id', 'name', 'bunit','dcenter'];
     email: string;

  selection = new SelectionModel<any>(false, []);

  public files: any[] = [];



  formattedTypes: formattedType[] = [
    { id: 1, typeName: 'Unix' },
    { id: 2, typeName: 'Mainframe' },
    { id: 3, typeName: 'HP Non-Stop' }
  ];
  fileuploadForm: FormGroup;

  constructor(private _snackBar: MatSnackBar, public dialog: MatDialog,private fb: FormBuilder){
  }

  ngOnInit() {
    this.filteredOptions = this.myControl.valueChanges
    .pipe(
      startWith(''),
      map(value => this._filter(value))
    );

    this.fileuploadForm = this.fb.group({
        formatTyeControl : new FormControl(),
        applicationownerControl: new FormControl(),
        applicationNameControl : new FormControl(),
        rfidControl : new FormControl()
    });
  }

  private _filter(value: string): string[] {
    const filterValue = value.toLowerCase();

    return this.options.filter(option => option.toLowerCase().includes(filterValue));
  }

  onUserListFileChange(pFileList: File[]){
    this.files = Object.keys(pFileList).map(key => pFileList[key]);
    this.files.forEach(element => {
        const evid : any = {
            filename: element.name,
                size: element.size,
                data: null,
                type: element.type
            }
            this.fileArray.push(evid);
    });
    this._snackBar.open("Successfully upload!", 'Close', {
      duration: 2000,
    });
  }

  onEvidenceFileChange(pFileList: File[]){
    this.files = Object.keys(pFileList).map(key => pFileList[key]);
    this.files.forEach(element => {
        const evid : any = {
        filename: element.name,
            size: element.size,
            data: null,
            type: element.type
        }
        this.evidencefile.push(evid);

    });
    this._snackBar.open("Successfully upload!", 'Close', {
      duration: 2000,
    });
  }

  onRowChange(row:any){
      debugger;
  console.log(row);
  this.loadTabs = true;
  this.highlightedRows = [];
  this.highlightedRows.push(row);
  this.fileArray = [];
  this.fileuploadForm.controls['applicationownerControl'].setValue(row.owner);
  this.fileuploadForm.controls['applicationNameControl'].setValue(row.name);
  this.applicationName = row.name;
  this.applicationOwner = row.owner;
  this.rfiID = row.rfino;
  this.fileuploadForm.controls['rfidControl'].setValue(row.rfino);
  this.fileArray = row.userlist;
//   row.emailid.forEach(element => {
//   this.fileArray.push(element);      
//   });
  this.evidencefiles = row.emailid;
  }

  deleteFile(f){
    this._snackBar.open("Successfully delete!", 'Close', {
      duration: 2000,
    });
  }
 
  deleteFromArray(index) {
    console.log(this.files);
    this.files.splice(index, 1);
  }

  getAppId(event:any){

  }

  OnSelected(option: MatOption) {
    //console.log(option.value);
    this.loadTabs = true;
    //this.highlightedRows = [];
    //this.highlightedRows.push(row);
    this.fileArray = [];
    this.fileuploadForm.controls['applicationownerControl'].setValue(option.value.split(" | ",3)[2]);
    this.fileuploadForm.controls['applicationNameControl'].setValue(option.value.split(" | ",3)[1]);
    this.applicationName = option.value.split(" | ",3)[1];
    this.applicationOwner = option.value.split(" | ",3)[2];
    this.rfiID = option.value.split(" | ",3)[0];
    this.fileuploadForm.controls['rfidControl'].setValue(option.value);
    this.fileArray = this.userListfile; //row.userlist;
    this.evidencefiles = this.evidencefile;//row.emailid;
  }
}
