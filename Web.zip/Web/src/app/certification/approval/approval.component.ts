import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material/dialog';
import { RfipopupComponent } from '../rfipopup/rfipopup.component';
import { MatTableDataSource } from '@angular/material/table';
import { RfiService } from 'src/app/services/rfi.service';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { FormGroup, FormControl, FormBuilder } from '@angular/forms';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { DatePipe } from '@angular/common';
import { CommonService } from 'src/app/services/common.service';
import { Router } from '@angular/router';
import { UserService } from 'src/app/services/user.service';
import { MenuItems, Permission } from 'src/app/header/header.component';
import { SelectionModel} from '@angular/cdk/collections';
import { IRFIList } from 'src/app/interfaces/IRFIList';
import { Source } from 'webpack-sources';
import { element } from 'protractor';

@Component({
  selector: 'app-approval',
  templateUrl: './approval.component.html',
  styleUrls: ['./approval.component.css'],
  providers: [DatePipe]
})
export class ApprovalComponent implements OnInit, AfterViewInit {

  public role: string;
  public userId: string;
  tdate = new Date();

  //public cdate : string = '20-20-2021'
  public show: boolean = false;
  public isshowview: boolean = true;
  public isshowupload: boolean = true;
  public isshowsearch: boolean = false;
  RFIStatusId: number;
  StatusMessage:string="";
  statusIsActive: boolean=false;
  //public selection : any;
  erroMsg: any;
  displayedColumns: string[] = [
    'select',
    'rfiId',
    'rfiName',
    'rfiStatus',
    'rfiOwner',
    'dueDate',
    'Upload',
    'bu'
  ];


  
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  //@ViewChild(MatSort, {static: true}) sort: MatSort;

  isMasterSel:boolean;
  public approvalstatus=[];
  categoryList:any;
  checkedCategoryList:any;
  rfiapproval :any;
  isSubmittoAdmin:boolean =false;

  dataSource = new MatTableDataSource<any>();
  
  dataSourcenew = new MatTableDataSource<IRFIList>();
  selection = new SelectionModel<any>(true, []);


  // getrfidetails(rw : any){
  //   alert(rw);
  //    // console.log(this.selection.selected);
  // }
  
  isAllSelected() {
   const numSelected = this.selection.selected.length;
   const numRows = this.dataSource.data.length;
   return numSelected === numRows;
  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle() {
    this.isAllSelected()
      ? this.selection.clear()
      : this.dataSource.data.forEach((row) => this.selection.select(row));
  }
  filterForm: FormGroup;
  showrole = this.commonService.getRoleName();
  pageSize = this.showrole == "ACGMember" ? 6 : 8; //show 9 records or 13 records as default
  constructor(
    private router: Router,
    private _rfiService: RfiService,
    private datePipe: DatePipe,
    public fb: FormBuilder,
    private commonService: CommonService,
    private _snackBar: MatSnackBar,
    public dialog: MatDialog,
    private userService : UserService
  ) {
    // this.isMasterSel = false;
    // debugger;
    //  this.categoryList = this.dataSourcenew.data[1];

    
    // this.getCheckedItemList();
   
  }

  approve(){
    debugger;
    
      let selectedvalue =  this.selection.selected;
    
      for(let i=0;i<selectedvalue.length;i++)
      {
        this.approvalstatus.push(selectedvalue[i].id)
      }
        this._rfiService.UpdatetoAdminStatus(this.approvalstatus)
        .subscribe((result) => {
          this.RFIStatusId=result["rfiStatusID"];
          this.StatusMessage=result["errorMessage"];
          this.statusIsActive=result["isActive"];

          if(this.StatusMessage=="Successfully Updated")
          {
              setTimeout(() => {
                this._snackBar.open('Updated successfully!', 'Success', {
                  duration: 8000,
                  verticalPosition: 'top',
                });
              }, 1000);
            }
            else{
              setTimeout(() => {
                this._snackBar.open('Record is already in Accepted Admin Complete!', 'Success', {
                  duration: 8000,
                  verticalPosition: 'top',
                });
              }, 1000);
            }
            this._rfiService
            .getRfiSubmittedList()
            .subscribe((data) => {
              this.dataSource = new MatTableDataSource(data);
              this.dataSource.paginator = this.paginator;
              this.dataSource.sort = this.sort;
           
            });
        });
     }
    
    
  public rfiStatus = [];
  public rfiBUStatus = [];
  masterSelected:boolean;
  checklist:any;
  checkedList:any;
  ngOnInit() {
    this.searchForm();

    this.userId = this.commonService.getUserName();
    this.role = this.commonService.getRoleName();

    this.displayRoleMenuPermission()


    let cDate = this.datePipe.transform(this.tdate, 'MM-dd-yyyy');

       this._rfiService
      .getRfiSubmittedList()
      .subscribe((data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
     
      });

    this._rfiService.getRfiStatus().subscribe(
      (data) => (this.rfiStatus = data),
      (error) => (this.erroMsg = error)
    );

    this._rfiService.getRfiBUStatus().subscribe(
      (data) => (this.rfiBUStatus = data),
      (error) => (this.erroMsg = error)
    );

  }

  /* Reactive form */
  searchForm() {
    this.filterForm = this.fb.group({
      bu: [''],
      owner: [''],
      duedate: [''],
    });
  }

  ngAfterViewInit(): void {
    //this.dataSource.sort = this.sort;
  }

  openRFIDetailsDialog(rfiIdVal : any): void {

   const dialogConfig = new MatDialogConfig();
   dialogConfig.disableClose = true;
   dialogConfig.autoFocus = true;

   dialogConfig.width= "800px",

   dialogConfig.data = {
       userId: rfiIdVal
   };
   this.dialog.open(RfipopupComponent, dialogConfig);

  }
  upload(rfiIdVal : any){
    this.router.navigate(['/certification/rfifileupload/'], { queryParams: { rfiId : rfiIdVal  }, queryParamsHandling: 'merge' });

  }

  submitSearchForm() {
    debugger;
    let pOwner = this.filterForm.get('owner').value;
    //alert(pOwner)
    let prfibu = this.filterForm.get('bu').value;
    //alert(prfibu)
    let prDate = this.datePipe.transform(
      this.filterForm.get('duedate').value,
      'MM-dd-yyyy'
    );
    let pcDate = this.datePipe.transform(this.tdate, 'MM-dd-yyyy');

    if (pOwner == 'undefined' || pOwner == '' || pOwner == null) {
      pOwner = '';
    }


    if (prfibu == 'undefined' || prfibu == '' || prfibu == null || prfibu == 'Select' ) {
      prfibu = '';
    }

    if (prDate == 'undefined' || prDate == '' || prDate == null) {
      prDate = '';
    }

    //console.log(this.filterForm.value)
    this._rfiService
      .getRfiListbyBU(pOwner, prfibu, prDate)
      .subscribe((data) => {
        this.dataSource = new MatTableDataSource(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
      });
      
  }
 
  
  // checkUncheckAll() {
  //   for (var i = 0; i < this.checklist.length; i++) {
  //     this.checklist[i].isSelected = this.masterSelected;
  //   }
  //   this.getCheckedItemList();
  // }

  // Check All Checkbox Checked
  // isAllSelected() {
  //   this.masterSelected = this.checklist.every(function(item:any) {
  //       return item.isSelected == true;
  //     })
  //   this.getCheckedItemList();
  // }

  // // Get List of Checked Items
  // getCheckedItemList(){
  //   this.checkedList = [];
  //   for (var i = 0; i < this.checklist.length; i++) {
  //     if(this.checklist[i].isSelected)
  //     this.checkedList.push(this.checklist[i]);
  //   }
    
  // }
  // // isAllSelected() {
  //   const numSelected = this.selection.selected.length;
  //   const numRows = this.dataSource.data.length;
  //   return numSelected === numRows;
  // }

  // /** Selects all rows if they are not all selected; otherwise clear selection. */
  // masterToggle() {
  //   this.isAllSelected()
  //     ? this.selection.clear()
  //     : this.dataSource.data.forEach((row) => this.selection.select(row));
  // }

  displayRoleMenuPermission()
    {

      this.userService
      .getMenuPermission(this.commonService.getRoleId(),MenuItems.UserCertificationHome)
      .subscribe((data) => {

        data.forEach(element =>
          {

            if(Permission.View == element.permissionId)
            {
              this.isshowview  = true;
            }
            if(Permission.Upload == element.permissionId )
            {
              this.isshowupload = false;  // in this section we have make false.
            }
            if(Permission.Search == element.permissionId )
            {
              this.isshowsearch = true;
            }

          });
          


      });
    }
  }












