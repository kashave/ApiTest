import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ManagerfidetailsComponent } from './managerfidetails.component';

describe('ManagerfidetailsComponent', () => {
  let component: ManagerfidetailsComponent;
  let fixture: ComponentFixture<ManagerfidetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ManagerfidetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManagerfidetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
