import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RfipopupComponent } from './rfipopup.component';

describe('RfipopupComponent', () => {
  let component: RfipopupComponent;
  let fixture: ComponentFixture<RfipopupComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ RfipopupComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RfipopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
