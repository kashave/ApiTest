import { Component, OnInit, Inject, ɵflushModuleScopingQueueAsMuchAsPossible } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { element } from 'protractor';
import { RfiService } from 'src/app/services/rfi.service';
import { ActivatedRoute } from '@angular/router';

interface DialogData {
  email: string;
}


@Component({
  selector: 'app-rfipopup',
  templateUrl: './rfipopup.component.html',
  styleUrls: ['./rfipopup.component.css'],
  providers: [
    { provide: MAT_DIALOG_DATA, useValue: {} },
    { provide: MatDialogRef, useValue: {} }
  ]
})
export class RfipopupComponent implements OnInit {


  heroes: string[];
  UserId: any = [];
  RFIId: any;
  delegatesplit: string[];
  stringArr: string[] = [];
  listDelegate:string[];
  splitLstDelegate: string[];
  splitListComma: string[];
  splitdata:string[];
  RFD: any;

  dataSource = new MatTableDataSource<any>();
  constructor(public dialog: MatDialog,public dialogRef: MatDialogRef<RfipopupComponent>,
    private route: ActivatedRoute,
    @Inject(MAT_DIALOG_DATA) data , private _rfiService: RfiService,
    ) {
    //  this.RFIId=data.userId

    }
    
    
    public rfiDetails = [];
    public rfiDetailsComma = [];

   onCloseClick(): void {

    this.dialogRef.close();
  }

  ngOnInit() {
    this.RFIId = this.route.snapshot.queryParamMap.get('rfiId');

    this._rfiService
      .getRfiListDetails(this.RFIId)
      .subscribe(
        (data) => {
          (this.rfiDetails = data)
         // console.log(JSON.stringify(data))
          this.rfiDetails.forEach((element) => {
            this.RFD= element.certID;
          this.listDelegate= element.delegate;
          var strSplitdel = new String(this.listDelegate);
          var strSplitValue=strSplitdel.split("$");
          this.splitListComma=strSplitValue;

          this.splitListComma.forEach((splitdata) =>{

            this.rfiDetailsComma.push(splitdata)

          });

        });
     });
  }
}
