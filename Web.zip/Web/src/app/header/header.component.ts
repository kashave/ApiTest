import { Component, OnInit, HostListener } from '@angular/core';
import { Router, ActivatedRoute, NavigationStart } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { CommonService } from '../services/common.service';
import { UserService } from '../services/user.service';

export enum MenuItems {

  UserCertificationHome = 1,
  ACGDashboard = 2,
  CreateandModifyTemplate = 3,
  UseTemplateandFormatData = 4,
  ManageRFDUserList = 5
  

}


export enum Permission {

  View = 1,
  Edit = 2,
  Delete = 3,
  Approve = 4,
  Upload = 5,
  Save = 6,
  Submit = 7,
  Download = 8,
  Search = 9

}



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent {
  showloginname: string = '';
  showrole: string = '';
  showlogin: boolean = false;
  shownavbar: boolean = false;
  showcertification: boolean = false;
  isrfiList: boolean = false;
  ismanagerfddetails: boolean = false;
  isacgdashboard: boolean = false;
  isuseraccessdatamngt: boolean = false;
  ismanagerfduserlist: boolean = false;
  isacgapproval: boolean = false;
  isreports: boolean = false;
  isparsefiles: boolean = false;
  issubmittocampaigntool: boolean = false;
  ismanagerfidetails: boolean = false;
  iscreateandmodifytemplate : boolean= false;
  isusetemplateandformatData : boolean=false;
  isconfirmuserinformation : boolean =false;

  menuitems: string[];
  userroleMenuList: string[];

  certhome: string = '';
  mngrfd: string = '';
  acgdash: string = '';
  useraccessdatamng: string = '';
  mngrfduserlst: string = '';
  acgapproval: string = '';
  reports: string = '';
  sbtcampntool: string = '';
  erroMsg: any;
  createandmodifytemplate ='';
  usetemplateandformatdata = '';
  confirmuserinformation = '';




  @HostListener('window:popstate', ['$event'])
  onPopState(event) {
    this.validateUserSession();

  }
  constructor(
    private router: Router,
    private authService: AuthService,
    private commonservice: CommonService, private userService: UserService, private commonService: CommonService) {

    router.events.forEach((event) => {

      if (event instanceof NavigationStart) {
        if (event['url'] == '/login') {
          this.showlogin = true;
          this.shownavbar = false;
        } else if (event['url'] == '/provisioning') {
          this.showlogin = false;
          this.shownavbar = true;
        } else if (event['url'].indexOf('/certification/') > -1) {

          this.showcertification = true;
          this.getMenuNames();

        } else {
          this.shownavbar = false;
          this.showlogin = false;
          this.showcertification = false;
        }
      }
    });
  }
  ngOnInit() {

    this.validateUserSession();


    // if(this.showrole == 'ApplicationOwner'){
    //   this.isrfiList = true;
    //   this.isuseraccessdatamngt = true;
    //   this.isparsefiles = true;
    //   this.issubmittocampaigntool = true;
    //   this.ismanagerfidetails = true;
    // }
    // else{
    //   this.isrfiList = true;
    //   this.isuseraccessdatamngt = false;
    //   this.isparsefiles = true;
    //   this.issubmittocampaigntool = true;
    //   this.ismanagerfidetails = true;
    // }
  }
  validateUserSession() {
    if (this.authService.getUserProfile() != null) {
      this.showloginname = this.authService.getUserProfile();
    }
    if (this.commonservice.getRoleName() != null) {
      this.showrole = this.commonservice.getRoleName();
    } else {
      this.logout();
    }
  }
  logout() {
    this.showcertification = false;
    this.authService.logout();
  }
  getMenuNames() {
    let menulist: string[] = [];
    this.menuitems = JSON.parse(sessionStorage.getItem("menuList"));
    console.log(this.menuitems);
    if (this.menuitems) {
      this.menuitems.forEach(element => {
        menulist.push(element["menuName"]);
      });
    }
    this.certhome = menulist[MenuItems.UserCertificationHome - 1];
    this.acgdash = menulist[MenuItems.ACGDashboard - 1];
    this.createandmodifytemplate = menulist[MenuItems.CreateandModifyTemplate - 1];
    this.usetemplateandformatdata = menulist[MenuItems.UseTemplateandFormatData - 1];
    this.confirmuserinformation = menulist[MenuItems.ManageRFDUserList - 1];
    
    let userrolemenuids: number[] = [];

    this.userroleMenuList = JSON.parse(sessionStorage.getItem("userRoleMenuList"));
    console.log(this.userroleMenuList);
if(this.userroleMenuList)
{
   this.userroleMenuList.forEach(element => {
      userrolemenuids.push(element["menuId"]);

      if (MenuItems.UserCertificationHome == element["menuId"]) {
        this.isrfiList = true;
      }

     
      if (MenuItems.ACGDashboard == element["menuId"]) {
        this.isacgdashboard = true;
      }

      if (MenuItems.CreateandModifyTemplate ==element["menuId"]) {
        this.iscreateandmodifytemplate = true;
        
      }

      if (MenuItems.UseTemplateandFormatData ==element["menuId"]) {
        this.isusetemplateandformatData = true;
      }

      if (MenuItems.ManageRFDUserList == element["menuId"]) {
        this.isconfirmuserinformation = true;
      }

      

    });


  }

  }
}
