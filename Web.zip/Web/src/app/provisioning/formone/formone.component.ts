import { Component,ViewChild,ViewChildren,QueryList,ElementRef } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';

import { NgForm, FormGroup, FormControl, FormArray, FormBuilder, Validators } from '@angular/forms';

import { MatSnackBar } from "@angular/material/snack-bar";
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { MatRadioGroup } from '@angular/material/radio';
import { Observable, pipe } from 'rxjs';
import { map, filter, scan, startWith } from 'rxjs/operators';
import { $ } from 'protractor';

import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSelect } from '@angular/material/select';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort } from '@angular/material/sort';
import { MatTable } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { dateInputsHaveChanged } from '@angular/material/datepicker/datepicker-input-base';

@Component({
  selector: 'app-formone',
  templateUrl: './formone.component.html',
  styleUrls: ['./formone.component.css']
})
export class FormoneComponent  {


  title = 'Search-by-Database';
  containers = [];

  searchfields: string[] = [
    'Client ID or Client Name',
    'File Name or File Category',
    'Job Name or Job Type'

  ];
  priorities: string[] = [
    'High (3)',
    'Medium (2)',
    'Low (1)'
  ];
  clientNames: any = [];
  add() {
    this.containers.push(this.containers.length);
  }
  applications; selectedAppID;
  schedulers; schedulerbyid; selectedJobName;
  regions; startDate;
  selected = null;
  formOne: FormGroup;
  gatewayproducts; filecategories; starttime; startMins;
  protocoltypes; clienttypes; ttransmissions; jobnames; clientbyid; clientbyid2; clientbyid3; selectedClientName; selectedFileName; selectedJobID;
  files; gatewayproductbyid; regionId; clientsandfiles; jobTypes; jobrowdata;
  selectedClientID; selectedGateWayID; selectedRegionID;
  filteredOptionsCID: Observable<string[]>;
  filteredOptionsCName: Observable<string[]>;
  parsedJson: any; selectedFileID;
  Ischecked; checkboxes: FormArray;
  loadTable: boolean = false;


  weekdays = [
    {
      id: 1,
      title: 'SUN',
      checked: false,
    },
    {
      id: 2,
      title: 'MON',
      checked: false,
    },
    {
      id: 3,
      title: 'TUE',
      checked: false,
    },
    {
      id: 4,
      title: 'WED',
      checked: false,
    },
    {
      id: 5,
      title: 'THU',
      checked: false,
    },
    {
      id: 6,
      title: 'FRI',
      checked: false,
    },
    {
      id: 7,
      title: 'SAT',
      checked: false,
    },
  ]
  // weekdays: string[] = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"]


  checkedItems;
  starttimes: string[] = [
    "12:00 AM", "12:30 AM", "1:00 AM", "1:30 AM",
    "2:00 AM", "2:30 AM", "3:00 AM", "3:30 AM", "4:00 AM",
    "4:30 AM", "5:00 AM", "5:30 AM", "6:00 AM", "6:30 AM",
    "7:00 AM", "7:30 AM", "8:00 AM", "8:30 AM", "9:00 AM",
    "9:30 AM", "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
    "12:00 PM", "12:30 PM", "1:00 PM", "1:30 PM", "2:00 PM",
    "2:30 PM", "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM",
    "5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM", "7:00 PM",
    "7:30 PM", "8:00 PM", "8:30 PM", "9:00 PM", "9:30 PM",
    "10:00 PM", "10:30 PM", "11:00 PM", "11:30 PM"
  ]
  commands: string[] = [
    'Test1',
    'Test2',
    'Test3',
  ]
  sendfailurealarms: string[] = [
    'True',
    'False'
  ];
  notifications: string[] = [
    'Notify',
    'Do Not Notify'
  ];
  pusheditems = [];

  onChange(e) {
    console.log(e.target.value)
    this.pusheditems[e.target.value] = e.target.checked === true ? 'Y' : 'N';
    console.log(this.pusheditems);
  }


  post_params = JSON.stringify([{ 'time': '10 mins' }, { 'time': '15 mins' }]);

  displayedColumns: string[] = ['selected', 'clientName', 'fileName', 'fileCategory', 'jobName', 'jobType'];


  constructor(public dialog: MatDialog,
    private _snackBar: MatSnackBar, private fb: FormBuilder, private http: HttpClient) { }
  AutoFormReset(): void {


    this.formOne.get('jobnameControl').reset();
    this.formOne.get('jobtypeControl').reset();
    this.formOne.get('jobtdescriptionControl').reset();
    this.formOne.get('startdateControl').reset();
    this.formOne.get('starttimeControl').reset();
    this.formOne.get('startminsControl').reset();
    this.formOne.get('sendtomachineControl').reset();
    this.formOne.get('commandControl').reset();

    this.formOne.get('calendarexceptionsControl').reset();
    this.formOne.get('priorityControl').reset();
    this.formOne.get('ownerControl').reset();
    this.formOne.get('runmachineControl').reset();
    this.loadTable = null;




    //   });

  }



  ngOnInit() {

    this.startDate = new Date();

    this.formOne = this.fb.group({
      //validations
      applicationControl: new FormControl(''),
      schedulerControl: new FormControl(''),
      regionControl: new FormControl(''),
      searchfieldControl: new FormControl(''),
      clientnameoridsearchControl: new FormControl(''),
      filenameorfilecategoryControl: new FormControl(''),
      JobnamesearchControl: new FormControl(''),
      jobnameControl: new FormControl(''),
      jobtypeControl: new FormControl(''),
      jobtdescriptionControl: new FormControl(''),
      jobloadControl: new FormControl(''),
      startdateControl: new FormControl('', [Validators.required]),
      starttimeControl: new FormControl(''),
      startminsControl: new FormControl(''),
      sendtomachineControl: new FormControl(''),
      sendfailurealarmControl: new FormControl(''),
      notificationControl: new FormControl(''),
      commandControl: new FormControl(''),
      conditionControl: new FormControl(''),
      calendarexceptionsControl: new FormControl(''),
      priorityControl: new FormControl(''),
      ownerControl: new FormControl(''),
      runmachineControl: new FormControl(''),
      rundaysControl: new FormControl('')
    });


    //////////////////////////////////////


  }


  getRegionID(regionId) {
    this.selectedRegionID = regionId;
    console.log(regionId);
  }

  // getGatewayId(gatewayID) {
  //   if (this.Region) this.Region.focus();
  //   this.selectedGateWayID = gatewayID;
  //   this.schedulingService.getRegionById(this.selectedAppID, gatewayID).subscribe(data => {
  //     this.regionId = data;
  //     console.log(JSON.stringify(data));
  //   });
  // }


}
