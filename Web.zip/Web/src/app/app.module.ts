import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatMenuModule } from '@angular/material/menu';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatGridListModule } from '@angular/material/grid-list';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HomeComponent } from './home/home.component';
import { FooterComponent } from './footer/footer.component';
import { RouterModule } from '@angular/router'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MatDialogModule } from '@angular/material/dialog';

import {MatTabsModule} from '@angular/material/tabs';

import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatSortModule } from '@angular/material/sort';
import { HttpClientModule,HTTP_INTERCEPTORS, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { MatSidenavModule } from '@angular/material/sidenav'
import { DragDropModule } from '@angular/cdk/drag-drop';


import {CdkTreeModule} from '@angular/cdk/tree';
import { LoginComponent } from './login/login.component';
import { HeaderComponent } from './header/header.component';
import { FormoneComponent } from './provisioning/formone/formone.component';

import { CampaignComponent } from './certification/campaign/campaign.component';
import { CampaignlistComponent } from './certification/campaignlist/campaignlist.component';
import { ManagerfidetailsComponent } from './certification/managerfidetails/managerfidetails.component';

import { SubmittoardbComponent } from './certification/submittoardb/submittoardb.component';
import { RfipopupComponent } from './certification/rfipopup/rfipopup.component';

import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { AccessDeniedComponent } from './access-denied/access-denied.component';

import { DocumentUploadComponent } from './certification/documentupload/documentupload.component';
import { ParsefilesComponent } from './certification/parsefiles/parsefiles.component';
import { ChartsModule } from 'ng2-charts';
import { DashboardComponent } from './certification/dashboard/dashboard.component';
import { UserComponent } from './settings/user/user.component';
import { EditDialogComponent } from './settings/user/dialogs/edit/edit.dialog.component';
import { DeleteDialogComponent } from './settings/user/dialogs/delete/delete.dialog.component';
import { AddDialogComponent } from './settings/user/dialogs/add/add.dialog.component';
import { DefaultreportsComponent } from './certification/defaultreports/defaultreports.component';
import { AuthGuard } from './services/auth.guard';
import { RfilistComponent } from './certification/rfilist/rfilist.component';
import { RfiService } from './services/rfi.service';
import { CreatetemplatecsvComponent } from './certification/createtemplatecsv/createtemplatecsv.component';
import { RfifileuploadComponent } from './certification/rfifileupload/rfifileupload.component';
import { ManualentryComponent } from './certification/manualentry/manualentry.component';
import { RfidetailsComponent } from './certification/rfidetails/rfidetails.component';

import {	  MatTreeModule,	}	from	'@angular/material/tree';
import {	  MatStepperModule,	}	from		'@angular/material/stepper';
import {	  MatChipsModule,	}	from		'@angular/material/chips';
import {	  MatTooltipModule,	}	from		'@angular/material/tooltip';
import {	  MatTableModule,	}	from		'@angular/material/table';
import {	  MatListModule,	}	from		'@angular/material/list';
import {	  MatAutocompleteModule,	}	from		'@angular/material/autocomplete';
import {	  MatProgressBarModule,	}	from 	'@angular/material/progress-bar';
import {	  MatProgressSpinnerModule,	}	from 	'@angular/material/progress-spinner';
import {	  MatPaginatorModule	}	from		'@angular/material/paginator';
import { CdkTableModule} from '@angular/cdk/table';
import { AlertdialogComponent } from './modal/alertdialog/alertdialog.component';
import { TemplatepopupComponent } from './certification/templatepopup/templatepopup.component';

import {MatButtonToggleModule} from '@angular/material/button-toggle';
import { ManagerfddetailsComponent } from './certification/managerfddetails/managerfddetails.component';
import { ManagerfduserlistComponent } from './certification/managerfduserlist/managerfduserlist.component';
//import { ApprovalComponent } from './certification/approval/approval.component';
import { ReportsComponent } from './certification/reports/reports.component';
import {ClipboardModule} from '@angular/cdk/clipboard';
import { LoadingComponent }  from './loading/loading';

import { EmployeelookupComponent } from 'src/app/certification/employeelookup/employeelookup.component';


@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    FooterComponent,
    LoginComponent,
    HeaderComponent,
    FormoneComponent,
    CampaignComponent,
    CampaignlistComponent,
    ManagerfidetailsComponent,
    SubmittoardbComponent,
    RfipopupComponent,
    DocumentUploadComponent,
    ParsefilesComponent,
    DashboardComponent,
    EditDialogComponent,
    AddDialogComponent,
    UserComponent,
    PageNotFoundComponent,
    AccessDeniedComponent,
    DeleteDialogComponent,
    DefaultreportsComponent,
    RfilistComponent,
    CreatetemplatecsvComponent,
    RfifileuploadComponent,
    ManualentryComponent,
    AlertdialogComponent,
    ManagerfddetailsComponent,
    ManagerfduserlistComponent,
    //ApprovalComponent,
    ReportsComponent,
    TemplatepopupComponent,
    LoadingComponent,
    RfidetailsComponent,
    EmployeelookupComponent
  ],

  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatToolbarModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatCardModule,
    RouterModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatRadioModule,
    MatCheckboxModule,
    MatDialogModule,
    MatGridListModule,
    MatExpansionModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatProgressBarModule,
    MatAutocompleteModule,
    MatSnackBarModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    MatTableModule,
    MatPaginatorModule,
    MatSortModule,
    MatTooltipModule,
    MatTabsModule,
    MatSidenavModule,
    MatListModule,
    MatChipsModule,

    CdkTreeModule,
    MatTreeModule,
    DragDropModule,
    ChartsModule,
    MatStepperModule,
    CdkTableModule,
    ClipboardModule,
    MatButtonToggleModule,
    MatStepperModule,
    CdkTableModule,
  ],
  entryComponents: [
     RfipopupComponent
   
  ],
  providers: [MatDatepickerModule,AuthGuard,RfiService
  ],
  bootstrap: [AppComponent],

})
export class AppModule {


}
