import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar, MatSnackBarConfig } from "@angular/material/snack-bar";
import { Router } from '@angular/router';
import { AuthService } from '../services/auth.service';
import { CommonService } from '../services/common.service';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  private formSubmitAttempt: boolean;
  userName;
  loading = false;
  showlogin: boolean = false;
  erroMsg: any;
  constructor(private router: Router, private authService: AuthService, private _snackBar: MatSnackBar,
    private commonservice: CommonService, private userService: UserService) {
    this.loginForm = new FormGroup({
      userName: new FormControl('', [Validators.required]),
      password: new FormControl('', [Validators.required])
    });

  }
  ngOnInit(): void {
    sessionStorage.removeItem('currentUser');
    sessionStorage.removeItem('currentUserRole');

  }

  isFieldInvalid(field: string) {
    return (
      (!this.loginForm.get(field).valid && this.loginForm.get(field).touched) ||
      (this.loginForm.get(field).untouched && this.formSubmitAttempt)
    );
  }

  public OnReset() {
    this.loginForm.reset();
  }
  public OnSubmit() {
    debugger;
    const myFormData =
    {
      "username": this.loginForm.value.userName,
      "password": this.loginForm.value.password
    }

    if (this.loginForm.valid) {
      this.loginForm.disable();
      this.authService.login(myFormData).subscribe(
        async data => {
          this.loading = true;
          if (data) {
            let response = await this.authService.getRolePermission(this.loginForm.value.userName);
            if (response) {

              this.userService.getMenu().subscribe(
                (data) => (
                  sessionStorage.setItem('menuList', JSON.stringify(data))),
                (error) => (this.erroMsg = error)
              );
              this.userService.getUserRoleMenu(this.commonservice.getRoleId()).subscribe(
                (data) => (
                  sessionStorage.setItem('userRoleMenuList', JSON.stringify(data))),
                (error) => (this.erroMsg = error)
              );

              if (sessionStorage.getItem('sessionurl')) {

                var urlarray = JSON.parse(sessionStorage.getItem('sessionurl'));
                console.log(urlarray);

                this.router.navigate(["/"]).then(() =>
                  window.location.href = document.location.origin + urlarray)

              }
              else {
                this.router.navigate(["/home"]).then(() => window.location.reload())
              }

            }
            else {
              const snackBarConfig = new MatSnackBarConfig();
              snackBarConfig.verticalPosition = 'top';
              snackBarConfig.duration = 3000;
              snackBarConfig.panelClass = 'center';
              this._snackBar.open("User is not available in AMP Portal", "", snackBarConfig);
              this.loginForm.reset();
              setTimeout(() => {
                this.router.navigate(["/login"]).then(() => window.location.reload())
              }, 3000);
            }
          }
        },
        error => {
          const snackBarConfig = new MatSnackBarConfig();
          snackBarConfig.verticalPosition = 'top';
          snackBarConfig.duration = 3000;
          snackBarConfig.panelClass = 'center';
          this._snackBar.open("Something went wrong.Please try again.", "", snackBarConfig),
            this.loginForm.reset();
          setTimeout(() => {
            this.router.navigate(["/login"]).then(() => window.location.reload())
          }, 3000);
        }
      )
    }

    this.formSubmitAttempt = true;
  }
}
