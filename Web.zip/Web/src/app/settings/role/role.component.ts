import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { Role } from '../../model/role';
import { AddRoleDialogComponent } from './dialogs/add/addrole.dialog.component';
import { EditRoleDialogComponent } from './dialogs/edit/editrole.dialog.component';
import { DeleteRoleDialogComponent } from './dialogs/delete/deleterole.dialog.component';
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})

export class RoleComponent implements OnInit {
  displayedColumns = ['roleName', 'roleTypeName', 'actions'];
  allRoles: any[] = [];

  constructor(
    public dialog: MatDialog,
    
    private _snackBar: MatSnackBar) {
  }

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  dataSource = new MatTableDataSource<any>();

  ngOnInit() {
    this.loadData();
  }

  getAllRoles() {
    // this.userService.getAllRoles().subscribe(data => {
    //   this.allRoles = data;
    // });
  }

  addNew() {
    const dialogAdd = this.dialog.open(AddRoleDialogComponent, {
      data: { Role: Role }
    });

    dialogAdd.afterClosed().subscribe(result => {
      if (result === 1) {
        setTimeout(() => {
          this.loadData();
          this._snackBar.open('Saved successfully!', 'Success', {
            duration: 3000,
            verticalPosition: 'top'
          });
        }, 1000);

      }
    });
  }

  startEdit(roleId: number, roleName: string, roletypeId: number) {
    const dialogEdit = this.dialog.open(EditRoleDialogComponent, {
      data: { roleId: roleId, roleName: roleName, roletypeId: roletypeId }
    });

    dialogEdit.afterClosed().subscribe(result => {
      if (result === 1) {
        setTimeout(() => {
          this._snackBar.open('Updated successfully', 'Success', {
            duration: 1000,
            verticalPosition: 'top'
          });
          this.loadData();
        }, 1000);
        
      }
    });
  }

  deleteItem(roleId: number, roleName: string, roleTypeId: number, roleTypeName: string) {
    const dialogDelete = this.dialog.open(DeleteRoleDialogComponent, {
      data: { roleId: roleId, roleName: roleName, roleTypeId: roleTypeId, roleTypeName: roleTypeName }
    });

    dialogDelete.afterClosed().subscribe(result => {
      if (result === 1) {
       setTimeout(() => {
        this._snackBar.open('Deleted successfully', 'Success', {
          duration: 1000,
          verticalPosition: 'top'
        });
        this.loadData();
       }, 1000);
      }
    });
  }

  loadData() {
    // this.userService.getAllRoles().subscribe(data => {
    //   this.dataSource = new MatTableDataSource(data);
    //   setTimeout(() => {
    //     this.dataSource.paginator = this.paginator;
    //     this.dataSource.sort = this.sort;
    //   });
    // });

  }
}



