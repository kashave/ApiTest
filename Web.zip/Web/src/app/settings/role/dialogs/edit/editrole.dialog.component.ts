import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-editrole.dialog',
  templateUrl: '../../dialogs/edit/editrole.dialog.html',
  styleUrls: ['../../dialogs/edit/editrole.dialog.css']
})
export class EditRoleDialogComponent implements OnInit {

  editRoleForm: FormGroup;
  allRolesType: any[] = [];

  constructor(public dialogRef: MatDialogRef<EditRoleDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any, private fb: FormBuilder) {
    dialogRef.disableClose = true;
  }

  formControl = new FormControl('', [
    Validators.required
    // Validators.email,
  ]);

  ngOnInit() {
    this.getAllRolesType();

    this.editRoleForm = this.fb.group({
      //validations
      roleNameControl: new FormControl(''),
      roletypeIdControl: new FormControl('')
    });
  }

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  onNoClick(): void {
    this.dialogRef.close();
  }
  submit() {

  }

  stopEdit(): void {
    const myFormData =
    {
      "RoleId": this.data.roleId,
      "RoleName": this.editRoleForm.value.roleNameControl,
      "RoleTypeId": this.editRoleForm.value.roletypeIdControl,
      "CreatedBy": 1//this.authService.getUserId()
    }

    // this.userService.updateRole(myFormData).subscribe(
    //   data => {
    //   });
  }

  getAllRolesType() {
    // this.userService.getLookType('Role').subscribe(data => {
    //   this.allRolesType = data;
    // });
  }
}
