import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject, OnInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
//import {User} from '../../../../modals/user';
//import {UserService} from '../../../../services/user.service';
import {FormGroup, FormBuilder } from '@angular/forms';
import { User } from 'src/app/model/user';
//import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-addrole.dialog',
  templateUrl: '../../dialogs/add/addrole.dialog.html',
  styleUrls: ['../../dialogs/add/addrole.dialog.css']
})

export class AddRoleDialogComponent implements OnInit {
  addRoleForm: FormGroup;
  allRolesType:any[] = [];

  constructor(public dialogRef: MatDialogRef<AddRoleDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: User,
               private fb: FormBuilder) {
                dialogRef.disableClose=true;
               }

  formControl = new FormControl('', [
    Validators.required
    //Validators.email,
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  ngOnInit() {
    this.getAllRolesType();

    this.addRoleForm = this.fb.group({
      //validations
      roleNameControl: new FormControl(''),
      roletypeIdControl: new FormControl('')
    });
  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  submit(){
  }

  public confirmAdd(): void {

    const myFormData =
    {
      "RoleId": 0,
      "RoleName": this.addRoleForm.value.roleNameControl,
      "RoleTypeId": this.addRoleForm.value.roletypeIdControl,
      "CreatedBy": 1//this.authService.getUserId()
    }

    // this.userService.addRole(myFormData).subscribe(
    //   data => {
    //   });
  }

  getAllRolesType(){
  //   this.userService.getLookType('Role').subscribe(data => {
  //   this.allRolesType = data;
  // });
  }

}
