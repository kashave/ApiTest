import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject} from '@angular/core';
//import {UserService} from '../../../../services/user.service';
//import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-deleterole.dialog',
  templateUrl: '../../dialogs/delete/deleterole.dialog.html',
  styleUrls: ['../../dialogs/delete/deleterole.dialog.css']
})
export class DeleteRoleDialogComponent {

  constructor(public dialogRef: MatDialogRef<DeleteRoleDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any
              ) {
                dialogRef.disableClose=true;
               }

  onNoClick(): void {
    this.dialogRef.close();
  }

  confirmDelete(): void {
    const myFormData =
    {
      "RoleId": this.data.roleId,
      "RoleName": this.data.roleName,
      "RoleTypeId": this.data.roleTypeId,
      "RoleTypeName": this.data.roleTypeName,
      "CreatedBy": 1//this.authService.getUserId() 
    }
    // this.userService.deleteRole(myFormData).subscribe(
    //   data => {
    //   });
  }
}
