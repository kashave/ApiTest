import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

import { AddDialogComponent } from './dialogs/add/add.dialog.component';
import { EditDialogComponent } from './dialogs/edit/edit.dialog.component';
import { DeleteDialogComponent } from './dialogs/delete/delete.dialog.component';
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar } from '@angular/material/snack-bar';
import { UserService } from '../../services/user.service';
import {CommonService} from '../../services/common.service';

export class User {
  userId: number;
  email: string;
  //isactive: boolean;
  roleId?: number;
  roleName: string;
  userName: string;
  firstname: string;
  lastname: string;
  PCUserName: string;
}

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css'],
})
export class UserComponent implements OnInit {
  displayedColumns = [
    'userID',
    'userName',
    'firstName',
    'lastName',
    'role',
    'email',
    //'isActive',
    'actions',
  ];
  allRoles: any[] = [];
  public isshow: boolean = false;

  constructor(
    public dialog: MatDialog,
    private _snackBar: MatSnackBar,
    private userService: UserService,
    private commonService: CommonService


  ) {}
  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;

  dataSource: MatTableDataSource<any>;
  pageSize = window.innerWidth < 1440 ? 10 : 18;
  ngOnInit() {

    if(this.commonService.getRoleId()== 3 || this.commonService.getRoleId() == 1) // 1 = Admin , 3 = ACGMember 
    {
      this.isshow = false;  // Here isshow  false means we are giving add,edit,delete for ACG and Admin
    }
    else
    {
      this.isshow = true;
    }

    this.getAllRoles();
    this.getallUsers();
  }

  getallUsers() {
    this.userService.getUserList(this.commonService.getRoleId()).subscribe((data) => {
      //console.log(JSON.stringify(data));
      this.dataSource = new MatTableDataSource(data);
      this.dataSource.paginator = this.paginator;
      this.dataSource.sort = this.sort;
    });
  }
  getAllRoles() {
    // this.userService.getAllRoles().subscribe(data => {
    //   this.allRoles = data;
    // });
  }

  addNew() {
    const dialogAdd = this.dialog.open(AddDialogComponent, {
      data: { User: User },
      width: "65%"
    });

    dialogAdd.afterClosed().subscribe((result) => {
      if (result === 1) {
        setTimeout(() => {
          this.getallUsers();
          //this._snackBar.open('Saved Successfully', 'Success', {
            //duration: 1000,
            //verticalPosition: 'top',
          //});
        }, 1000);
      }
    });
  }

  startEdit(row) {
    debugger;
    const dialogEdit = this.dialog.open(EditDialogComponent, {
      data: row,
      width: "65%"
    });

    dialogEdit.afterClosed().subscribe((result) => {
      if (result === 1) {
        setTimeout(() => {
          this.getallUsers();
          this._snackBar.open('Updated successfully!', 'Success', {
            duration: 3000,
            verticalPosition: 'top',
          });
        }, 1000);
      }
    });
  }

  deleteItem(userId: number, email: string, roleId: number, roleName: string,userName:string) {
    const dialogRef = this.dialog.open(DeleteDialogComponent, {
      data: {
        userId: userId,
        email: email,
        roleId: roleId,
        roleName: roleName,
        userName : userName
      },
      width: "650px"
    });

    

    dialogRef.afterClosed().subscribe((result) => {
      if (result === 1) {
        setTimeout(() => {
          this.getallUsers();
         
        }, 1000);
      }
    });
  }

  loadData() {
    // var data: User[] = [
    //   {
    //     firstname: 'maha',
    //     lastname: 'lakshmi',
    //     username: 'msaminathan',
    //     isactive: true,
    //     email: 'mahalakshmi.saminathan@fiserv.com',
    //     userId: 1,
    //     roleName: 'Admin',
    //   },
    // ];

    //  this.dataSource = new MatTableDataSource(data);
    //     this.dataSource.paginator = this.paginator;
    //     this.dataSource.sort = this.sort;

    // this.userService.getAllUser().subscribe(data => {
    //   this.dataSource = new MatTableDataSource(data);
    //   this.dataSource.paginator = this.paginator;
    //   this.dataSource.sort = this.sort;
    // });
  }
}
