import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject, OnInit,ViewChild, AfterViewInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import { FormGroup, FormBuilder } from '@angular/forms';
import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { SelectionModel} from '@angular/cdk/collections';
import { debug } from 'console';
import { MatDialog } from '@angular/material/dialog';
import { AlertdialogComponent } from 'src/app/modal/alertdialog/alertdialog.component';
import { RfiService } from 'src/app/services/rfi.service';



export class UserUpsertModel {
  firstName: string;
  lastName: string;
  userName: string;
  role : string;
  roleID : number;
  email: string;
  isActive : boolean;
  buid: number;
  UserId : number;
  createdBy? : number;
  modifiedBy? : number;
  DelegateId? : number;
  UserRfdIds : string;
  UserLoginRoleId? :number;
}

@Component({
  selector: 'app-baza.dialog',
  templateUrl: '../../dialogs/edit/edit.dialog.html',
  styleUrls: ['../../dialogs/edit/edit.dialog.css']
})
export class EditDialogComponent  implements OnInit{

  toppings = new FormControl();
  editUserForm: FormGroup;
  allRoles:any[] = [];
  allBUs:any[] = [];
  currentUser:any =[];
  roleOwner:number;
  strroleowner:string;
  appstatus:any;
  userappCount : any;

  existingRoleId : any;
  cUserId : any ;
  public isshowapplications : boolean = false;
  public appselected: number[] = [];

  public appOwners = [];
  public multiRfds = [];
  public appOwnerandRfds = [];
  public finalAppownerRFDs :string ;

  public isshowappowners : boolean = false;
  public isshowappownerrfds : boolean = false;
  isClose: boolean;
  isRfdClose : boolean;
  valueSelected : string;
  erroMsg: any;

  multiappownerControl = new FormControl();

multirfdControl = new FormControl();
appOwnerselected: number[] = [];
appOwnerRfdsselected : number[] = [];

  //public approvalstatus=[];
  public gaugeTitles= [];
  appArray : any[] = [];
  displayedColumns: string[] = [
    'select',
    'Description',
   ];
   @ViewChild(MatPaginator) paginator: MatPaginator;
   @ViewChild(MatSort) sort: MatSort;
   dataSource = new MatTableDataSource<any>();
   selection = new SelectionModel<any>(true, []);
  constructor(public dialogRef: MatDialogRef<EditDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: any,
               private fb: FormBuilder,private userService: UserService,
               private commonService : CommonService,
               public dialog: MatDialog,
                private _snackBar: MatSnackBar,private rfiService :RfiService) {
                dialogRef.disableClose=true;
                this.getAllRoles();
                this.getAllBUs();
                console.log('constructor : ' + JSON.stringify(data));

                }

 // formControl = new FormControl('', [Validators.required]);

  ngOnInit() {
    
   // this.getUser(this.data.userID);

   this.userService.getUser(this.data.userID).subscribe(data => {
        debugger;
        this.currentUser = data[0];
        this.existingRoleId = data[0].roleID;
        //this.cUserId = data[0].UserID;

        if(this.commonService.getRoleId()== 3 && data[0].roleID == 6 )
        {
          this.isshowappowners = true;
          this.isshowappownerrfds =true;
        }
   })

   this.userService.getValidateUserWithRFIs(this.data.userName).subscribe(data => {

    this.userappCount = data;
   })

 
    
 
 this.userService.GetApplicationOwners().subscribe(
    (data) => (this.appOwners = data),
    (error) => (this.erroMsg = error)
  );


  //this.multiappownerControl.setValue(this.selected)
  
 
  this.rfiService
      .GetUserRFDs("0",this.data.userID)
      .subscribe((data: any)=> {                     
        data.forEach(element => {              
        //alert(element.applicationOwneruserId);
        this.appOwnerselected.push(element.applicationOwneruserId);
        this.appOwnerRfdsselected.push(element.id);

    });
    this.multiappownerControl.setValue(this.appOwnerselected);
    
    
    //this.appOwnerselected.toString()
    
    this.rfiService.GetUserRFDs(this.appOwnerselected.toString(),0).subscribe(
      (data) => (this.multiRfds = data),
      (error) => (this.erroMsg = error)
    );

  this.multirfdControl.setValue(this.appOwnerRfdsselected);
    });
     
    
    //alert('test');
     //alert(this.selected[0]);

    this.editUserForm = this.fb.group({
      //validations
      emailControl: new FormControl(''),
      roleIdControl: new FormControl(''),
      BUIdControl: new FormControl(''),
      firstnameControl: new  FormControl(''),
      lastnameControl : new FormControl(''),
      usernameControl: new  FormControl(''),
      multiappownerControl : new FormControl('')
    });
    
     
   if(this.data.role=="ApplicationOwner")
    {
      this.isshowapplications  = true;
      this.userService.getApplicationList(this.data.firstName,this.data.lastName)
      .subscribe((data) => {
        let delUserName;
        let delStatuses;
        data.forEach(element => {
          const evid : any = {
            delUserName :  element.description,
            delStatuses :element.statuses
           }
         this.appArray.push(evid)
         });
    
      });
      
     
    }
   
    // this.fetchTableData(selectApp);
  }



  submit(){

  }

  isAllSelected() {
    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.data.length;
    return numSelected === numRows;
   }
 
   /** Selects all rows if they are not all selected; otherwise clear selection. */
   masterToggle() {
     this.isAllSelected()
       ? this.selection.clear()
       : this.dataSource.data.forEach((row) => this.selection.select(row));
   }

  onNoClick(): void {
    this.dialogRef.close();
  }

  confirmEdit(): void {
    var saveModel : UserUpsertModel = new UserUpsertModel();
    saveModel.firstName = this.editUserForm.value.firstnameControl;
    saveModel.lastName = this.editUserForm.value.lastnameControl;    
    saveModel.userName = this.currentUser.userName;
    saveModel.role = "";
    saveModel.email = this.editUserForm.value.emailControl;
    saveModel.isActive = true;
    saveModel.UserId=this.data.userID;
    saveModel.buid = this.editUserForm.value.BUIdControl;
    saveModel.createdBy = 0;
    saveModel.modifiedBy = this.commonService.getUserId();
    saveModel.roleID = this.editUserForm.value.roleIdControl;

    // new added for  when selecting user loging as ACG and select role as RFD delete 
    saveModel.DelegateId = 0; // intial it will be 0 .
    saveModel.UserRfdIds = this.finalAppownerRFDs;
    saveModel.UserLoginRoleId = this.commonService.getRoleId();
 

    this.userService.UserUpsert(saveModel).subscribe(
    )
    // this.userService.updateUser(myFormData).subscribe(
    //   data => {
    //   });
  }

  getAllRoles(){
    this.userService.getAllRoles(this.commonService.getRoleId()).subscribe(data => {
     this.allRoles = data;

   //  console.log(this.allRoles);
   });
  }

  fetchTableData(appSelected : any){

    this.appstatus=appSelected.value;
    if(this.roleOwner==2)
    {
    if(appSelected.value==0)
    {
      setTimeout(() => {
        this._snackBar.open('Application not Selected!', 'Success', {
          duration: 8000,
          verticalPosition: 'top',
        });
      }, 1000);
    }
    else{
      setTimeout(() => {
        this._snackBar.open('Application is already selected!', 'Success', {
          duration: 8000,
          verticalPosition: 'top',
        });
      }, 1000); 
    }
  
  }
  else{
    if(appSelected.value==0)
    {
      setTimeout(() => {
        this._snackBar.open('Application not Selected!', 'Success', {
          duration: 8000,
          verticalPosition: 'top',
        });
      }, 1000);
    }
    else{
      setTimeout(() => {
        this._snackBar.open('Application is already selected!', 'Success', {
          duration: 8000,
          verticalPosition: 'top',
        });
      }, 1000); 
    }
  

  }
           
  }

  getAllBUs(){
    this.userService.getAllBUs().subscribe(data => {
     this.allBUs = data;
    // console.log(this.allBUs);
   });
  }

  onRoleChange(ob) {
    if(ob.value == 2 ) //if user has seleted 2- For ApplicationOwner
    {
    this.isshowapplications  = true;
    }
    else
    {
      this.isshowapplications  = false;
    }
    //alert(this.existingRoleId);

//alert(this.userappCount)

if(this.commonService.getRoleId()== 3) //3- For ACGMember

{

        if(ob.value==6 ) //6 means RFD delegate
        {

        this.isshowappowners   = true;
        this.isshowappownerrfds = true;
       
        this.userService.GetApplicationOwners().subscribe(
          (data) => (this.appOwners = data),
          (error) => (this.erroMsg = error)
        );

        
      }
      else
      {
        this.isshowappowners = false;
        this.isshowappownerrfds =false;
      }
 

if(this.userappCount > 0)

{

if(ob.value == 3 || ob.value == 6) // if user has seleted 3- For ACGMember // 6 - RFDDelagate from dropdown

{

//alert("User is already asscociated to applications you can't change the role for this user.")

this.dialog.open(AlertdialogComponent, {

width: '450px',



data: {

message: 'User is already asscociated to applications you can not change the role for this user.',

}

});

this.editUserForm.controls['roleIdControl'].setValue(this.existingRoleId);
if(this.existingRoleId == 2) // if role is 2: for Application Owner
{
 this.isshowapplications = true;
}



}

}

}

    
    //US_91 Change
    let selectedRole = ob.value;
    this.roleOwner=selectedRole;
    if(selectedRole==2 || this.data.role==2)
    {
    this.userService.getApplicationList(this.data.firstName,this.data.lastName)
      .subscribe((data) => {
        let delUserName;
        let delStatuses;
        data.forEach(element => {
          const evid : any = {
            delUserName :  element.description,
            delStatuses :element.statuses
          }
         this.appArray.push(evid)
       
        });
    
       });
    }
  }

  getAppOwnerValues(event)
{
  
  this.isClose = false;
  if(!event)
  {
  
   this.isClose = true;
    
   this.valueSelected =   this.multiappownerControl.value.toString();
  

   if(this.valueSelected == "")
   {
    this.valueSelected = "0";
   }

   this.isshowappownerrfds = true;
   //alert(this.valueSelected);
   this.rfiService.GetUserRFDs(this.valueSelected,0).subscribe(
    (data) => (this.multiRfds = data),
    (error) => (this.erroMsg = error)
  );
     
   //alert(this.valueSelected);
   
  }
}




getAppOwnerRfDs(event)
{
  
  this.isRfdClose = false;
  if(!event)
  {
  
   this.isRfdClose = true;
    
   this.finalAppownerRFDs =   this.multirfdControl.value.toString();

   //alert(this.finalAppownerRFDs)
       
   
  }
}

 
}
