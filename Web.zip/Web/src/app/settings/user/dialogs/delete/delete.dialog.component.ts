import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { Component, Inject } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';
import {RfiService} from 'src/app/services/rfi.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
//import {UserService} from '../../../../services/user.service';
//import { AuthService } from 'src/app/services/auth.service';
export class UserDeleteModel {
  userID: bigint;
}


@Component({
  selector: 'app-delete.dialog',
  templateUrl: '../../dialogs/delete/delete.dialog.html',
  styleUrls: ['../../dialogs/delete/delete.dialog.css'],
})
export class DeleteDialogComponent {
  userID: number;
  gaugeTitles: string[];
  userId:string;
  //delUserName: number;
  showrole: string = '';
  constructor(
    public dialogRef: MatDialogRef<DeleteDialogComponent>,
    private commonService: CommonService,
    @Inject(MAT_DIALOG_DATA) public data: any,private _snackBar: MatSnackBar,private userService: UserService,private commonservice: CommonService,private rfiService: RfiService  )
    {
    dialogRef.disableClose = true;
  }

  onNoClick(): void {
   this.dialogRef.close();
  }

  confirmDelete(): void {
    debugger;
    this.userId = this.commonService.getUserName();
    // alert(this.userId)
    // alert(this.data.userName)
    if (this.commonservice.getRoleName() != null) {
      this.showrole = this.commonservice.getRoleName();
    } 
   // alert(this.showrole)
    this.rfiService.deleteApplicationList(this.data.userName)
      .subscribe((result) => {
        let delUserName;
        result.forEach(element => {
          // const evid : any = {
          //   delUserName :  element.appCount
          // }
         // this.gaugeTitles.push(evid.appCount)
          
        
          //  Asset: element.asset,
        //this.delUserName=result["appCount"];
       
      
     // alert(element.appCount)
    //  alert(this.userId)
    //  alert(this.data.userName)
    var strUserName = this.userId; 
    strUserName.toLowerCase()
     if(strUserName==this.data.userName)
     {
      setTimeout(() => {
        this._snackBar.open('Cannot delete his own logged in user', 'Fail',{
          duration: 3000,
          verticalPosition: 'top',
        });
      }, 1000);
     }
     else       
    if((this.showrole=="Admin" || this.showrole=="ACGMember") && (element.appCount == 0))
    {   
    var userDeleteModel: UserDeleteModel = new UserDeleteModel();

    userDeleteModel.userID = this.data.userId;
    const myFormData = {
      userID: this.data.userId,
    };
    this.userID = this.data.userId;
    this.userService.deleteUser(this.userID).subscribe((data) => {});
    setTimeout(() => {
      this._snackBar.open('Deleted Successfully!', 'Success',{
        duration: 3000,
        verticalPosition: 'top',
      });
    }, 1000);
    }
    else{ setTimeout(() => {
      this._snackBar.open('Does not have authority to delete!', 'fail', {
        duration: 3000,
        verticalPosition: 'top',
      });
    }, 1000);}
  });
});
  }
}
