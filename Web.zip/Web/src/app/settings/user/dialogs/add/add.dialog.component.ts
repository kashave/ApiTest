import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import {Component, Inject, OnInit,ViewChild, AfterViewInit} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';

import { NgForm, FormGroup,  FormArray, FormBuilder } from '@angular/forms';
import { MatSnackBar, MatSnackBarConfig } from '@angular/material/snack-bar';
import { UserService } from 'src/app/services/user.service';
import { CommonService } from 'src/app/services/common.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';

import {MatDialog} from '@angular/material/dialog';
import { AlertdialogComponent } from 'src/app/modal/alertdialog/alertdialog.component';
import { RfiService } from 'src/app/services/rfi.service';

export class User {
  userId:number;
  email:string;
  isactive:boolean;
  roleId?:number;
  roleName:string;
  username:string;
  firstname:string;
  lastname:string;
  ID?:number;
  BUName?:string;
}

export class UserUpsertModel {
  firstName: string;
  lastName: string;
  userName: string;
  role : string;
  roleID : number;
  email: string;
  isActive : boolean;
  buid: number;
  UserId : number;
  createdBy? : number;
  modifiedBy? : number;
  DelegateId? : number;
  UserRfdIds : string;
  UserLoginRoleId? :number;
  
}

@Component({
  selector: 'app-add.dialog',
  templateUrl: '../../dialogs/add/add.dialog.html',
  styleUrls: ['../../dialogs/add/add.dialog.css']
})

export class AddDialogComponent implements OnInit {
  addUserForm: FormGroup;
  toppings = new FormControl();
  allRoles:any[] = [];
  allBUs:any[] = [];
  appArray : any[] = [];
  //appOwners : any[] = [];
  public appOwners = [];
  public multiRfds = [];
  public finalAppownerRFDs :string ;

  roleId = 19;
  buId = 1;
  allUser : any[] = [];
  roleOwner:number;
  currentUser : string =''; 
  userCount : number;
  displayedColumns: string[] = [
    'select',
    'Description',
   ];
  public isshowapplications : boolean = false;
  public isshowappowners : boolean = false;
  public isshowappownerrfds : boolean = false;
  isClose: boolean;
  isRfdClose : boolean;
  valueSelected : string;
  erroMsg: any;



multiappownerControl = new FormControl();

multirfdControl = new FormControl();
  
  //multiappownerControl = new FormControl();
  
  //  @ViewChild(MatPaginator) paginator: MatPaginator;
  //  @ViewChild(MatSort) sort: MatSort;
   dataSource = new MatTableDataSource<any>();
  constructor(public dialogRef: MatDialogRef<AddDialogComponent>,
              @Inject(MAT_DIALOG_DATA) public data: User,
               private fb: FormBuilder,private userService: UserService,
               private commonService : CommonService,public dialog: MatDialog,private rfiService :RfiService,
               private _snackBar: MatSnackBar) {
                dialogRef.disableClose=true;
               }

  formControl = new FormControl('', [
    Validators.required
    //Validators.email,
  ]);

  getErrorMessage() {
    return this.formControl.hasError('required') ? 'Required field' :
      this.formControl.hasError('email') ? 'Not a valid email' :
        '';
  }

  ngOnInit() {
    this.getAllRoles();
    this.getAllBUs();
    this.addUserForm = this.fb.group({
      //validations
      emailControl: new FormControl(''),
      roleIdControl: new FormControl(''),
      firstnameControl: new  FormControl(''),
      lastnameControl : new FormControl(''),
      usernameControl: new  FormControl(''),
      BUIdControl:new FormControl(),
      isActiveControl : new FormControl(''),
      multiappownerControl : new FormControl('')


    });
  }

 
fetchTableData(appSelected : any){

  if(this.roleOwner==2)
  {
  if(appSelected.value==0)
    {
      setTimeout(() => {
        this._snackBar.open('Application not Selected!', 'Success', {
          duration: 8000,
          verticalPosition: 'top',
        });
      }, 1000);
    }
    else{
      setTimeout(() => {
        this._snackBar.open('Application is already selected!', 'Success', {
          duration: 8000,
          verticalPosition: 'top',
        });
      }, 1000); 
    }
  }
  
}

  submit(){

  }

  onNoClick(): void {
    this.dialogRef.close();
  }

  public confirmAdd(): void {    
    debugger;
    //console.log(this.addUserForm.value.multiappownerControl);
    //console.log(this.addUserForm.controls.multiappownerControl.patchValue([]));


    var saveModel : UserUpsertModel = new UserUpsertModel();
    saveModel.firstName = this.addUserForm.value.firstnameControl;
    saveModel.lastName = this.addUserForm.value.lastnameControl;
    saveModel.userName = this.addUserForm.value.usernameControl;
    saveModel.role = "";
    saveModel.email = this.addUserForm.value.emailControl;
    saveModel.isActive = true;
    saveModel.UserId=0;
    saveModel.buid = this.buId;
    saveModel.createdBy = this.commonService.getUserId();
    saveModel.modifiedBy = 0;
    saveModel.roleID = this.roleId;

    // new added for  when selecting user loging as ACG and select role as RFD delete 
    saveModel.DelegateId = 0; // intial it will be 0 .
    saveModel.UserRfdIds = this.finalAppownerRFDs;
    saveModel.UserLoginRoleId = this.commonService.getRoleId();
 

    this.userService.getUserList(this.commonService.getRoleId()).subscribe((data) => {
      this.allUser = data;
      this.currentUser = this.addUserForm.value.usernameControl;      
      var v = this.allUser.filter( x=> x.userName == this.currentUser)
      if(v.length === 1)
      {
       // alert('User Name  ' +this.currentUser + ' already exists ');
        //this.dialog.open(AlertdialogComponent, {
          ///width: '450px',
          
         //data: {
           // message: 'User Name "' +   this.currentUser   + '" already exists.',
          //}
        //}); 
        //return;  
        
        setTimeout(() => {
            this._snackBar.open('User Name ' +   this.currentUser   + '  already exists.', 'OK', {
            duration: 3500,
            verticalPosition: 'top',
          });
        }, 1000);
      }
      else
      {
 
        if(this.commonService.getRoleId() == 3 && saveModel.roleID == 6 )

         {
          this.userService.ValidateUserWithWorkDay(saveModel.firstName,saveModel.lastName,saveModel.email).subscribe(data => {

            this.userCount = data;
            
            if(this.userCount == 1)
           {
                this.userService.UserUpsert(saveModel).subscribe(
                )
      
                setTimeout(() => {
                  this._snackBar.open('Saved Successfully!', 'Success',{
                    duration: 3000,
                    verticalPosition: 'top',
                  });
                }, 1000);
           }
           else
           {
             // this.dialog.open(AlertdialogComponent, {
                //width: '450px',
                
                //data: {
                //  message: "Invalid User ,User is not associated with workday Please Check.",
                //}
              //}); 
              //return; 
              setTimeout(() => {
                this._snackBar.open('Invalid User, User is not associated with workday please check.', 'OK', {
                duration: 3500,
                verticalPosition: 'top',
              });
            }, 1000);

           }
             
           })
           //alert(this.userCount)
           
         }
         else
         {
           
        this.userService.UserUpsert(saveModel).subscribe(
          )

          setTimeout(() => {
            this._snackBar.open('Saved Successfully!', 'Success',{
              duration: 3000,
              verticalPosition: 'top',
            });
          }, 1000);
      }
    }
    });
  }

  getAllRoles(){
    this.userService.getAllRoles(this.commonService.getRoleId()).subscribe(data => {
     this.allRoles = data;
   });
  }

  getAllBUs(){
    this.userService.getAllBUs().subscribe(data => {
     console.log(JSON.stringify(data));
     this.allBUs = data;
   });
  }

  onRoleChange(ob) 
  {
    debugger;
  let selectedRole = ob.value;
  this.roleOwner=selectedRole;
  if(selectedRole!=2) //2 means ApplicationOwner
  {
   this.isshowapplications = false;
  }
  else
  {
  this.isshowapplications = true;
  }

  if(selectedRole==2) //2 means ApplicationOwner
  {
   
  this.userService.getApplicationList(this.data.firstname,this.data.lastname)
    .subscribe((data) => {
      let delUserName;
      let delStatuses;
      data.forEach(element => {
        const evid : any = {
          delUserName :  element.description,
          delStatuses :element.statuses
        }
       this.appArray.push(evid)
      
      
        //  Asset: element.asset,
      //this.delUserName=result["appCount"];
     
    
   
     
      });
  
   });
  }


  if(this.commonService.getRoleId() == 3 ) //3- For ACGMember
  { 
        if(selectedRole==6 ) //6 means RFD delegate
        {

        this.isshowappowners   = true;
       
        this.userService.GetApplicationOwners().subscribe(
          (data) => (this.appOwners = data),
          (error) => (this.erroMsg = error)
        );

        
      }
      else
      {
        this.isshowappowners   = false;
        this.isshowappownerrfds = false;
      }
  }
}


getAppOwnerValues(event)
{
  
  this.isClose = false;
  if(!event)
  {
  
   this.isClose = true;
    
   this.valueSelected =   this.multiappownerControl.value.toString();
  

   if(this.valueSelected == "")
   {
    this.valueSelected = "0";
   }

   this.isshowappownerrfds = true;

   this.rfiService.GetUserRFDs(this.valueSelected,0).subscribe(
    (data) => (this.multiRfds = data),
    (error) => (this.erroMsg = error)
  );
     
   //alert(this.valueSelected);
   
  }
}




getAppOwnerRfDs(event)
{
  
  this.isRfdClose = false;
  if(!event)
  {
  
   this.isRfdClose = true;
    
   this.finalAppownerRFDs =   this.multirfdControl.value.toString();

   //alert(this.finalAppownerRFDs)
       
   
  }
}

}
