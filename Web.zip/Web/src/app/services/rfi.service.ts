import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpParams } from '@angular/common/http';
import { Observable, throwError, Subject } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import {CommonService}from '../services/common.service';
import { IRFIList } from '../interfaces/IRFIList';
import { IRFIListDetails } from '../interfaces/IRFIListDetails';
import { IRFDUserListDetails } from '../interfaces/IRFDUserListDetails';
import { promise } from 'protractor';
import { IValidAndUpdate } from '../interfaces/IValidAndUpdate';

@Injectable({
  providedIn: 'root'
})
export class RfiService {

  json;
  errorMessage = "";
  apiBaseUrl = this.ApiBaseUrl();
  config = {
    headers: {
      'Content-Type': 'application/json;charset=utf-8;'
    }
  }

  ApiBaseUrl() {
		return this.commonService.apiBaseUrl;
	}

  constructor(private http: HttpClient, private commonService:CommonService) { }
  private _refreshneeded$ = new Subject<void>();
  get refreshneeded() {
    return this._refreshneeded$;
  }

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json'
    })
  }


  getApplicationSearchList(pageIndex: number, pageSize: number, searchText: string): Observable<any> {
    return this.http.get(this.apiBaseUrl + "/api/applications/GetApplicationSearch/" + pageIndex + "/" + pageSize + "/" + searchText).pipe(
      catchError(this.handleError)
    );
  }

  getApplicationSearchListExport(searchText: string): Observable<any> {
    return this.http.get(this.apiBaseUrl + "/api/applications/GetExportApplicationData/"+ searchText).pipe(
      catchError(this.handleError)
    );
  }
  
  getApplicationList(): Observable<any> {
    return this.http.get(this.apiBaseUrl + "/api/applications/GetApplicationsList/").pipe(
      catchError(this.handleError)
    );
  }


  getRFIDocumentList(rfiId: any): Observable<any> {
    const params = new HttpParams()
         .set('rfiId', rfiId);
    return this.http.get(this.apiBaseUrl + "/api/rfi/GetRFIDocumentList",{params}).pipe(
      catchError(this.handleError)
    );
  }
   async getRFIDetailList(userId: string,role:string,cDate:string): Promise<any> {
         const params = new HttpParams()
         .set('userId', userId)
         .set('role', role)
         .set('campaignDate',cDate)               
           return this.http.get(this.apiBaseUrl + "/api/RFI/GetRFIList",{params}).pipe(
             retry(3), // retry a failed request up to 3 times
             catchError(this.handleError) // then handle the error
           ).toPromise();

  }

  

  postApplicationDetails(JSONData): Observable<any> {
    return this.http.post(this.apiBaseUrl + "/api/applications/UpdateApplicationDetails", JSONData, { responseType: 'text' });
  }


  getRfiList(userId: string, role:string , cDate: string) : Observable<IRFIList[]>
  {
  const params = new HttpParams()
  .set('userId', userId)
  .set('role', role)
  .set('campaignDate',cDate)
        
    return this.http.get<IRFIList[]>(this.apiBaseUrl + "/api/RFI/GetRFIList",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  getRfiListDetails(rfiId: any) : Observable<IRFIListDetails[]>
  {
  const params = new HttpParams()
  .set('rfiId', rfiId)
         
    return this.http.get<IRFIListDetails[]>(this.apiBaseUrl + "/api/RFI/getRfiListDetails",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  GetRFDUserList(rfiId: any): Promise<any> {
    const params = new HttpParams().set('rfdid', rfiId);
    return this.http.get<IRFDUserListDetails[]>(this.apiBaseUrl + "/api/UserDetails/GetRFDUserList",{params}).pipe(
        retry(3),
       catchError(this.handleError)
    ).toPromise();
  }

  ValidateUpdateStatus(rfiId: any,userId: any): Observable<any>  {
    const params = new HttpParams()
    .set('rfdid', rfiId) 
    .set('loginUserId',userId);        
    return this.http.get<any>(this.apiBaseUrl + "/api/UserDetails/ValidateUpdateStatus",{params}).pipe(
     catchError(this.handleError)
    );
  }


  getRfiListbySearch(rfiOwnerId: string, rfiStatusId:string , rfiDueDate: string,cDate : string) : Observable<IRFIList[]>
  {

  const params = new HttpParams()
  .set('rfiOwnerId', rfiOwnerId)
  .set('rfiStatusId', rfiStatusId)
  .set('rfiDueDate',rfiDueDate)
  .set('campaignDate',cDate)
         
    return this.http.get<IRFIList[]>(this.apiBaseUrl + "/api/RFI/GetRFIListBySearch",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  getRfiStatus() : Observable<any[]>
  {
    return this.http.get<any[]>(this.apiBaseUrl + "/api/RFI/GetRFIStatus").pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  deleteApplicationList(userName : any) : Observable<any[]>
  {
    const params = new HttpParams()
    .set('userName', userName)
    return this.http.get<any[]>(this.apiBaseUrl + "/api/UserDetails/DeleteApplicationList",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }


  SaveRFDDocuments(fileData : any) : Observable<any>
  {

      return this.http.post(this.apiBaseUrl + "/api/RFI/UploadFiles",fileData).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
   
  }

  UploadFilesFromTemplate(fileData : any) : Observable<any>
  {
      debugger;
      return this.http.post(this.apiBaseUrl + "/api/RFI/UploadFilesToFolder",fileData).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  getCurrentRfiList() : Observable<IRFIList[]>
  {
    return this.http.get<any[]>(this.apiBaseUrl + "/api/RFI/GetCurrentRfiList").pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  downloadZipFile(userId: any): any 
  {
    return this.http.get(this.apiBaseUrl + "/api/RFI/DownloadUserListZipFile?userId=" + userId,{responseType : 'arraybuffer'});
  }

  GetUserRFDs(appOwnerIds: any,delegateId: any): Observable<any> {
    const params = new HttpParams()
         .set('appOwnerIds', appOwnerIds)
         .set('delegateId', delegateId)
    return this.http.get(this.apiBaseUrl + "/api/rfi/GetUserRFDs",{params}).pipe(
      catchError(this.handleError)
    );
  }

  deleteRFIDocument(rfiId: any,documentId: any): Observable<any> {
    const params = new HttpParams()
         .set('rfiId', rfiId)
         .set('documentId', documentId);
    return this.http.delete(this.apiBaseUrl + "/api/rfi/DeleteRFIDocument",{params}).pipe(
      catchError(this.handleError)
    );
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened. Please try again later.');
  }

  UpdatetoAdminStatus(rfiId: any): Observable<IValidAndUpdate[]> {

    // const params = new HttpParams()
    
    // .set('rfdid', rfiId)
    
    // return this.http.get<any[]>(this.apiBaseUrl + "/api/UserDetails/ValidateUpdateStatus",{params}).pipe(
    
    return this.http.get<IValidAndUpdate[]>(this.apiBaseUrl + "/api/RFI/UpdatetoAdminStatus?rfdid=" + rfiId).pipe(
    
    catchError(this.handleError)
    
    );
    
    }

    getRfiListbyBU(rfiOwnerId: string, rfiBU:string , rfiDueDate: string) : Observable<IRFIList[]>

{



const params = new HttpParams()

.set('rfiOwnerId', rfiOwnerId)

.set('rfiBU', rfiBU)

.set('rfiDueDate',rfiDueDate)

return this.http.get<IRFIList[]>(this.apiBaseUrl + "/api/RFI/getRfiListbyBU",{params}).pipe(

retry(3), // retry a failed request up to 3 times

catchError(this.handleError) // then handle the error

);

}

getRfiBUStatus() : Observable<any[]>

{

return this.http.get<any[]>(this.apiBaseUrl + "/api/RFI/GetBUList").pipe(

retry(3), // retry a failed request up to 3 times

catchError(this.handleError) // then handle the error

);

}

getRfiSubmittedList() : Observable<any[]>

{

return this.http.get<any[]>(this.apiBaseUrl + "/api/RFI/GetRFISubmittedList").pipe(

retry(3), // retry a failed request up to 3 times

catchError(this.handleError) // then handle the error

);

}


}
