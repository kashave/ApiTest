import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { CommonService } from './common.service';

interface RefreshTokenRequest {
  accessToken: string;
  refreshToken:string;
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private currentUserSubject: BehaviorSubject<any>;
  public currentUser: Observable<any>;
  isLoggedin: boolean = false;


  json;
  errorMessage = "";
  apiBaseUrl : any;
  config = {
    headers: {
      'Content-Type': 'application/json;charset=utf-8;'
    }
  }


  ApiBaseUrl() {
		return this.commonService.apiBaseUrl;
	}


  constructor(private http: HttpClient,private router:Router, private commonService:CommonService) {

    this.currentUserSubject = new BehaviorSubject<any>(JSON.parse(sessionStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
    if (sessionStorage.getItem('apiBaseUrl')) {
      this.apiBaseUrl = sessionStorage.getItem('apiBaseUrl')
    }
    else {
      this.apiBaseUrl = this.getApiBaseUrl();
    }
  }


  //calling Api url
  private async getApiBaseUrl() {
    let response = await this.getAppSettings();
    if(response){
      this.apiBaseUrl = response.apiBaseUrl;
      sessionStorage.setItem('apiBaseUrl',response.apiBaseUrl);
    }
    return response.apiBaseUrl;
  }

  //Reading Api Url from json file
  public async getAppSettings(): Promise<any> {
    return await this.http.get('./assets/appsettings.json').pipe(
      catchError(this.handleError)
    ).toPromise();
  }


  public get currentUserValue(): any {
    return this.currentUserSubject.value;
  }

  isLoggedIn() {
    if (JSON.parse(sessionStorage.getItem('currentUser')) == null) {
      this.isLoggedin = false;
      return this.isLoggedin;
    }
    else {
      return true;
    }
  }

  login(JSONData): Observable<any> {
    return this.http.post(this.apiBaseUrl+"/api/Account/Login", JSONData, { responseType: 'text' }
    )
      .pipe(map(user => {
        // login successful if there's a jwt token in the response
        if (user) {
          // store user details and jwt token in local storage to keep user logged in between page refreshes
          sessionStorage.setItem('currentUser', JSON.stringify(user));
          this.currentUserSubject.next(user);
        }

        return user;
      }));
  }

  refresh(){
    this.refreshToken().subscribe(data => {
      this.setCurrentUser(data);
    });
  }

  refreshToken(): Observable<any> {
    const dt : RefreshTokenRequest = {
      refreshToken: this.getRefreshToken(),
      accessToken : this.getAccessToken()
    }
    return this.http.post(this.apiBaseUrl+"/api/account/RefreshToken", dt, { responseType: 'text' });
  }


  setCurrentUser(user:any){
    sessionStorage.removeItem('currentUser');
    sessionStorage.setItem('currentUser', JSON.stringify(user));
    this.currentUserSubject.next(user);
    console.log(this.getRefreshToken());
    console.log(this.getAccessToken());
  }

  getAccessToken():string {
    var accessToken;
    if (JSON.parse(sessionStorage.getItem("currentUser")))
     {
      var usersJson = JSON.parse(sessionStorage.getItem("currentUser"))
      accessToken = JSON.parse(usersJson).accessToken;
    }
    return accessToken;
  }

  getRefreshToken():string {
    var refreshToken;
    if (JSON.parse(sessionStorage.getItem("currentUser")))
     {
      var usersJson = JSON.parse(sessionStorage.getItem("currentUser"))
     refreshToken = JSON.parse(usersJson).refreshToken;
    }
    return refreshToken;
  }

  getUserProfile():string {
    var userDisplayName;
    if (JSON.parse(sessionStorage.getItem("currentUser")))
     {
      var usersJson = JSON.parse(sessionStorage.getItem("currentUser"))
      userDisplayName = JSON.parse(usersJson).displayName;
    }
    return userDisplayName;
  }

  async getRolePermission(userName:string): Promise<any>{
    let response = await this.http.get(this.apiBaseUrl + "/api/user/GetUserDetail/"+userName,
          )
          .pipe().toPromise();
          if(response){
            sessionStorage.setItem('currentUserRole', JSON.stringify(response));

          }
          return response;
  }



  logout() {
    // remove user from local storage to log user out
    sessionStorage.removeItem('currentUser');
    sessionStorage.removeItem('currentUserRole');
    sessionStorage.removeItem('menuList');
    sessionStorage.removeItem('userRoleMenuList');
    sessionStorage.removeItem('sessionurl');
    this.currentUserSubject.next(null);
    this.router.navigate(["/login"]).then(() => window.location.reload());
    
  }

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened. Please try again later.');
  }
}


