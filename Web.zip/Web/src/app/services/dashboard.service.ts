import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpParams } from '@angular/common/http';
import { Observable, throwError, Subject } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import {CommonService}from '../services/common.service';


@Injectable({
  providedIn: 'root'
})
export class DashboardService {
  json;
  errorMessage = "";
  apiBaseUrl = this.ApiBaseUrl();
  config = {
    headers: {
      'Content-Type': 'application/json;charset=utf-8;'
    }
  }

  ApiBaseUrl() {
		return this.commonService.apiBaseUrl;
	}

  constructor(private http: HttpClient, private commonService:CommonService) { }
  private _refreshneeded$ = new Subject<void>();


  getDetailsbyQuarter(graphParam: any): Observable<any> {
    return this.http.get(this.apiBaseUrl + "/api/dashboard/getdetailsbyquarter?inputDashboard=" + graphParam).pipe(
      catchError(this.handleError)
    );
  }

  getStatusbyQuarter(graphParam: any): Observable<any> {
    return this.http.get(this.apiBaseUrl + "/api/dashboard/GetStatusDetailsByQuarter?inputDashboard=" + graphParam).pipe(
      catchError(this.handleError)
    );
  }

  //////////////////////////////////////
  private handleError(error: HttpErrorResponse) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      errorMessage = `Error: ${error.error.message}`;
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      // console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
      errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;

    }
    // return an observable with a user-facing error message

    return throwError(errorMessage);

  }
}
