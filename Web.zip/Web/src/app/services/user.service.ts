import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, throwError, Subject } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import {CommonService}from '../services/common.service';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  json;
  errorMessage = "";
  apiBaseUrl = this.ApiBaseUrl();
  config = {
    headers: {
      'Content-Type': 'application/json;charset=utf-8;'
    }
  }

  ApiBaseUrl() {
    return this.commonService.apiBaseUrl;
  }

  constructor(private http: HttpClient, private commonService:CommonService) { }
  private _refreshneeded$ = new Subject<void>();
  get refreshneeded() {
    return this._refreshneeded$;
  }

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json'
    })
  }

  getUserList(userRoleId: any): Observable<any> {

    return this.http.get(this.apiBaseUrl + "/api/User/GetAllUser?userRoleId=" + userRoleId).pipe(
    
    catchError(this.handleError)
    
    );
    
    }
    
    getAllRoles(userRoleId: any) : Observable<any> {
    
    return this.http.get(this.apiBaseUrl + "/api/User/GetAllRoles?userRoleId=" + userRoleId).pipe(
    
    catchError(this.handleError)
    
    );
    
    }
  getAllBUs() : Observable<any> {
    return this.http.get(this.apiBaseUrl + "/api/User/GetAllBU/").pipe(
      catchError(this.handleError)
    );
  }

  getApplicationList(firstName : any, lastName : any ) : Observable<any[]>
  {
    const params = new HttpParams()
    .set('firstName', firstName)
    .set('lastName', lastName)
    return this.http.get<any[]>(this.apiBaseUrl + "/api/UserDetails/GetApplicationList",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }
  UserUpsert(data: any): Observable<any> {
    return this.http.post<any>(this.apiBaseUrl + "/api/User/UserUpsert/", data);
  }
  deleteUser(data: any): Observable<any> {    
    return this.http.delete<any>(this.apiBaseUrl + "/api/User/Delete?userID="+data);
  }
  getUser(data: any): Observable<any> {
    return this.http.get<any>(this.apiBaseUrl + "/api/User/GetUser?userID="+data);
  }
  getMenu() : Observable<any[]>
  {
    return this.http.get<any[]>(this.apiBaseUrl + "/api/User/GetMenu").pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }  
  getUserRoleMenu(roleId: any) : Observable<any[]>
  {
   
    const params = new HttpParams()
    .set('roleId', roleId)
    return this.http.get<any[]>(this.apiBaseUrl + "/api/User/GetUserRoleMenu",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }  
  getMenuPermission(roleId: any,menuId : any) : Observable<any[]>
  {
    const params = new HttpParams()
    .set('roleId', roleId)
    .set('menuId', menuId)
    return this.http.get<any[]>(this.apiBaseUrl + "/api/User/GetMenuPermission",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  UpdateUserAccessList(data: any): Observable<any> {
    return this.http.post<any>(this.apiBaseUrl + "/api/User/UpdateUserAccess/", data);
  }
    
  DeleteUserAccess(userId: any, assetId:any, roleId: any, rfiId : any) : Observable<any>
  {
    const params = new HttpParams()
    .set('userId', userId)
    .set('assetId', assetId)
    .set('roleId', roleId)
    .set('loginUserId', this.commonService.getUserId().toString())
    .set('rfiId',rfiId)
    return this.http.delete<any>(this.apiBaseUrl + "/api/User/DeleteUserAccess",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  getValidateUserWithRFIs(userName: any): Observable<any> {

    return this.http.get(this.apiBaseUrl + "/api/User/ValidateUserWithRFIs?userName=" + userName).pipe(
    
    catchError(this.handleError)
    
    );
    
    }

  getWorkDayDetails(firstName: string,lastName : string) : Observable<any[]>
  {
    const params = new HttpParams()
    .set('firstName', firstName)
    .set('lastName', lastName)
    return this.http.get<any>(this.apiBaseUrl + "/api/User/GetWorkDayDetails",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }

  ValidateUserWithWorkDay(firstName: any,lastName : any,email : any) : Observable<any>
  {
    const params = new HttpParams()
    .set('firstName', firstName)
    .set('lastName', lastName)
    .set('email',email)
    return this.http.get(this.apiBaseUrl + "/api/User/ValidateUserWithWorkDay",{params}).pipe(
      retry(3), // retry a failed request up to 3 times
      catchError(this.handleError) // then handle the error
    );
  }


  GetApplicationOwners() : Observable<any> {
    return this.http.get(this.apiBaseUrl + "/api/User/GetApplicationOwners").pipe(
      catchError(this.handleError)
    );
  }
    
  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened. Please try again later.');
  }
}
