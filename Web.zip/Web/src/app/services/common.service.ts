import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  private data = {};  
  
  setOption(option, value) {      
     this.data[option] = value;  
   }  
   
   getOption() {  
     return this.data;  
   } 

  //common variable using in entire services
  apiBaseUrl: any = this.getApiBaseUrl();

  constructor(private http: HttpClient) {
    if (sessionStorage.getItem('apiBaseUrl')) {
      this.apiBaseUrl = sessionStorage.getItem('apiBaseUrl')
    }
    else {
      this.apiBaseUrl = this.getApiBaseUrl();
    }
  }

  ngOnInit() {
  }

  //calling Api url
  private getApiBaseUrl() {
    this.getAppSettings().subscribe(data => {
      this.apiBaseUrl = data.apiBaseUrl;
      sessionStorage.setItem('apiBaseUrl', data.apiBaseUrl);
     return data.apiBaseUrl;
    });
  }

  //Reading Api Url from json file
  private getAppSettings(): Observable<any> {
    return this.http.get('./assets/appsettings.json').pipe(
      catchError(this.handleError)
    );
  }

  //Delaying the function/api call
  async delay(ms: number) {
    await new Promise<void>(resolve => setTimeout(() => resolve(), ms)).then(() => console.log("fired"));
  }


  getRoleId(){
    let roleId: number = 0;
    if (JSON.parse(sessionStorage.getItem("currentUserRole")))
    {
      var usersJson = JSON.parse(sessionStorage.getItem("currentUserRole"));
      roleId = usersJson.roleId;
   }
   return roleId;
  }



  getUserId(){
    let currentUserId: number = 0;
    if (JSON.parse(sessionStorage.getItem("currentUserRole")))
    {
     var usersJson = JSON.parse(sessionStorage.getItem("currentUserRole"));
     currentUserId = usersJson.userId;
   }
   return currentUserId;
  }

  getRoleName(){
    let roleName: string = '';
    if (JSON.parse(sessionStorage.getItem("currentUserRole")))
    {
      var usersJson = JSON.parse(sessionStorage.getItem("currentUserRole"));
      roleName = usersJson.roleName;
    }
   return roleName;
  }

  getUserName(){
    let userName: string = '';
    if (JSON.parse(sessionStorage.getItem("currentUserRole")))
    {
     var usersJson = JSON.parse(sessionStorage.getItem("currentUserRole"));
     userName = usersJson.userName;
    }
   return userName;
  }

  async getPageAccess(pageName:string){
    let isPageAccess: boolean = false;
    if('home' == pageName){
        return true;
    }
    if (JSON.parse(sessionStorage.getItem("currentUserRole")))
    {
        var usersJson = JSON.parse(sessionStorage.getItem("currentUserRole"));
        isPageAccess = await usersJson.rolePermissions.find(a=>a.moduleName == pageName).isEnabledToView;
    }
   return isPageAccess;
  }

  async getPageAction(pageName:string){
    let isPageAccess: boolean = false;
    if (JSON.parse(sessionStorage.getItem("currentUserRole")))
    {
        var usersJson = JSON.parse(sessionStorage.getItem("currentUserRole"));
        isPageAccess = await usersJson.rolePermissions.find(a=>a.moduleName == pageName).isEnabledToEdit;
   }
   return isPageAccess;
  }



  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened. Please try again later.');
  }
}


