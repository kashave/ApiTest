import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders,HttpParams } from '@angular/common/http';
import { Observable, throwError, Subject } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';
import {CommonService}from '../services/common.service';
import { IAppTemplateList } from '../interfaces/IAppTemplateList';

@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  json;
  errorMessage = "";
  apiBaseUrl = this.ApiBaseUrl();
  config = {
    headers: {
      'Content-Type': 'application/json;charset=utf-8;'
    }
  }

  ApiBaseUrl() {
		return this.commonService.apiBaseUrl;
	}

  constructor(private http: HttpClient, private commonService:CommonService) { }
  private _refreshneeded$ = new Subject<void>();
  get refreshneeded() {
    return this._refreshneeded$;
  }

  // Http Options
  httpOptions = {
    headers: new HttpHeaders({
      'Access-Control-Allow-Origin': '*',
      'Content-Type': 'application/json'
    })
  }

  GetAppTemplatesList(appId: any): Observable<any> {
    const params = new HttpParams()
         .set('appid', appId);
    return this.http.get(this.apiBaseUrl + "/api/template/GetAppTemplatesList",{params}).pipe(
      catchError(this.handleError)
    );
  }

  CreateUpdateTemplate(data: any): Observable<any> {
    return this.http.post<any>(this.apiBaseUrl + "/api/template", data);
  }

  ParseFileToJson(appId: any, templateId:any, fileName:any): Observable<any> {
    const params = new HttpParams()
         .set('applicationId', appId)
         .set('templateId',templateId)
         .set('fileName',fileName);
    return this.http.get(this.apiBaseUrl + "/api/template/ParseTemplateForJSON",{params}).pipe(
      catchError(this.handleError)
    );
  }

  /*async getRFIDetailList(userId: string,role:string,cDate:string): Promise<any> {
         const params = new HttpParams()
         .set('userId', userId)
         .set('role', role)
         .set('campaignDate',cDate)               
           return this.http.get(this.apiBaseUrl + "/api/RFI/GetRFIList",{params}).pipe(
             retry(3), // retry a failed request up to 3 times
             catchError(this.handleError) // then handle the error
           ).toPromise();

  }

  postApplicationDetails(JSONData): Observable<any> {
    return this.http.post(this.apiBaseUrl + "/api/applications/UpdateApplicationDetails", JSONData, { responseType: 'text' });
  }*/

  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(`Backend returned code ${error.status}, ` + `body was: ${error.error}`);
    }
    // return an observable with a user-facing error message
    return throwError('Something bad happened. Please try again later.');
  }
}
