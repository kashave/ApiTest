import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { UserService } from '../services/user.service';
import { HttpClient} from '@angular/common/http';
import { AuthService } from './auth.service'

@Injectable()
export class AuthGuard implements CanActivate {

  constructor(private userService: UserService,
    private http: HttpClient, private router: Router, private authService: AuthService) {
  }
  async canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {1
    let routepath = '';
    let isPermission = true;
    if (route.url.length > 0) {
      routepath = route.url[0].path;
    }
    else {
      routepath = state.url.replace('/', '');
    }
    if (state.url !== '/login' && !this.authService.isLoggedIn()) {
      
      sessionStorage.setItem('sessionurl',JSON.stringify(state.url));
      this.router.navigate(['/login']).then(() => window.location.reload());
      return false;
    }
    else{
      return true;

    }
  //   let respone = await this.authService.getPageAccess(routepath);
  //   if(respone!=null && respone!=undefined)
  //   {
  //     isPermission = respone;
  //     if(!isPermission)
  //      {
  //        this.router.navigate([`/access-denied`]);
  //        return false;
  //      }
  //   }
  //  return isPermission;

  }
}
