import { Component, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Idle } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-idle-modal',
  templateUrl: './idle-modal.component.html',
  styleUrls: ['./idle-modal.component.css']
})
export class IdleModalComponent {

  constructor(private dialogRef: MatDialogRef<IdleModalComponent>, @Inject(MAT_DIALOG_DATA)
  public data: any, public authService: AuthService, private idle: Idle, private keepalive: Keepalive) {
    dialogRef.disableClose = true;
  }
 
  reFreshToken() {
    this.authService.refresh();
    this.idle.stop();
    this.idle.watch();
  }

  logOut() {
    this.dialogRef.close();
    this.authService.logout();

  }





}




