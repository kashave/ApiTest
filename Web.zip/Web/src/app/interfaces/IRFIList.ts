import { DateSelectionModelChange } from "@angular/material/datepicker";

export interface IRFIList {
    id: number,
    rfiid: string,
    rfistatus : string,
    rfiowner: string,
    rfiname : string,
    applicationname : string,
    duedate : Date,
    applicationId : number
    bu:string  
  }