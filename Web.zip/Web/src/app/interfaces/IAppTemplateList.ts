import { DateSelectionModelChange } from "@angular/material/datepicker";

export interface IAppTemplateList {
    ApplicationId: number,
    TemplateId: number,
    Description: string,
    Details : string,
    DocumentTypeId: number,
    DocumentData : string,
    TemplateTypeId: number,
    TemplateType : string      
  }

  