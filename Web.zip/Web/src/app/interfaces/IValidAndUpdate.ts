export interface IValidAndUpdate {

    errorMessage :string
  
    }