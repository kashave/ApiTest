export interface IRFIListDetails {
  quarter : string,
  year : string,
  appCategory : string,
  dataNeeded : number,
  certID : string,
  appName : string,
  appNumber : string,
  iTAppOwner : string,
  certDueDate : Date,
  dataRequestStatus : string,
  rejectedType : string,
  generalComments : string,
  deligateDetails : Array<Delegatedetails>
}

export interface Delegatedetails
{
  delegateName: string,
  delegateLanId: string,
  delegateEmailId: string
}