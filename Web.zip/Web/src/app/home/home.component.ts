import { Component,ViewChild,ViewChildren,QueryList,ElementRef } from '@angular/core';
import { CommonService } from '../services/common.service';
import { UserService } from '../services/user.service';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent  {
       erroMsg: any;
       isShow:boolean;
       constructor(private userService : UserService,private commonservice: CommonService )
       {

       }

       ngOnInit() {
        this.isShow=false;
               this.userService.getMenu().subscribe(
               (data) => (
             sessionStorage.setItem('menuList', JSON.stringify(data))),
               (error) => (this.erroMsg = error)
             );
              
              this.userService.getUserRoleMenu(this.commonservice.getRoleId()).subscribe(
               (data) => (
               sessionStorage.setItem('userRoleMenuList', JSON.stringify(data))),
               (error) => (this.erroMsg = error)
             );
              
            
          }

}

