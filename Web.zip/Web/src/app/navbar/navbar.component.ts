import { Component, OnInit } from '@angular/core';
import { Router,NavigationStart } from '@angular/router';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import jwt_decode from 'jwt-decode';
import { AuthService } from '../services/auth.service';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { IdleModalComponent } from '../modal/idle-model/idle-modal.component';


@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrls: ['./navbar.component.css']
})
export class NavbarComponent {
  sidenavWidth = 15;
  ngStyle: string;
  isExpanded = true;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;
  username; fullname;
  token; expirationTime;
  freshToken:string;
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  private dialogRef: MatDialogRef<IdleModalComponent>

  ngOnInit() {
  if (this.authService.getUserProfile() != null)
  {
      this.fullname = this.authService.getUserProfile();
      console.log(this.fullname);
      this.token = this.authService.getAccessToken();
      console.log(this.token);
      this.freshToken = this.authService.getRefreshToken();
      console.log(this.freshToken);

    // sets an idle timeout of 5 seconds, for testing purposes.
    this.idle.setIdle(1200); // 20 mins
    // sets a timeout period of 5 seconds. after 10 seconds of inactivity, the user will be considered timed out.
    this.idle.setTimeout(60); // 5 mins
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    this.idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);

    // this.idle.onIdleEnd.subscribe(() => {
    //   this.idleState = 'No longer idle.'
    //   console.log(this.idleState);
    //   this.reset();
    // });

    this.idle.onTimeout.subscribe(() => {
      this.idleState = 'Timed out!';
      this.idleState = ' You will time out in 5 seconds!' ;
      this.timedOut = true;
      console.log(this.idleState);
      this.authService.logout();
      // this.dialogRef = this.dialog.open(IdleModalComponent,
      //   {
      //     width: '30%',
      //     data: {
      //       message: this.idleState
      //     },

      //   });


      // setTimeout(() => {
      //   this.idle.stop();
      //   this.authService.logout();
      // }, 10000 * 3);


    });

    // if (!(sessionStorage.getItem("stay"))){
    //   this.authService.logout();
    // }

    // this.idle.onIdleStart.subscribe(() => {
    //     this.idleState = 'You\'ve gone idle!'
    //    // this.openConfirmDialog();
    //     console.log(this.idleState);
    // });

    this.idle.onTimeoutWarning.subscribe((countdown) => {
      this.idleState = 'You will time out in ' + countdown + ' seconds!';
     // this.openConfirmDialog();
      console.log(this.idleState);
    });

    // sets the ping interval to 15 seconds
   // this.keepalive.interval(180); // 15 mins

    this.keepalive.onPing.subscribe(
    () => {
            this.lastPing = new Date();
            this.authService.refresh();
            //this.idle.watch()
            //this.timedOut = false;
          }
    );

    // this.appService.getUserLoggedIn().subscribe(userLoggedIn => {
    //   if (userLoggedIn) {
    //     this.idle.watch()
    //     this.timedOut = false;
    //   } else {
    //     this.idle.stop();
    //   }
    // })

     this.reset();
  }
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
    console.log(this.idleState);
  }

  logout(){
   this.authService.logout();
  }

  openConfirmDialog() {
    this.dialogRef = this.dialog.open(IdleModalComponent,
      {
        width: '30%',
        data: {
          message: this.idleState
        }
      });

   }

  getDecodedAccessToken(token: string): any {
    try {
      return jwt_decode(token);
    }
    catch (Error) {
      return null;
    }
  }

  _showTab: number = 1;
  get showTab() {

    return parseInt(sessionStorage.getItem('showTab') ? sessionStorage.getItem('showTab') : '1');
  }
  set showTab(value: number) {
    sessionStorage.setItem('showTab', value.toString());
    this._showTab = value;
  }
  tabToggle(index: number) {
    this.showTab = index;
  }
  showsettings: boolean = false;
  showlogin: boolean = false;

  constructor(private router: Router, private authService: AuthService,public dialog: MatDialog,
    private idle: Idle, private keepalive: Keepalive) {

    router.events.forEach((event) => {

      if (event instanceof NavigationStart && event['url']) {
       // console.log()
        this.setTab(event['url']);

        if (event['url'] == '/settings'|| event['url'] == '/user' ||
        event['url'] == '/role' || event['url'] == '/permission' || event['url'] == '/exclusionrules') {
          this.showsettings = true;
        }
        else if (event['url'] == '/login') {
          this.showlogin = true;
        }
        else {
          this.showsettings = false;
          this.showlogin = false;
        }

    }
    });
  }

  backtoHome() {
    this.router.navigate(['/home']);
  }

  setTab(url: string) {
    debugger;
    //  console.log(url)
      if (url.includes('/home')) {
        this.showTab = 1;

      }
      else if (url.includes('/transmission')) {
       this.showTab = 2;
       this.tabToggle(2)
      }
      else if (url.includes('/scheduling')) {
        this.showTab = 3;
        this.tabToggle(3);
      }
      else{
        this.showTab = 1;
      }
    }
}
